﻿namespace KazyCrypter
{
    partial class CrypterForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tt = new System.Windows.Forms.ToolTip(this.components);
            this.mysticCheckBox13 = new KazyCrypter.MysticCheckBox();
            this.mysticCheckBox6 = new KazyCrypter.MysticCheckBox();
            this.mysticCheckBox7 = new KazyCrypter.MysticCheckBox();
            this.mysticCheckBox8 = new KazyCrypter.MysticCheckBox();
            this.mysticCheckBox9 = new KazyCrypter.MysticCheckBox();
            this.mysticCheckBox5 = new KazyCrypter.MysticCheckBox();
            this.mysticCheckBox4 = new KazyCrypter.MysticCheckBox();
            this.mysticCheckBox3 = new KazyCrypter.MysticCheckBox();
            this.mysticCheckBox2 = new KazyCrypter.MysticCheckBox();
            this.mysticRadioButton6 = new KazyCrypter.MysticRadioButton();
            this.mysticRadioButton5 = new KazyCrypter.MysticRadioButton();
            this.mysticRadioButton4 = new KazyCrypter.MysticRadioButton();
            this.mysticRadioButton3 = new KazyCrypter.MysticRadioButton();
            this.mysticRadioButton2 = new KazyCrypter.MysticRadioButton();
            this.mysticRadioButton1 = new KazyCrypter.MysticRadioButton();
            this.mysticCheckBox1 = new KazyCrypter.MysticCheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.mysticButton1 = new KazyCrypter.MysticButton();
            this.mysticTextBox1 = new KazyCrypter.MysticTextBox();
            this.mysticCheckBox11 = new KazyCrypter.MysticCheckBox();
            this.mysticCheckBox10 = new KazyCrypter.MysticCheckBox();
            this.mysticCheckBox19 = new KazyCrypter.MysticCheckBox();
            this.mysticButton3 = new KazyCrypter.MysticButton();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.mysticButton2 = new KazyCrypter.MysticButton();
            this.mysticRadioButton8 = new KazyCrypter.MysticRadioButton();
            this.mysticRadioButton7 = new KazyCrypter.MysticRadioButton();
            this.mysticCheckBox12 = new KazyCrypter.MysticCheckBox();
            this.mysticCheckBox18 = new KazyCrypter.MysticCheckBox();
            this.mysticCheckBox17 = new KazyCrypter.MysticCheckBox();
            this.mysticCheckBox16 = new KazyCrypter.MysticCheckBox();
            this.mysticTextBox11 = new KazyCrypter.MysticTextBox();
            this.mysticTextBox10 = new KazyCrypter.MysticTextBox();
            this.mysticTextBox9 = new KazyCrypter.MysticTextBox();
            this.mysticCheckBox15 = new KazyCrypter.MysticCheckBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.mysticTextBox8 = new KazyCrypter.MysticTextBox();
            this.mysticTextBox7 = new KazyCrypter.MysticTextBox();
            this.mysticCheckBox14 = new KazyCrypter.MysticCheckBox();
            this.mysticCheckBox28 = new KazyCrypter.MysticCheckBox();
            this.mysticRadioButton10 = new KazyCrypter.MysticRadioButton();
            this.mysticRadioButton9 = new KazyCrypter.MysticRadioButton();
            this.mysticCheckBox27 = new KazyCrypter.MysticCheckBox();
            this.mysticButton7 = new KazyCrypter.MysticButton();
            this.mysticButton6 = new KazyCrypter.MysticButton();
            this.mysticButton5 = new KazyCrypter.MysticButton();
            this.mysticCheckBox26 = new KazyCrypter.MysticCheckBox();
            this.mysticCheckBox25 = new KazyCrypter.MysticCheckBox();
            this.mysticCheckBox24 = new KazyCrypter.MysticCheckBox();
            this.mysticCheckBox23 = new KazyCrypter.MysticCheckBox();
            this.mysticCheckBox22 = new KazyCrypter.MysticCheckBox();
            this.mysticCheckBox21 = new KazyCrypter.MysticCheckBox();
            this.mysticCheckBox20 = new KazyCrypter.MysticCheckBox();
            this.mysticButton10 = new KazyCrypter.MysticButton();
            this.mysticCheckBox29 = new KazyCrypter.MysticCheckBox();
            this.mysticButton14 = new KazyCrypter.MysticButton();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.mysticButton12 = new KazyCrypter.MysticButton();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.openFileDialog2 = new System.Windows.Forms.OpenFileDialog();
            this.openFileDialog3 = new System.Windows.Forms.OpenFileDialog();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.addFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addUrlToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.locationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.currentFolderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.runToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.onceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.alwaysToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.neverToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.removeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.removeAllToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openFileDialog4 = new System.Windows.Forms.OpenFileDialog();
            this.openFileDialog5 = new System.Windows.Forms.OpenFileDialog();
            this.openFileDialog6 = new System.Windows.Forms.OpenFileDialog();
            this.openFileDialog7 = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.saveFileDialog2 = new System.Windows.Forms.SaveFileDialog();
            this.openFileDialog8 = new System.Windows.Forms.OpenFileDialog();
            this.mysticTheme1 = new KazyCrypter.MysticTheme();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tabControlEX1 = new Dotnetrix.Controls.TabControlEX();
            this.tabPageEX1 = new Dotnetrix.Controls.TabPageEX();
            this.mysticGroupBox7 = new KazyCrypter.MysticGroupBox();
            this.mysticGroupBox6 = new KazyCrypter.MysticGroupBox();
            this.mysticGroupBox5 = new KazyCrypter.MysticGroupBox();
            this.mysticGroupBox3 = new KazyCrypter.MysticGroupBox();
            this.mysticGroupBox4 = new KazyCrypter.MysticGroupBox();
            this.mysticTextBox2 = new KazyCrypter.MysticTextBox();
            this.mysticGroupBox1 = new KazyCrypter.MysticGroupBox();
            this.tabPageEX2 = new Dotnetrix.Controls.TabPageEX();
            this.mysticGroupBox20 = new KazyCrypter.MysticGroupBox();
            this.vScrollBar1 = new System.Windows.Forms.VScrollBar();
            this.fversion4 = new KazyCrypter.MysticTextBox();
            this.fversion3 = new KazyCrypter.MysticTextBox();
            this.fversion2 = new KazyCrypter.MysticTextBox();
            this.fversion1 = new KazyCrypter.MysticTextBox();
            this.version4 = new KazyCrypter.MysticTextBox();
            this.version3 = new KazyCrypter.MysticTextBox();
            this.version2 = new KazyCrypter.MysticTextBox();
            this.version1 = new KazyCrypter.MysticTextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.descriptionbox = new KazyCrypter.MysticTextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.copyrightbox = new KazyCrypter.MysticTextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.productbox = new KazyCrypter.MysticTextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.titlebox = new KazyCrypter.MysticTextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.mysticGroupBox8 = new KazyCrypter.MysticGroupBox();
            this.mysticTextBox4 = new KazyCrypter.MysticTextBox();
            this.mysticGroupBox2 = new KazyCrypter.MysticGroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.mysticTextBox3 = new KazyCrypter.MysticTextBox();
            this.tabPageEX3 = new Dotnetrix.Controls.TabPageEX();
            this.mysticButton4 = new KazyCrypter.MysticButton();
            this.mysticGroupBox13 = new KazyCrypter.MysticGroupBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.mysticGroupBox12 = new KazyCrypter.MysticGroupBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.mysticGroupBox11 = new KazyCrypter.MysticGroupBox();
            this.mysticTextBox6 = new KazyCrypter.MysticTextBox();
            this.mysticGroupBox10 = new KazyCrypter.MysticGroupBox();
            this.mysticTextBox5 = new KazyCrypter.MysticTextBox();
            this.tabPageEX4 = new Dotnetrix.Controls.TabPageEX();
            this.mysticGroupBox19 = new KazyCrypter.MysticGroupBox();
            this.mysticGroupBox18 = new KazyCrypter.MysticGroupBox();
            this.mysticGroupBox17 = new KazyCrypter.MysticGroupBox();
            this.mysticGroupBox14 = new KazyCrypter.MysticGroupBox();
            this.mysticGroupBox16 = new KazyCrypter.MysticGroupBox();
            this.mysticGroupBox15 = new KazyCrypter.MysticGroupBox();
            this.tabPageEX6 = new Dotnetrix.Controls.TabPageEX();
            this.mysticGroupBox9 = new KazyCrypter.MysticGroupBox();
            this.listView1 = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabPageEX10 = new Dotnetrix.Controls.TabPageEX();
            this.mysticGroupBox26 = new KazyCrypter.MysticGroupBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label13 = new System.Windows.Forms.Label();
            this.mysticGroupBox25 = new KazyCrypter.MysticGroupBox();
            this.mysticTextBox13 = new KazyCrypter.MysticTextBox();
            this.mysticGroupBox24 = new KazyCrypter.MysticGroupBox();
            this.mysticGroupBox23 = new KazyCrypter.MysticGroupBox();
            this.mysticGroupBox22 = new KazyCrypter.MysticGroupBox();
            this.mysticTextBox12 = new KazyCrypter.MysticTextBox();
            this.mysticGroupBox21 = new KazyCrypter.MysticGroupBox();
            this.tabPageEX8 = new Dotnetrix.Controls.TabPageEX();
            this.mysticGroupBox29 = new KazyCrypter.MysticGroupBox();
            this.mysticButton8 = new KazyCrypter.MysticButton();
            this.mysticGroupBox28 = new KazyCrypter.MysticGroupBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.mysticGroupBox27 = new KazyCrypter.MysticGroupBox();
            this.mysticTextBox14 = new KazyCrypter.MysticTextBox();
            this.tabPageEX9 = new Dotnetrix.Controls.TabPageEX();
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.label18 = new System.Windows.Forms.Label();
            this.mysticButton9 = new KazyCrypter.MysticButton();
            this.mysticGroupBox32 = new KazyCrypter.MysticGroupBox();
            this.mysticTextBox17 = new KazyCrypter.MysticTextBox();
            this.mysticGroupBox31 = new KazyCrypter.MysticGroupBox();
            this.mysticTextBox16 = new KazyCrypter.MysticTextBox();
            this.mysticGroupBox30 = new KazyCrypter.MysticGroupBox();
            this.mysticTextBox15 = new KazyCrypter.MysticTextBox();
            this.tabPageEX7 = new Dotnetrix.Controls.TabPageEX();
            this.mysticButton11 = new KazyCrypter.MysticButton();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.mysticGroupBox35 = new KazyCrypter.MysticGroupBox();
            this.linkLabel3 = new System.Windows.Forms.LinkLabel();
            this.mysticGroupBox34 = new KazyCrypter.MysticGroupBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.mysticGroupBox33 = new KazyCrypter.MysticGroupBox();
            this.listView2 = new System.Windows.Forms.ListView();
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabPageEX5 = new Dotnetrix.Controls.TabPageEX();
            this.mysticGroupBox39 = new KazyCrypter.MysticGroupBox();
            this.label25 = new System.Windows.Forms.Label();
            this.mysticTextBox18 = new KazyCrypter.MysticTextBox();
            this.mysticGroupBox38 = new KazyCrypter.MysticGroupBox();
            this.mysticButton13 = new KazyCrypter.MysticButton();
            this.mysticGroupBox37 = new KazyCrypter.MysticGroupBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.mysticGroupBox36 = new KazyCrypter.MysticGroupBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel3 = new System.Windows.Forms.ToolStripStatusLabel();
            this.mysticMini1 = new KazyCrypter.MysticMini();
            this.mysticClose1 = new KazyCrypter.MysticClose();
            this.contextMenuStrip1.SuspendLayout();
            this.mysticTheme1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tabControlEX1.SuspendLayout();
            this.tabPageEX1.SuspendLayout();
            this.mysticGroupBox7.SuspendLayout();
            this.mysticGroupBox6.SuspendLayout();
            this.mysticGroupBox5.SuspendLayout();
            this.mysticGroupBox3.SuspendLayout();
            this.mysticGroupBox4.SuspendLayout();
            this.mysticGroupBox1.SuspendLayout();
            this.tabPageEX2.SuspendLayout();
            this.mysticGroupBox20.SuspendLayout();
            this.mysticGroupBox8.SuspendLayout();
            this.mysticGroupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabPageEX3.SuspendLayout();
            this.mysticGroupBox13.SuspendLayout();
            this.mysticGroupBox12.SuspendLayout();
            this.mysticGroupBox11.SuspendLayout();
            this.mysticGroupBox10.SuspendLayout();
            this.tabPageEX4.SuspendLayout();
            this.mysticGroupBox19.SuspendLayout();
            this.mysticGroupBox18.SuspendLayout();
            this.mysticGroupBox17.SuspendLayout();
            this.mysticGroupBox14.SuspendLayout();
            this.mysticGroupBox16.SuspendLayout();
            this.mysticGroupBox15.SuspendLayout();
            this.tabPageEX6.SuspendLayout();
            this.mysticGroupBox9.SuspendLayout();
            this.tabPageEX10.SuspendLayout();
            this.mysticGroupBox26.SuspendLayout();
            this.mysticGroupBox25.SuspendLayout();
            this.mysticGroupBox24.SuspendLayout();
            this.mysticGroupBox23.SuspendLayout();
            this.mysticGroupBox22.SuspendLayout();
            this.mysticGroupBox21.SuspendLayout();
            this.tabPageEX8.SuspendLayout();
            this.mysticGroupBox29.SuspendLayout();
            this.mysticGroupBox28.SuspendLayout();
            this.mysticGroupBox27.SuspendLayout();
            this.tabPageEX9.SuspendLayout();
            this.mysticGroupBox32.SuspendLayout();
            this.mysticGroupBox31.SuspendLayout();
            this.mysticGroupBox30.SuspendLayout();
            this.tabPageEX7.SuspendLayout();
            this.mysticGroupBox35.SuspendLayout();
            this.mysticGroupBox34.SuspendLayout();
            this.mysticGroupBox33.SuspendLayout();
            this.tabPageEX5.SuspendLayout();
            this.mysticGroupBox39.SuspendLayout();
            this.mysticGroupBox38.SuspendLayout();
            this.mysticGroupBox37.SuspendLayout();
            this.mysticGroupBox36.SuspendLayout();
            this.panel2.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tt
            // 
            this.tt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(29)))), ((int)(((byte)(35)))));
            this.tt.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(153)))), ((int)(((byte)(228)))));
            // 
            // mysticCheckBox13
            // 
            this.mysticCheckBox13.Checked = false;
            this.mysticCheckBox13.Location = new System.Drawing.Point(7, 27);
            this.mysticCheckBox13.Name = "mysticCheckBox13";
            this.mysticCheckBox13.Size = new System.Drawing.Size(133, 16);
            this.mysticCheckBox13.TabIndex = 0;
            this.mysticCheckBox13.Text = "Force Admin Rights";
            this.tt.SetToolTip(this.mysticCheckBox13, "Forces adming rights for your file. It needs the user to grant permissions to run" +
        " your file.");
            // 
            // mysticCheckBox6
            // 
            this.mysticCheckBox6.Checked = false;
            this.mysticCheckBox6.Location = new System.Drawing.Point(109, 48);
            this.mysticCheckBox6.Name = "mysticCheckBox6";
            this.mysticCheckBox6.Size = new System.Drawing.Size(49, 16);
            this.mysticCheckBox6.TabIndex = 3;
            this.mysticCheckBox6.Text = "Ver";
            this.tt.SetToolTip(this.mysticCheckBox6, "Compresses your file by deleting its VersionInfo.\r\n");
            // 
            // mysticCheckBox7
            // 
            this.mysticCheckBox7.Checked = false;
            this.mysticCheckBox7.Location = new System.Drawing.Point(8, 48);
            this.mysticCheckBox7.Name = "mysticCheckBox7";
            this.mysticCheckBox7.Size = new System.Drawing.Size(49, 16);
            this.mysticCheckBox7.TabIndex = 2;
            this.mysticCheckBox7.Text = "Gzip";
            this.tt.SetToolTip(this.mysticCheckBox7, "Compresses your file using the GZIP.\r\n");
            // 
            // mysticCheckBox8
            // 
            this.mysticCheckBox8.Checked = false;
            this.mysticCheckBox8.Location = new System.Drawing.Point(8, 26);
            this.mysticCheckBox8.Name = "mysticCheckBox8";
            this.mysticCheckBox8.Size = new System.Drawing.Size(75, 16);
            this.mysticCheckBox8.TabIndex = 1;
            this.mysticCheckBox8.Text = "USG";
            this.tt.SetToolTip(this.mysticCheckBox8, "Compresses your file using the USG\'s default compression.");
            // 
            // mysticCheckBox9
            // 
            this.mysticCheckBox9.Checked = false;
            this.mysticCheckBox9.Location = new System.Drawing.Point(109, 26);
            this.mysticCheckBox9.Name = "mysticCheckBox9";
            this.mysticCheckBox9.Size = new System.Drawing.Size(51, 16);
            this.mysticCheckBox9.TabIndex = 0;
            this.mysticCheckBox9.Text = "UPX";
            this.tt.SetToolTip(this.mysticCheckBox9, "Compresses your file using the UPX. Only usable on native files.");
            // 
            // mysticCheckBox5
            // 
            this.mysticCheckBox5.Checked = false;
            this.mysticCheckBox5.Location = new System.Drawing.Point(109, 48);
            this.mysticCheckBox5.Name = "mysticCheckBox5";
            this.mysticCheckBox5.Size = new System.Drawing.Size(49, 16);
            this.mysticCheckBox5.TabIndex = 3;
            this.mysticCheckBox5.Text = "WPE";
            this.tt.SetToolTip(this.mysticCheckBox5, "Terminates the program when WPE is detected.");
            // 
            // mysticCheckBox4
            // 
            this.mysticCheckBox4.Checked = false;
            this.mysticCheckBox4.Location = new System.Drawing.Point(109, 26);
            this.mysticCheckBox4.Name = "mysticCheckBox4";
            this.mysticCheckBox4.Size = new System.Drawing.Size(49, 16);
            this.mysticCheckBox4.TabIndex = 2;
            this.mysticCheckBox4.Text = "WS";
            this.tt.SetToolTip(this.mysticCheckBox4, "Terminates the program when WireShark is detected.");
            // 
            // mysticCheckBox3
            // 
            this.mysticCheckBox3.Checked = false;
            this.mysticCheckBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.mysticCheckBox3.Location = new System.Drawing.Point(7, 48);
            this.mysticCheckBox3.Name = "mysticCheckBox3";
            this.mysticCheckBox3.Size = new System.Drawing.Size(75, 16);
            this.mysticCheckBox3.TabIndex = 1;
            this.mysticCheckBox3.Text = "Emulation";
            this.tt.SetToolTip(this.mysticCheckBox3, "Terminates the program when Emulation is detected.");
            // 
            // mysticCheckBox2
            // 
            this.mysticCheckBox2.Checked = false;
            this.mysticCheckBox2.Location = new System.Drawing.Point(7, 26);
            this.mysticCheckBox2.Name = "mysticCheckBox2";
            this.mysticCheckBox2.Size = new System.Drawing.Size(86, 16);
            this.mysticCheckBox2.TabIndex = 0;
            this.mysticCheckBox2.Text = "Sandboxie";
            this.tt.SetToolTip(this.mysticCheckBox2, "Terminates the program when Sandboxie is detected.");
            // 
            // mysticRadioButton6
            // 
            this.mysticRadioButton6.Checked = false;
            this.mysticRadioButton6.Location = new System.Drawing.Point(6, 63);
            this.mysticRadioButton6.Name = "mysticRadioButton6";
            this.mysticRadioButton6.Size = new System.Drawing.Size(75, 16);
            this.mysticRadioButton6.TabIndex = 5;
            this.mysticRadioButton6.Text = "Custom";
            this.tt.SetToolTip(this.mysticRadioButton6, "Itself injection with a custom filename.");
            this.mysticRadioButton6.CheckedChanged += new KazyCrypter.MysticRadioButton.CheckedChangedEventHandler(this.mysticRadioButton6_CheckedChanged);
            // 
            // mysticRadioButton5
            // 
            this.mysticRadioButton5.Checked = false;
            this.mysticRadioButton5.Location = new System.Drawing.Point(261, 29);
            this.mysticRadioButton5.Name = "mysticRadioButton5";
            this.mysticRadioButton5.Size = new System.Drawing.Size(72, 16);
            this.mysticRadioButton5.TabIndex = 4;
            this.mysticRadioButton5.Text = "Browser";
            this.tt.SetToolTip(this.mysticRadioButton5, "Injects to the default browser.");
            // 
            // mysticRadioButton4
            // 
            this.mysticRadioButton4.Checked = false;
            this.mysticRadioButton4.Location = new System.Drawing.Point(189, 29);
            this.mysticRadioButton4.Name = "mysticRadioButton4";
            this.mysticRadioButton4.Size = new System.Drawing.Size(67, 16);
            this.mysticRadioButton4.TabIndex = 3;
            this.mysticRadioButton4.Text = "Regasm";
            this.tt.SetToolTip(this.mysticRadioButton4, "Injection for .Net files.");
            // 
            // mysticRadioButton3
            // 
            this.mysticRadioButton3.Checked = false;
            this.mysticRadioButton3.Location = new System.Drawing.Point(116, 29);
            this.mysticRadioButton3.Name = "mysticRadioButton3";
            this.mysticRadioButton3.Size = new System.Drawing.Size(75, 16);
            this.mysticRadioButton3.TabIndex = 2;
            this.mysticRadioButton3.Text = "Svchost";
            this.tt.SetToolTip(this.mysticRadioButton3, "Easily bypasses Firewalls.");
            // 
            // mysticRadioButton2
            // 
            this.mysticRadioButton2.Checked = false;
            this.mysticRadioButton2.Location = new System.Drawing.Point(64, 29);
            this.mysticRadioButton2.Name = "mysticRadioButton2";
            this.mysticRadioButton2.Size = new System.Drawing.Size(47, 16);
            this.mysticRadioButton2.TabIndex = 1;
            this.mysticRadioButton2.Text = "Vbc";
            this.tt.SetToolTip(this.mysticRadioButton2, "Stable injection.");
            // 
            // mysticRadioButton1
            // 
            this.mysticRadioButton1.Checked = true;
            this.mysticRadioButton1.Location = new System.Drawing.Point(6, 29);
            this.mysticRadioButton1.Name = "mysticRadioButton1";
            this.mysticRadioButton1.Size = new System.Drawing.Size(59, 16);
            this.mysticRadioButton1.TabIndex = 0;
            this.mysticRadioButton1.Text = "Itself";
            this.tt.SetToolTip(this.mysticRadioButton1, "The most stable and recommended injection.");
            // 
            // mysticCheckBox1
            // 
            this.mysticCheckBox1.Checked = false;
            this.mysticCheckBox1.Enabled = false;
            this.mysticCheckBox1.Location = new System.Drawing.Point(202, 8);
            this.mysticCheckBox1.Name = "mysticCheckBox1";
            this.mysticCheckBox1.Size = new System.Drawing.Size(144, 16);
            this.mysticCheckBox1.TabIndex = 0;
            this.mysticCheckBox1.Text = "Force .Net Reflection";
            this.tt.SetToolTip(this.mysticCheckBox1, "Forces the Reflection on .Net files. It may be used id compatibility issues are p" +
        "resent.");
            this.mysticCheckBox1.CheckedChanged += new KazyCrypter.MysticCheckBox.CheckedChangedEventHandler(this.mysticCheckBox1_CheckedChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.Location = new System.Drawing.Point(290, 54);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 15);
            this.label3.TabIndex = 4;
            this.label3.Text = "EOF: N/A";
            this.tt.SetToolTip(this.label3, "Indicates if your file has EOF data or not.");
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(148, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 15);
            this.label2.TabIndex = 3;
            this.label2.Text = ".Net: N/A";
            this.tt.SetToolTip(this.label2, "Indicates if your file is a .Net file or not.");
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(7, 54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 15);
            this.label1.TabIndex = 2;
            this.label1.Text = "Size: N/A";
            this.tt.SetToolTip(this.label1, "The size of your main file.");
            // 
            // mysticButton1
            // 
            this.mysticButton1.Location = new System.Drawing.Point(312, 23);
            this.mysticButton1.Name = "mysticButton1";
            this.mysticButton1.Size = new System.Drawing.Size(35, 27);
            this.mysticButton1.TabIndex = 1;
            this.mysticButton1.Text = "...";
            this.tt.SetToolTip(this.mysticButton1, "Prompts you to select your main file.");
            this.mysticButton1.Click += new System.EventHandler(this.mysticButton1_Click);
            // 
            // mysticTextBox1
            // 
            this.mysticTextBox1.BackColor = System.Drawing.Color.Transparent;
            this.mysticTextBox1.Location = new System.Drawing.Point(8, 23);
            this.mysticTextBox1.MaxLength = 32767;
            this.mysticTextBox1.Multiline = false;
            this.mysticTextBox1.Name = "mysticTextBox1";
            this.mysticTextBox1.ReadOnly = false;
            this.mysticTextBox1.Size = new System.Drawing.Size(298, 27);
            this.mysticTextBox1.TabIndex = 0;
            this.mysticTextBox1.Text = "Please select your original file!";
            this.mysticTextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tt.SetToolTip(this.mysticTextBox1, "The location of your main file.");
            this.mysticTextBox1.UseSystemPasswordChar = false;
            this.mysticTextBox1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.mysticTextBox1_KeyDown);
            // 
            // mysticCheckBox11
            // 
            this.mysticCheckBox11.Checked = false;
            this.mysticCheckBox11.Location = new System.Drawing.Point(175, 167);
            this.mysticCheckBox11.Name = "mysticCheckBox11";
            this.mysticCheckBox11.Size = new System.Drawing.Size(85, 16);
            this.mysticCheckBox11.TabIndex = 1;
            this.mysticCheckBox11.Text = "File Cloner";
            this.tt.SetToolTip(this.mysticCheckBox11, "Enables or disables file cloner.");
            this.mysticCheckBox11.CheckedChanged += new KazyCrypter.MysticCheckBox.CheckedChangedEventHandler(this.mysticCheckBox11_CheckedChanged);
            // 
            // mysticCheckBox10
            // 
            this.mysticCheckBox10.Checked = false;
            this.mysticCheckBox10.Location = new System.Drawing.Point(160, 13);
            this.mysticCheckBox10.Name = "mysticCheckBox10";
            this.mysticCheckBox10.Size = new System.Drawing.Size(98, 16);
            this.mysticCheckBox10.TabIndex = 0;
            this.mysticCheckBox10.Text = "Icon Changer";
            this.tt.SetToolTip(this.mysticCheckBox10, "Enables or disables the icon changer.");
            this.mysticCheckBox10.CheckedChanged += new KazyCrypter.MysticCheckBox.CheckedChangedEventHandler(this.mysticCheckBox10_CheckedChanged);
            // 
            // mysticCheckBox19
            // 
            this.mysticCheckBox19.Checked = false;
            this.mysticCheckBox19.Location = new System.Drawing.Point(438, 13);
            this.mysticCheckBox19.Name = "mysticCheckBox19";
            this.mysticCheckBox19.Size = new System.Drawing.Size(93, 16);
            this.mysticCheckBox19.TabIndex = 22;
            this.mysticCheckBox19.Text = "Default Info";
            this.tt.SetToolTip(this.mysticCheckBox19, "Leaves the default Assembly Info or lets you specify your own.");
            this.mysticCheckBox19.CheckedChanged += new KazyCrypter.MysticCheckBox.CheckedChangedEventHandler(this.mysticCheckBox19_CheckedChanged);
            // 
            // mysticButton3
            // 
            this.mysticButton3.Location = new System.Drawing.Point(216, 27);
            this.mysticButton3.Name = "mysticButton3";
            this.mysticButton3.Size = new System.Drawing.Size(35, 27);
            this.mysticButton3.TabIndex = 3;
            this.mysticButton3.Text = "...";
            this.tt.SetToolTip(this.mysticButton3, "Select your .exe to clone its informations.");
            this.mysticButton3.Click += new System.EventHandler(this.mysticButton3_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label6.Location = new System.Drawing.Point(198, 126);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(38, 15);
            this.label6.TabIndex = 9;
            this.label6.Text = "0 KBs";
            this.tt.SetToolTip(this.label6, "The size of your new icon.");
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label5.Location = new System.Drawing.Point(4, 126);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(38, 15);
            this.label5.TabIndex = 8;
            this.label5.Text = "0 KBs";
            this.tt.SetToolTip(this.label5, "The size of your original icon.");
            // 
            // mysticButton2
            // 
            this.mysticButton2.Location = new System.Drawing.Point(216, 27);
            this.mysticButton2.Name = "mysticButton2";
            this.mysticButton2.Size = new System.Drawing.Size(35, 27);
            this.mysticButton2.TabIndex = 3;
            this.mysticButton2.Text = "...";
            this.tt.SetToolTip(this.mysticButton2, "Select your icon. It can be a .exe or a .ico file.");
            this.mysticButton2.Click += new System.EventHandler(this.mysticButton2_Click);
            // 
            // mysticRadioButton8
            // 
            this.mysticRadioButton8.Checked = false;
            this.mysticRadioButton8.Enabled = false;
            this.mysticRadioButton8.Location = new System.Drawing.Point(344, 206);
            this.mysticRadioButton8.Name = "mysticRadioButton8";
            this.mysticRadioButton8.Size = new System.Drawing.Size(70, 16);
            this.mysticRadioButton8.TabIndex = 8;
            this.mysticRadioButton8.Text = "Always";
            this.tt.SetToolTip(this.mysticRadioButton8, "Your message will be shown on every startup.");
            // 
            // mysticRadioButton7
            // 
            this.mysticRadioButton7.Checked = true;
            this.mysticRadioButton7.Enabled = false;
            this.mysticRadioButton7.Location = new System.Drawing.Point(344, 181);
            this.mysticRadioButton7.Name = "mysticRadioButton7";
            this.mysticRadioButton7.Size = new System.Drawing.Size(70, 16);
            this.mysticRadioButton7.TabIndex = 7;
            this.mysticRadioButton7.Text = "Once";
            this.tt.SetToolTip(this.mysticRadioButton7, "Your message will only be shown once.");
            // 
            // mysticCheckBox12
            // 
            this.mysticCheckBox12.Checked = false;
            this.mysticCheckBox12.Location = new System.Drawing.Point(4, 6);
            this.mysticCheckBox12.Name = "mysticCheckBox12";
            this.mysticCheckBox12.Size = new System.Drawing.Size(98, 16);
            this.mysticCheckBox12.TabIndex = 1;
            this.mysticCheckBox12.Text = "Fake Message";
            this.tt.SetToolTip(this.mysticCheckBox12, "Enables or disables the Fake Message.");
            this.mysticCheckBox12.CheckedChanged += new KazyCrypter.MysticCheckBox.CheckedChangedEventHandler(this.mysticCheckBox12_CheckedChanged);
            // 
            // mysticCheckBox18
            // 
            this.mysticCheckBox18.Checked = false;
            this.mysticCheckBox18.Location = new System.Drawing.Point(443, 6);
            this.mysticCheckBox18.Name = "mysticCheckBox18";
            this.mysticCheckBox18.Size = new System.Drawing.Size(91, 16);
            this.mysticCheckBox18.TabIndex = 9;
            this.mysticCheckBox18.Text = "File Pumper";
            this.tt.SetToolTip(this.mysticCheckBox18, "Enables or disables File Pumper. Pumping your file might help bypass some AVs.");
            this.mysticCheckBox18.CheckedChanged += new KazyCrypter.MysticCheckBox.CheckedChangedEventHandler(this.mysticCheckBox18_CheckedChanged);
            // 
            // mysticCheckBox17
            // 
            this.mysticCheckBox17.Checked = false;
            this.mysticCheckBox17.Location = new System.Drawing.Point(273, 6);
            this.mysticCheckBox17.Name = "mysticCheckBox17";
            this.mysticCheckBox17.Size = new System.Drawing.Size(128, 16);
            this.mysticCheckBox17.TabIndex = 8;
            this.mysticCheckBox17.Text = "Delayed Execution";
            this.tt.SetToolTip(this.mysticCheckBox17, "Enalbes or disables Delayed Exectuion. MIght help bypassing AVs at runtime.");
            this.mysticCheckBox17.CheckedChanged += new KazyCrypter.MysticCheckBox.CheckedChangedEventHandler(this.mysticCheckBox17_CheckedChanged);
            // 
            // mysticCheckBox16
            // 
            this.mysticCheckBox16.Checked = false;
            this.mysticCheckBox16.Location = new System.Drawing.Point(123, 6);
            this.mysticCheckBox16.Name = "mysticCheckBox16";
            this.mysticCheckBox16.Size = new System.Drawing.Size(106, 16);
            this.mysticCheckBox16.TabIndex = 7;
            this.mysticCheckBox16.Text = "Delete ZoneID";
            this.tt.SetToolTip(this.mysticCheckBox16, "Deletes ZoneID: AFTER the first run it will delete the dialog that ask for permis" +
        "sion to run a file that has been downloaded from the internet.");
            // 
            // mysticTextBox11
            // 
            this.mysticTextBox11.BackColor = System.Drawing.Color.Transparent;
            this.mysticTextBox11.Location = new System.Drawing.Point(8, 25);
            this.mysticTextBox11.MaxLength = 32767;
            this.mysticTextBox11.Multiline = false;
            this.mysticTextBox11.Name = "mysticTextBox11";
            this.mysticTextBox11.ReadOnly = false;
            this.mysticTextBox11.Size = new System.Drawing.Size(175, 27);
            this.mysticTextBox11.TabIndex = 0;
            this.mysticTextBox11.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tt.SetToolTip(this.mysticTextBox11, "CMD Arguments to pass to your file.");
            this.mysticTextBox11.UseSystemPasswordChar = false;
            // 
            // mysticTextBox10
            // 
            this.mysticTextBox10.BackColor = System.Drawing.Color.Transparent;
            this.mysticTextBox10.Location = new System.Drawing.Point(8, 25);
            this.mysticTextBox10.MaxLength = 32767;
            this.mysticTextBox10.Multiline = false;
            this.mysticTextBox10.Name = "mysticTextBox10";
            this.mysticTextBox10.ReadOnly = false;
            this.mysticTextBox10.Size = new System.Drawing.Size(175, 27);
            this.mysticTextBox10.TabIndex = 0;
            this.mysticTextBox10.Text = "0";
            this.mysticTextBox10.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tt.SetToolTip(this.mysticTextBox10, "File Pump in KBs. 1024 = 1MB");
            this.mysticTextBox10.UseSystemPasswordChar = false;
            // 
            // mysticTextBox9
            // 
            this.mysticTextBox9.BackColor = System.Drawing.Color.Transparent;
            this.mysticTextBox9.Location = new System.Drawing.Point(8, 25);
            this.mysticTextBox9.MaxLength = 32767;
            this.mysticTextBox9.Multiline = false;
            this.mysticTextBox9.Name = "mysticTextBox9";
            this.mysticTextBox9.ReadOnly = false;
            this.mysticTextBox9.Size = new System.Drawing.Size(175, 27);
            this.mysticTextBox9.TabIndex = 0;
            this.mysticTextBox9.Text = "0";
            this.mysticTextBox9.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tt.SetToolTip(this.mysticTextBox9, "Dleay amoint in Secs.");
            this.mysticTextBox9.UseSystemPasswordChar = false;
            // 
            // mysticCheckBox15
            // 
            this.mysticCheckBox15.Checked = false;
            this.mysticCheckBox15.Location = new System.Drawing.Point(269, 172);
            this.mysticCheckBox15.Name = "mysticCheckBox15";
            this.mysticCheckBox15.Size = new System.Drawing.Size(53, 16);
            this.mysticCheckBox15.TabIndex = 6;
            this.mysticCheckBox15.Text = "Melt";
            this.tt.SetToolTip(this.mysticCheckBox15, "Enables or disables melt. If enabled your original file will disappear.");
            // 
            // comboBox3
            // 
            this.comboBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(37)))), ((int)(((byte)(44)))));
            this.comboBox3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(153)))), ((int)(((byte)(228)))));
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "CurrentFolder"});
            this.comboBox3.Location = new System.Drawing.Point(7, 167);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(170, 23);
            this.comboBox3.TabIndex = 5;
            this.tt.SetToolTip(this.comboBox3, "Location of your startup");
            // 
            // mysticTextBox8
            // 
            this.mysticTextBox8.BackColor = System.Drawing.Color.Transparent;
            this.mysticTextBox8.Location = new System.Drawing.Point(7, 27);
            this.mysticTextBox8.MaxLength = 32767;
            this.mysticTextBox8.Multiline = false;
            this.mysticTextBox8.Name = "mysticTextBox8";
            this.mysticTextBox8.ReadOnly = false;
            this.mysticTextBox8.Size = new System.Drawing.Size(300, 27);
            this.mysticTextBox8.TabIndex = 2;
            this.mysticTextBox8.Text = "Folder\\windows.exe";
            this.mysticTextBox8.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tt.SetToolTip(this.mysticTextBox8, "The folder and filename for your startup. Format: Folder\\Folder\\Folder...\\filenam" +
        "e.ext");
            this.mysticTextBox8.UseSystemPasswordChar = false;
            // 
            // mysticTextBox7
            // 
            this.mysticTextBox7.BackColor = System.Drawing.Color.Transparent;
            this.mysticTextBox7.Location = new System.Drawing.Point(7, 27);
            this.mysticTextBox7.MaxLength = 32767;
            this.mysticTextBox7.Multiline = false;
            this.mysticTextBox7.Name = "mysticTextBox7";
            this.mysticTextBox7.ReadOnly = false;
            this.mysticTextBox7.Size = new System.Drawing.Size(300, 27);
            this.mysticTextBox7.TabIndex = 2;
            this.mysticTextBox7.Text = "Update";
            this.mysticTextBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tt.SetToolTip(this.mysticTextBox7, "The entry name for startup.");
            this.mysticTextBox7.UseSystemPasswordChar = false;
            // 
            // mysticCheckBox14
            // 
            this.mysticCheckBox14.Checked = false;
            this.mysticCheckBox14.Location = new System.Drawing.Point(4, 6);
            this.mysticCheckBox14.Name = "mysticCheckBox14";
            this.mysticCheckBox14.Size = new System.Drawing.Size(70, 16);
            this.mysticCheckBox14.TabIndex = 2;
            this.mysticCheckBox14.Text = "Startup";
            this.tt.SetToolTip(this.mysticCheckBox14, "Enables or disables startup.");
            this.mysticCheckBox14.CheckedChanged += new KazyCrypter.MysticCheckBox.CheckedChangedEventHandler(this.mysticCheckBox14_CheckedChanged);
            // 
            // mysticCheckBox28
            // 
            this.mysticCheckBox28.Checked = false;
            this.mysticCheckBox28.Location = new System.Drawing.Point(330, 72);
            this.mysticCheckBox28.Name = "mysticCheckBox28";
            this.mysticCheckBox28.Size = new System.Drawing.Size(58, 16);
            this.mysticCheckBox28.TabIndex = 13;
            this.mysticCheckBox28.Text = "Enable";
            this.tt.SetToolTip(this.mysticCheckBox28, "Changes the creation date of your file. Neends startup enabled.");
            this.mysticCheckBox28.CheckedChanged += new KazyCrypter.MysticCheckBox.CheckedChangedEventHandler(this.mysticCheckBox28_CheckedChanged);
            // 
            // mysticRadioButton10
            // 
            this.mysticRadioButton10.Checked = false;
            this.mysticRadioButton10.Enabled = false;
            this.mysticRadioButton10.Location = new System.Drawing.Point(483, 138);
            this.mysticRadioButton10.Name = "mysticRadioButton10";
            this.mysticRadioButton10.Size = new System.Drawing.Size(51, 16);
            this.mysticRadioButton10.TabIndex = 10;
            this.mysticRadioButton10.Text = "x64";
            this.tt.SetToolTip(this.mysticRadioButton10, "The file you want to steal from is based on x64 arhitecture.");
            // 
            // mysticRadioButton9
            // 
            this.mysticRadioButton9.Checked = true;
            this.mysticRadioButton9.Enabled = false;
            this.mysticRadioButton9.Location = new System.Drawing.Point(428, 139);
            this.mysticRadioButton9.Name = "mysticRadioButton9";
            this.mysticRadioButton9.Size = new System.Drawing.Size(51, 16);
            this.mysticRadioButton9.TabIndex = 9;
            this.mysticRadioButton9.Text = "x86";
            this.tt.SetToolTip(this.mysticRadioButton9, "The file you want to steal from is based on x86 arhitecture.");
            // 
            // mysticCheckBox27
            // 
            this.mysticCheckBox27.Checked = false;
            this.mysticCheckBox27.Location = new System.Drawing.Point(210, 139);
            this.mysticCheckBox27.Name = "mysticCheckBox27";
            this.mysticCheckBox27.Size = new System.Drawing.Size(136, 16);
            this.mysticCheckBox27.TabIndex = 8;
            this.mysticCheckBox27.Text = "Signature Stealer";
            this.tt.SetToolTip(this.mysticCheckBox27, "Enables or disables the signature stealer. MIght help bypass some AVs.");
            this.mysticCheckBox27.CheckedChanged += new KazyCrypter.MysticCheckBox.CheckedChangedEventHandler(this.mysticCheckBox27_CheckedChanged);
            // 
            // mysticButton7
            // 
            this.mysticButton7.Location = new System.Drawing.Point(282, 27);
            this.mysticButton7.Name = "mysticButton7";
            this.mysticButton7.Size = new System.Drawing.Size(35, 27);
            this.mysticButton7.TabIndex = 9;
            this.mysticButton7.Text = "...";
            this.tt.SetToolTip(this.mysticButton7, "Select your file to steal the signature from.");
            this.mysticButton7.Click += new System.EventHandler(this.mysticButton7_Click);
            // 
            // mysticButton6
            // 
            this.mysticButton6.Location = new System.Drawing.Point(31, 75);
            this.mysticButton6.Name = "mysticButton6";
            this.mysticButton6.Size = new System.Drawing.Size(80, 29);
            this.mysticButton6.TabIndex = 1;
            this.mysticButton6.Text = "Save";
            this.tt.SetToolTip(this.mysticButton6, "Saves the current settings to a .dat file.");
            this.mysticButton6.Click += new System.EventHandler(this.mysticButton6_Click);
            // 
            // mysticButton5
            // 
            this.mysticButton5.Location = new System.Drawing.Point(31, 34);
            this.mysticButton5.Name = "mysticButton5";
            this.mysticButton5.Size = new System.Drawing.Size(80, 29);
            this.mysticButton5.TabIndex = 0;
            this.mysticButton5.Text = "Load";
            this.tt.SetToolTip(this.mysticButton5, "Loads a saved profile.");
            this.mysticButton5.Click += new System.EventHandler(this.mysticButton5_Click);
            // 
            // mysticCheckBox26
            // 
            this.mysticCheckBox26.Checked = false;
            this.mysticCheckBox26.Location = new System.Drawing.Point(87, 26);
            this.mysticCheckBox26.Name = "mysticCheckBox26";
            this.mysticCheckBox26.Size = new System.Drawing.Size(88, 16);
            this.mysticCheckBox26.TabIndex = 1;
            this.mysticCheckBox26.Text = "Hide Folder";
            this.tt.SetToolTip(this.mysticCheckBox26, "Sets System and Hidden attributes to your folder.");
            // 
            // mysticCheckBox25
            // 
            this.mysticCheckBox25.Checked = false;
            this.mysticCheckBox25.Location = new System.Drawing.Point(6, 26);
            this.mysticCheckBox25.Name = "mysticCheckBox25";
            this.mysticCheckBox25.Size = new System.Drawing.Size(75, 16);
            this.mysticCheckBox25.TabIndex = 0;
            this.mysticCheckBox25.Text = "Hide File";
            this.tt.SetToolTip(this.mysticCheckBox25, "Sets System and Hidden attributes to your file.");
            // 
            // mysticCheckBox24
            // 
            this.mysticCheckBox24.Checked = false;
            this.mysticCheckBox24.Location = new System.Drawing.Point(4, 139);
            this.mysticCheckBox24.Name = "mysticCheckBox24";
            this.mysticCheckBox24.Size = new System.Drawing.Size(136, 16);
            this.mysticCheckBox24.TabIndex = 4;
            this.mysticCheckBox24.Text = "Extension Spoofer";
            this.tt.SetToolTip(this.mysticCheckBox24, "Enables or disables the extension spoofer.");
            this.mysticCheckBox24.CheckedChanged += new KazyCrypter.MysticCheckBox.CheckedChangedEventHandler(this.mysticCheckBox24_CheckedChanged);
            // 
            // mysticCheckBox23
            // 
            this.mysticCheckBox23.Checked = false;
            this.mysticCheckBox23.Location = new System.Drawing.Point(8, 92);
            this.mysticCheckBox23.Name = "mysticCheckBox23";
            this.mysticCheckBox23.Size = new System.Drawing.Size(136, 16);
            this.mysticCheckBox23.TabIndex = 3;
            this.mysticCheckBox23.Text = "BSOD on terminate";
            this.tt.SetToolTip(this.mysticCheckBox23, "Will cause crashing when your process is closed. NEEDS admin rights.");
            // 
            // mysticCheckBox22
            // 
            this.mysticCheckBox22.Checked = false;
            this.mysticCheckBox22.Location = new System.Drawing.Point(8, 70);
            this.mysticCheckBox22.Name = "mysticCheckBox22";
            this.mysticCheckBox22.Size = new System.Drawing.Size(136, 16);
            this.mysticCheckBox22.TabIndex = 2;
            this.mysticCheckBox22.Text = "Elevated Process";
            this.tt.SetToolTip(this.mysticCheckBox22, "Normal uses won\'t be able to close your process. DOESN\'T grant admin rights.");
            // 
            // mysticCheckBox21
            // 
            this.mysticCheckBox21.Checked = false;
            this.mysticCheckBox21.Location = new System.Drawing.Point(8, 48);
            this.mysticCheckBox21.Name = "mysticCheckBox21";
            this.mysticCheckBox21.Size = new System.Drawing.Size(136, 16);
            this.mysticCheckBox21.TabIndex = 1;
            this.mysticCheckBox21.Text = "Startup Persistence";
            this.tt.SetToolTip(this.mysticCheckBox21, "Your startup entry will come back if it gets deleted.");
            // 
            // mysticCheckBox20
            // 
            this.mysticCheckBox20.Checked = false;
            this.mysticCheckBox20.Location = new System.Drawing.Point(8, 26);
            this.mysticCheckBox20.Name = "mysticCheckBox20";
            this.mysticCheckBox20.Size = new System.Drawing.Size(136, 16);
            this.mysticCheckBox20.TabIndex = 0;
            this.mysticCheckBox20.Text = "Process Persistence";
            this.tt.SetToolTip(this.mysticCheckBox20, "Your process will come back if it gets closed.");
            // 
            // mysticButton10
            // 
            this.mysticButton10.Location = new System.Drawing.Point(4, 193);
            this.mysticButton10.Name = "mysticButton10";
            this.mysticButton10.Size = new System.Drawing.Size(90, 35);
            this.mysticButton10.TabIndex = 6;
            this.mysticButton10.Text = "Scan";
            this.tt.SetToolTip(this.mysticButton10, "Please try to scan again if it failed.");
            this.mysticButton10.Click += new System.EventHandler(this.mysticButton10_Click);
            // 
            // mysticCheckBox29
            // 
            this.mysticCheckBox29.Checked = false;
            this.mysticCheckBox29.Location = new System.Drawing.Point(470, 91);
            this.mysticCheckBox29.Name = "mysticCheckBox29";
            this.mysticCheckBox29.Size = new System.Drawing.Size(61, 16);
            this.mysticCheckBox29.TabIndex = 6;
            this.mysticCheckBox29.Text = "Enable";
            this.tt.SetToolTip(this.mysticCheckBox29, "Enables or disables the usage of a private stub.");
            this.mysticCheckBox29.CheckedChanged += new KazyCrypter.MysticCheckBox.CheckedChangedEventHandler(this.mysticCheckBox29_CheckedChanged);
            // 
            // mysticButton14
            // 
            this.mysticButton14.Location = new System.Drawing.Point(159, 26);
            this.mysticButton14.Name = "mysticButton14";
            this.mysticButton14.Size = new System.Drawing.Size(35, 27);
            this.mysticButton14.TabIndex = 2;
            this.mysticButton14.Text = "...";
            this.tt.SetToolTip(this.mysticButton14, "Select your private stub dll.");
            this.mysticButton14.Click += new System.EventHandler(this.mysticButton14_Click);
            // 
            // comboBox4
            // 
            this.comboBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(37)))), ((int)(((byte)(44)))));
            this.comboBox4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(153)))), ((int)(((byte)(228)))));
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Items.AddRange(new object[] {
            ".Net v2.0",
            ".Net v3.5"});
            this.comboBox4.Location = new System.Drawing.Point(4, 25);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(112, 23);
            this.comboBox4.TabIndex = 5;
            this.tt.SetToolTip(this.comboBox4, "Select your .net version. Might be used to solve compatibility issues.");
            // 
            // mysticButton12
            // 
            this.mysticButton12.Location = new System.Drawing.Point(121, 17);
            this.mysticButton12.Name = "mysticButton12";
            this.mysticButton12.Size = new System.Drawing.Size(73, 26);
            this.mysticButton12.TabIndex = 4;
            this.mysticButton12.Text = "Check";
            this.tt.SetToolTip(this.mysticButton12, "Checks for a new CryptEngine. It is done automatically upon crypting.");
            this.mysticButton12.Click += new System.EventHandler(this.mysticButton12_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.DefaultExt = "exe";
            this.openFileDialog1.Filter = "Executables(*.exe)|*.exe";
            this.openFileDialog1.Title = "Main file";
            // 
            // openFileDialog2
            // 
            this.openFileDialog2.Filter = "Executable,Icon File|*.exe;*.ico";
            this.openFileDialog2.Title = "Select your Icon";
            // 
            // openFileDialog3
            // 
            this.openFileDialog3.DefaultExt = "exe";
            this.openFileDialog3.Filter = "Executables(*.exe)|*.exe";
            this.openFileDialog3.Title = "File to clone";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(36)))), ((int)(((byte)(44)))));
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addFileToolStripMenuItem,
            this.addUrlToolStripMenuItem,
            this.toolStripSeparator1,
            this.locationToolStripMenuItem,
            this.runToolStripMenuItem,
            this.toolStripMenuItem1,
            this.toolStripSeparator2,
            this.removeToolStripMenuItem,
            this.removeAllToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.ShowImageMargin = false;
            this.contextMenuStrip1.Size = new System.Drawing.Size(110, 170);
            // 
            // addFileToolStripMenuItem
            // 
            this.addFileToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.addFileToolStripMenuItem.Name = "addFileToolStripMenuItem";
            this.addFileToolStripMenuItem.Size = new System.Drawing.Size(109, 22);
            this.addFileToolStripMenuItem.Text = "Add File";
            this.addFileToolStripMenuItem.ToolTipText = "Adds a file";
            this.addFileToolStripMenuItem.Click += new System.EventHandler(this.addFileToolStripMenuItem_Click);
            // 
            // addUrlToolStripMenuItem
            // 
            this.addUrlToolStripMenuItem.Checked = true;
            this.addUrlToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.addUrlToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.addUrlToolStripMenuItem.Name = "addUrlToolStripMenuItem";
            this.addUrlToolStripMenuItem.Size = new System.Drawing.Size(109, 22);
            this.addUrlToolStripMenuItem.Text = "Add Url";
            this.addUrlToolStripMenuItem.ToolTipText = "Adds an url. Must be a direct link.";
            this.addUrlToolStripMenuItem.Click += new System.EventHandler(this.addUrlToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(106, 6);
            // 
            // locationToolStripMenuItem
            // 
            this.locationToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(36)))), ((int)(((byte)(44)))));
            this.locationToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.currentFolderToolStripMenuItem});
            this.locationToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.locationToolStripMenuItem.Name = "locationToolStripMenuItem";
            this.locationToolStripMenuItem.Size = new System.Drawing.Size(109, 22);
            this.locationToolStripMenuItem.Text = "Location";
            this.locationToolStripMenuItem.ToolTipText = "Changes the location.";
            // 
            // currentFolderToolStripMenuItem
            // 
            this.currentFolderToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(36)))), ((int)(((byte)(44)))));
            this.currentFolderToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.currentFolderToolStripMenuItem.Name = "currentFolderToolStripMenuItem";
            this.currentFolderToolStripMenuItem.Size = new System.Drawing.Size(147, 22);
            this.currentFolderToolStripMenuItem.Text = "CurrentFolder";
            this.currentFolderToolStripMenuItem.Click += new System.EventHandler(this.Item_Click);
            // 
            // runToolStripMenuItem
            // 
            this.runToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(36)))), ((int)(((byte)(44)))));
            this.runToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.onceToolStripMenuItem,
            this.alwaysToolStripMenuItem,
            this.neverToolStripMenuItem});
            this.runToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.runToolStripMenuItem.Name = "runToolStripMenuItem";
            this.runToolStripMenuItem.Size = new System.Drawing.Size(109, 22);
            this.runToolStripMenuItem.Text = "Run";
            this.runToolStripMenuItem.ToolTipText = "Changes the run mode.";
            // 
            // onceToolStripMenuItem
            // 
            this.onceToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(36)))), ((int)(((byte)(44)))));
            this.onceToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.onceToolStripMenuItem.Name = "onceToolStripMenuItem";
            this.onceToolStripMenuItem.Size = new System.Drawing.Size(111, 22);
            this.onceToolStripMenuItem.Text = "Once";
            this.onceToolStripMenuItem.ToolTipText = "Your file will only run once. Needs startup enabled.";
            this.onceToolStripMenuItem.Click += new System.EventHandler(this.onceToolStripMenuItem_Click);
            // 
            // alwaysToolStripMenuItem
            // 
            this.alwaysToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(36)))), ((int)(((byte)(44)))));
            this.alwaysToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.alwaysToolStripMenuItem.Name = "alwaysToolStripMenuItem";
            this.alwaysToolStripMenuItem.Size = new System.Drawing.Size(111, 22);
            this.alwaysToolStripMenuItem.Text = "Always";
            this.alwaysToolStripMenuItem.ToolTipText = "Your file will run on every startup.";
            this.alwaysToolStripMenuItem.Click += new System.EventHandler(this.alwaysToolStripMenuItem_Click);
            // 
            // neverToolStripMenuItem
            // 
            this.neverToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(36)))), ((int)(((byte)(44)))));
            this.neverToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.neverToolStripMenuItem.Name = "neverToolStripMenuItem";
            this.neverToolStripMenuItem.Size = new System.Drawing.Size(111, 22);
            this.neverToolStripMenuItem.Text = "Never";
            this.neverToolStripMenuItem.ToolTipText = "Your file will never run. Good for dependencies.";
            this.neverToolStripMenuItem.Click += new System.EventHandler(this.neverToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.ForeColor = System.Drawing.Color.White;
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(109, 22);
            this.toolStripMenuItem1.Text = "Set Dealy";
            this.toolStripMenuItem1.ToolTipText = "Sets the delay";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(106, 6);
            // 
            // removeToolStripMenuItem
            // 
            this.removeToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.removeToolStripMenuItem.Name = "removeToolStripMenuItem";
            this.removeToolStripMenuItem.Size = new System.Drawing.Size(109, 22);
            this.removeToolStripMenuItem.Text = "Remove";
            this.removeToolStripMenuItem.Click += new System.EventHandler(this.removeToolStripMenuItem_Click);
            // 
            // removeAllToolStripMenuItem
            // 
            this.removeAllToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.removeAllToolStripMenuItem.Name = "removeAllToolStripMenuItem";
            this.removeAllToolStripMenuItem.Size = new System.Drawing.Size(109, 22);
            this.removeAllToolStripMenuItem.Text = "Remove All";
            this.removeAllToolStripMenuItem.Click += new System.EventHandler(this.removeAllToolStripMenuItem_Click);
            // 
            // openFileDialog4
            // 
            this.openFileDialog4.Filter = "Any files|*.*";
            this.openFileDialog4.Title = "File to bind";
            // 
            // openFileDialog5
            // 
            this.openFileDialog5.Filter = "Any file|*.exe";
            this.openFileDialog5.Title = "File to scan";
            // 
            // openFileDialog6
            // 
            this.openFileDialog6.Filter = "DLL files(*.dll)|*.dll";
            this.openFileDialog6.Title = "Private stub";
            // 
            // openFileDialog7
            // 
            this.openFileDialog7.DefaultExt = "exe";
            this.openFileDialog7.Filter = "Executables(*.exe)|*.exe";
            this.openFileDialog7.Title = "Signature Stealer";
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.Filter = "Executable(*.exe)|*.exe|Scr File(*.scr)|*.scr|Bat File(*.bat)|*.bat|Pif File(*.pi" +
    "f)|*.pif|Com FIle(*.com)|*.com";
            this.saveFileDialog1.Title = "Save Location";
            // 
            // saveFileDialog2
            // 
            this.saveFileDialog2.Filter = "Dat File(*.dat)|*.dat";
            this.saveFileDialog2.Title = "Profile Location";
            // 
            // openFileDialog8
            // 
            this.openFileDialog8.Filter = "Dat File(*.dat)|*.dat";
            this.openFileDialog8.Title = "Profile Location";
            // 
            // mysticTheme1
            // 
            this.mysticTheme1.Controls.Add(this.panel1);
            this.mysticTheme1.Controls.Add(this.statusStrip1);
            this.mysticTheme1.Controls.Add(this.mysticMini1);
            this.mysticTheme1.Controls.Add(this.mysticClose1);
            this.mysticTheme1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mysticTheme1.Location = new System.Drawing.Point(0, 0);
            this.mysticTheme1.Name = "mysticTheme1";
            this.mysticTheme1.Size = new System.Drawing.Size(547, 315);
            this.mysticTheme1.TabIndex = 0;
            this.mysticTheme1.Text = "KazyCrypter v4";
            this.mysticTheme1.Click += new System.EventHandler(this.mysticTheme1_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Controls.Add(this.tabControlEX1);
            this.panel1.ForeColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(0, 35);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(547, 257);
            this.panel1.TabIndex = 4;
            // 
            // tabControlEX1
            // 
            this.tabControlEX1.Appearance = Dotnetrix.Controls.TabAppearanceEX.Button;
            this.tabControlEX1.BackColor = System.Drawing.Color.Transparent;
            this.tabControlEX1.Controls.Add(this.tabPageEX1);
            this.tabControlEX1.Controls.Add(this.tabPageEX2);
            this.tabControlEX1.Controls.Add(this.tabPageEX3);
            this.tabControlEX1.Controls.Add(this.tabPageEX4);
            this.tabControlEX1.Controls.Add(this.tabPageEX6);
            this.tabControlEX1.Controls.Add(this.tabPageEX10);
            this.tabControlEX1.Controls.Add(this.tabPageEX8);
            this.tabControlEX1.Controls.Add(this.tabPageEX9);
            this.tabControlEX1.Controls.Add(this.tabPageEX7);
            this.tabControlEX1.Controls.Add(this.tabPageEX5);
            this.tabControlEX1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlEX1.FlatBorderColor = System.Drawing.Color.White;
            this.tabControlEX1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tabControlEX1.Location = new System.Drawing.Point(0, 0);
            this.tabControlEX1.Name = "tabControlEX1";
            this.tabControlEX1.SelectedIndex = 8;
            this.tabControlEX1.SelectedTabColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(88)))), ((int)(((byte)(139)))));
            this.tabControlEX1.SelectedTabFontStyle = System.Drawing.FontStyle.Bold;
            this.tabControlEX1.Size = new System.Drawing.Size(547, 257);
            this.tabControlEX1.TabColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(29)))), ((int)(((byte)(35)))));
            this.tabControlEX1.TabIndex = 0;
            this.tabControlEX1.UseVisualStyles = false;
            // 
            // tabPageEX1
            // 
            this.tabPageEX1.BackColor = System.Drawing.Color.Transparent;
            this.tabPageEX1.Controls.Add(this.mysticGroupBox7);
            this.tabPageEX1.Controls.Add(this.mysticGroupBox6);
            this.tabPageEX1.Controls.Add(this.mysticGroupBox5);
            this.tabPageEX1.Controls.Add(this.mysticGroupBox3);
            this.tabPageEX1.Controls.Add(this.mysticGroupBox1);
            this.tabPageEX1.Location = new System.Drawing.Point(4, 25);
            this.tabPageEX1.Name = "tabPageEX1";
            this.tabPageEX1.Size = new System.Drawing.Size(539, 228);
            this.tabPageEX1.TabIndex = 0;
            this.tabPageEX1.Text = "Main";
            // 
            // mysticGroupBox7
            // 
            this.mysticGroupBox7.Controls.Add(this.mysticCheckBox13);
            this.mysticGroupBox7.Location = new System.Drawing.Point(370, 174);
            this.mysticGroupBox7.Name = "mysticGroupBox7";
            this.mysticGroupBox7.Size = new System.Drawing.Size(164, 53);
            this.mysticGroupBox7.TabIndex = 9;
            this.mysticGroupBox7.Text = "Manifest Settings";
            // 
            // mysticGroupBox6
            // 
            this.mysticGroupBox6.Controls.Add(this.mysticCheckBox6);
            this.mysticGroupBox6.Controls.Add(this.mysticCheckBox7);
            this.mysticGroupBox6.Controls.Add(this.mysticCheckBox8);
            this.mysticGroupBox6.Controls.Add(this.mysticCheckBox9);
            this.mysticGroupBox6.Location = new System.Drawing.Point(370, 93);
            this.mysticGroupBox6.Name = "mysticGroupBox6";
            this.mysticGroupBox6.Size = new System.Drawing.Size(164, 73);
            this.mysticGroupBox6.TabIndex = 8;
            this.mysticGroupBox6.Text = "Compression";
            // 
            // mysticGroupBox5
            // 
            this.mysticGroupBox5.Controls.Add(this.mysticCheckBox5);
            this.mysticGroupBox5.Controls.Add(this.mysticCheckBox4);
            this.mysticGroupBox5.Controls.Add(this.mysticCheckBox3);
            this.mysticGroupBox5.Controls.Add(this.mysticCheckBox2);
            this.mysticGroupBox5.Location = new System.Drawing.Point(370, 8);
            this.mysticGroupBox5.Name = "mysticGroupBox5";
            this.mysticGroupBox5.Size = new System.Drawing.Size(164, 73);
            this.mysticGroupBox5.TabIndex = 7;
            this.mysticGroupBox5.Text = "Antis";
            // 
            // mysticGroupBox3
            // 
            this.mysticGroupBox3.Controls.Add(this.mysticGroupBox4);
            this.mysticGroupBox3.Controls.Add(this.mysticCheckBox1);
            this.mysticGroupBox3.Location = new System.Drawing.Point(4, 93);
            this.mysticGroupBox3.Name = "mysticGroupBox3";
            this.mysticGroupBox3.Size = new System.Drawing.Size(356, 134);
            this.mysticGroupBox3.TabIndex = 6;
            this.mysticGroupBox3.Text = "Injection";
            // 
            // mysticGroupBox4
            // 
            this.mysticGroupBox4.Controls.Add(this.mysticTextBox2);
            this.mysticGroupBox4.Controls.Add(this.mysticRadioButton6);
            this.mysticGroupBox4.Controls.Add(this.mysticRadioButton5);
            this.mysticGroupBox4.Controls.Add(this.mysticRadioButton4);
            this.mysticGroupBox4.Controls.Add(this.mysticRadioButton3);
            this.mysticGroupBox4.Controls.Add(this.mysticRadioButton2);
            this.mysticGroupBox4.Controls.Add(this.mysticRadioButton1);
            this.mysticGroupBox4.Location = new System.Drawing.Point(7, 32);
            this.mysticGroupBox4.Name = "mysticGroupBox4";
            this.mysticGroupBox4.Size = new System.Drawing.Size(339, 92);
            this.mysticGroupBox4.TabIndex = 1;
            this.mysticGroupBox4.Text = "Injection Location - Enabled";
            // 
            // mysticTextBox2
            // 
            this.mysticTextBox2.BackColor = System.Drawing.Color.Transparent;
            this.mysticTextBox2.Enabled = false;
            this.mysticTextBox2.Location = new System.Drawing.Point(87, 57);
            this.mysticTextBox2.MaxLength = 32767;
            this.mysticTextBox2.Multiline = false;
            this.mysticTextBox2.Name = "mysticTextBox2";
            this.mysticTextBox2.ReadOnly = false;
            this.mysticTextBox2.Size = new System.Drawing.Size(242, 27);
            this.mysticTextBox2.TabIndex = 6;
            this.mysticTextBox2.Text = "windows.exe";
            this.mysticTextBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.mysticTextBox2.UseSystemPasswordChar = false;
            // 
            // mysticGroupBox1
            // 
            this.mysticGroupBox1.Controls.Add(this.label3);
            this.mysticGroupBox1.Controls.Add(this.label2);
            this.mysticGroupBox1.Controls.Add(this.label1);
            this.mysticGroupBox1.Controls.Add(this.mysticButton1);
            this.mysticGroupBox1.Controls.Add(this.mysticTextBox1);
            this.mysticGroupBox1.Location = new System.Drawing.Point(4, 8);
            this.mysticGroupBox1.Name = "mysticGroupBox1";
            this.mysticGroupBox1.Size = new System.Drawing.Size(356, 73);
            this.mysticGroupBox1.TabIndex = 5;
            this.mysticGroupBox1.Text = "Main File";
            // 
            // tabPageEX2
            // 
            this.tabPageEX2.Controls.Add(this.mysticCheckBox11);
            this.tabPageEX2.Controls.Add(this.mysticCheckBox19);
            this.tabPageEX2.Controls.Add(this.mysticCheckBox10);
            this.tabPageEX2.Controls.Add(this.mysticGroupBox20);
            this.tabPageEX2.Controls.Add(this.mysticGroupBox8);
            this.tabPageEX2.Controls.Add(this.mysticGroupBox2);
            this.tabPageEX2.Location = new System.Drawing.Point(4, 25);
            this.tabPageEX2.Name = "tabPageEX2";
            this.tabPageEX2.Size = new System.Drawing.Size(539, 228);
            this.tabPageEX2.TabIndex = 1;
            this.tabPageEX2.Text = "Info";
            // 
            // mysticGroupBox20
            // 
            this.mysticGroupBox20.Controls.Add(this.vScrollBar1);
            this.mysticGroupBox20.Controls.Add(this.fversion4);
            this.mysticGroupBox20.Controls.Add(this.fversion3);
            this.mysticGroupBox20.Controls.Add(this.fversion2);
            this.mysticGroupBox20.Controls.Add(this.fversion1);
            this.mysticGroupBox20.Controls.Add(this.version4);
            this.mysticGroupBox20.Controls.Add(this.version3);
            this.mysticGroupBox20.Controls.Add(this.version2);
            this.mysticGroupBox20.Controls.Add(this.version1);
            this.mysticGroupBox20.Controls.Add(this.label12);
            this.mysticGroupBox20.Controls.Add(this.label11);
            this.mysticGroupBox20.Controls.Add(this.descriptionbox);
            this.mysticGroupBox20.Controls.Add(this.label10);
            this.mysticGroupBox20.Controls.Add(this.copyrightbox);
            this.mysticGroupBox20.Controls.Add(this.label9);
            this.mysticGroupBox20.Controls.Add(this.productbox);
            this.mysticGroupBox20.Controls.Add(this.label8);
            this.mysticGroupBox20.Controls.Add(this.titlebox);
            this.mysticGroupBox20.Controls.Add(this.label7);
            this.mysticGroupBox20.Location = new System.Drawing.Point(269, 8);
            this.mysticGroupBox20.Name = "mysticGroupBox20";
            this.mysticGroupBox20.Size = new System.Drawing.Size(265, 219);
            this.mysticGroupBox20.TabIndex = 3;
            this.mysticGroupBox20.Text = "Assembly Informations";
            // 
            // vScrollBar1
            // 
            this.vScrollBar1.Location = new System.Drawing.Point(231, 25);
            this.vScrollBar1.Name = "vScrollBar1";
            this.vScrollBar1.Size = new System.Drawing.Size(26, 188);
            this.vScrollBar1.TabIndex = 23;
            this.vScrollBar1.Scroll += new System.Windows.Forms.ScrollEventHandler(this.vScrollBar1_Scroll);
            // 
            // fversion4
            // 
            this.fversion4.BackColor = System.Drawing.Color.Transparent;
            this.fversion4.Location = new System.Drawing.Point(193, 186);
            this.fversion4.MaxLength = 32767;
            this.fversion4.Multiline = false;
            this.fversion4.Name = "fversion4";
            this.fversion4.ReadOnly = false;
            this.fversion4.Size = new System.Drawing.Size(31, 27);
            this.fversion4.TabIndex = 20;
            this.fversion4.Text = "0";
            this.fversion4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.fversion4.UseSystemPasswordChar = false;
            // 
            // fversion3
            // 
            this.fversion3.BackColor = System.Drawing.Color.Transparent;
            this.fversion3.Location = new System.Drawing.Point(155, 186);
            this.fversion3.MaxLength = 32767;
            this.fversion3.Multiline = false;
            this.fversion3.Name = "fversion3";
            this.fversion3.ReadOnly = false;
            this.fversion3.Size = new System.Drawing.Size(31, 27);
            this.fversion3.TabIndex = 19;
            this.fversion3.Text = "0";
            this.fversion3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.fversion3.UseSystemPasswordChar = false;
            // 
            // fversion2
            // 
            this.fversion2.BackColor = System.Drawing.Color.Transparent;
            this.fversion2.Location = new System.Drawing.Point(118, 186);
            this.fversion2.MaxLength = 32767;
            this.fversion2.Multiline = false;
            this.fversion2.Name = "fversion2";
            this.fversion2.ReadOnly = false;
            this.fversion2.Size = new System.Drawing.Size(31, 27);
            this.fversion2.TabIndex = 18;
            this.fversion2.Text = "0";
            this.fversion2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.fversion2.UseSystemPasswordChar = false;
            // 
            // fversion1
            // 
            this.fversion1.BackColor = System.Drawing.Color.Transparent;
            this.fversion1.Location = new System.Drawing.Point(80, 186);
            this.fversion1.MaxLength = 32767;
            this.fversion1.Multiline = false;
            this.fversion1.Name = "fversion1";
            this.fversion1.ReadOnly = false;
            this.fversion1.Size = new System.Drawing.Size(31, 27);
            this.fversion1.TabIndex = 17;
            this.fversion1.Text = "1";
            this.fversion1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.fversion1.UseSystemPasswordChar = false;
            // 
            // version4
            // 
            this.version4.BackColor = System.Drawing.Color.Transparent;
            this.version4.Location = new System.Drawing.Point(193, 155);
            this.version4.MaxLength = 32767;
            this.version4.Multiline = false;
            this.version4.Name = "version4";
            this.version4.ReadOnly = false;
            this.version4.Size = new System.Drawing.Size(31, 27);
            this.version4.TabIndex = 16;
            this.version4.Text = "0";
            this.version4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.version4.UseSystemPasswordChar = false;
            // 
            // version3
            // 
            this.version3.BackColor = System.Drawing.Color.Transparent;
            this.version3.Location = new System.Drawing.Point(155, 155);
            this.version3.MaxLength = 32767;
            this.version3.Multiline = false;
            this.version3.Name = "version3";
            this.version3.ReadOnly = false;
            this.version3.Size = new System.Drawing.Size(31, 27);
            this.version3.TabIndex = 15;
            this.version3.Text = "0";
            this.version3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.version3.UseSystemPasswordChar = false;
            // 
            // version2
            // 
            this.version2.BackColor = System.Drawing.Color.Transparent;
            this.version2.Location = new System.Drawing.Point(118, 155);
            this.version2.MaxLength = 32767;
            this.version2.Multiline = false;
            this.version2.Name = "version2";
            this.version2.ReadOnly = false;
            this.version2.Size = new System.Drawing.Size(31, 27);
            this.version2.TabIndex = 14;
            this.version2.Text = "0";
            this.version2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.version2.UseSystemPasswordChar = false;
            // 
            // version1
            // 
            this.version1.BackColor = System.Drawing.Color.Transparent;
            this.version1.Location = new System.Drawing.Point(80, 155);
            this.version1.MaxLength = 32767;
            this.version1.Multiline = false;
            this.version1.Name = "version1";
            this.version1.ReadOnly = false;
            this.version1.Size = new System.Drawing.Size(31, 27);
            this.version1.TabIndex = 13;
            this.version1.Text = "1";
            this.version1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.version1.UseSystemPasswordChar = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label12.Location = new System.Drawing.Point(3, 193);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(73, 15);
            this.label12.TabIndex = 12;
            this.label12.Text = "File version:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label11.Location = new System.Drawing.Point(3, 163);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(51, 15);
            this.label11.TabIndex = 11;
            this.label11.Text = "Version:";
            // 
            // descriptionbox
            // 
            this.descriptionbox.BackColor = System.Drawing.Color.Transparent;
            this.descriptionbox.Location = new System.Drawing.Point(80, 124);
            this.descriptionbox.MaxLength = 32767;
            this.descriptionbox.Multiline = false;
            this.descriptionbox.Name = "descriptionbox";
            this.descriptionbox.ReadOnly = false;
            this.descriptionbox.Size = new System.Drawing.Size(144, 27);
            this.descriptionbox.TabIndex = 10;
            this.descriptionbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.descriptionbox.UseSystemPasswordChar = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label10.Location = new System.Drawing.Point(3, 129);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(71, 15);
            this.label10.TabIndex = 9;
            this.label10.Text = "Description";
            // 
            // copyrightbox
            // 
            this.copyrightbox.BackColor = System.Drawing.Color.Transparent;
            this.copyrightbox.Location = new System.Drawing.Point(80, 91);
            this.copyrightbox.MaxLength = 32767;
            this.copyrightbox.Multiline = false;
            this.copyrightbox.Name = "copyrightbox";
            this.copyrightbox.ReadOnly = false;
            this.copyrightbox.Size = new System.Drawing.Size(144, 27);
            this.copyrightbox.TabIndex = 8;
            this.copyrightbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.copyrightbox.UseSystemPasswordChar = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label9.Location = new System.Drawing.Point(3, 96);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(64, 15);
            this.label9.TabIndex = 7;
            this.label9.Text = "Copyright:";
            // 
            // productbox
            // 
            this.productbox.BackColor = System.Drawing.Color.Transparent;
            this.productbox.Location = new System.Drawing.Point(80, 58);
            this.productbox.MaxLength = 32767;
            this.productbox.Multiline = false;
            this.productbox.Name = "productbox";
            this.productbox.ReadOnly = false;
            this.productbox.Size = new System.Drawing.Size(144, 27);
            this.productbox.TabIndex = 6;
            this.productbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.productbox.UseSystemPasswordChar = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label8.Location = new System.Drawing.Point(3, 63);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(54, 15);
            this.label8.TabIndex = 5;
            this.label8.Text = "Product:";
            // 
            // titlebox
            // 
            this.titlebox.BackColor = System.Drawing.Color.Transparent;
            this.titlebox.Location = new System.Drawing.Point(80, 25);
            this.titlebox.MaxLength = 32767;
            this.titlebox.Multiline = false;
            this.titlebox.Name = "titlebox";
            this.titlebox.ReadOnly = false;
            this.titlebox.Size = new System.Drawing.Size(144, 27);
            this.titlebox.TabIndex = 4;
            this.titlebox.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.titlebox.UseSystemPasswordChar = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label7.Location = new System.Drawing.Point(3, 30);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(35, 15);
            this.label7.TabIndex = 3;
            this.label7.Text = "Title:";
            // 
            // mysticGroupBox8
            // 
            this.mysticGroupBox8.Controls.Add(this.mysticButton3);
            this.mysticGroupBox8.Controls.Add(this.mysticTextBox4);
            this.mysticGroupBox8.Enabled = false;
            this.mysticGroupBox8.Location = new System.Drawing.Point(4, 162);
            this.mysticGroupBox8.Name = "mysticGroupBox8";
            this.mysticGroupBox8.Size = new System.Drawing.Size(259, 65);
            this.mysticGroupBox8.TabIndex = 2;
            this.mysticGroupBox8.Text = "File Cloner";
            // 
            // mysticTextBox4
            // 
            this.mysticTextBox4.BackColor = System.Drawing.Color.Transparent;
            this.mysticTextBox4.Location = new System.Drawing.Point(7, 27);
            this.mysticTextBox4.MaxLength = 32767;
            this.mysticTextBox4.Multiline = false;
            this.mysticTextBox4.Name = "mysticTextBox4";
            this.mysticTextBox4.ReadOnly = false;
            this.mysticTextBox4.Size = new System.Drawing.Size(203, 27);
            this.mysticTextBox4.TabIndex = 2;
            this.mysticTextBox4.Text = "Please select a .exe file to clone!";
            this.mysticTextBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.mysticTextBox4.UseSystemPasswordChar = false;
            this.mysticTextBox4.KeyDown += new System.Windows.Forms.KeyEventHandler(this.mysticTextBox1_KeyDown);
            // 
            // mysticGroupBox2
            // 
            this.mysticGroupBox2.Controls.Add(this.label6);
            this.mysticGroupBox2.Controls.Add(this.label5);
            this.mysticGroupBox2.Controls.Add(this.label4);
            this.mysticGroupBox2.Controls.Add(this.pictureBox2);
            this.mysticGroupBox2.Controls.Add(this.pictureBox1);
            this.mysticGroupBox2.Controls.Add(this.mysticButton2);
            this.mysticGroupBox2.Controls.Add(this.mysticTextBox3);
            this.mysticGroupBox2.Enabled = false;
            this.mysticGroupBox2.Location = new System.Drawing.Point(4, 8);
            this.mysticGroupBox2.Name = "mysticGroupBox2";
            this.mysticGroupBox2.Size = new System.Drawing.Size(259, 148);
            this.mysticGroupBox2.TabIndex = 0;
            this.mysticGroupBox2.Text = "Icon Changer";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.Location = new System.Drawing.Point(119, 88);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(20, 15);
            this.label4.TabIndex = 7;
            this.label4.Text = "->";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox2.Location = new System.Drawing.Point(201, 70);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(50, 50);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 6;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Location = new System.Drawing.Point(7, 70);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(50, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // mysticTextBox3
            // 
            this.mysticTextBox3.BackColor = System.Drawing.Color.Transparent;
            this.mysticTextBox3.Location = new System.Drawing.Point(7, 27);
            this.mysticTextBox3.MaxLength = 32767;
            this.mysticTextBox3.Multiline = false;
            this.mysticTextBox3.Name = "mysticTextBox3";
            this.mysticTextBox3.ReadOnly = false;
            this.mysticTextBox3.Size = new System.Drawing.Size(203, 27);
            this.mysticTextBox3.TabIndex = 2;
            this.mysticTextBox3.Text = "Please select a .ico or .exe file!";
            this.mysticTextBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.mysticTextBox3.UseSystemPasswordChar = false;
            this.mysticTextBox3.KeyDown += new System.Windows.Forms.KeyEventHandler(this.mysticTextBox1_KeyDown);
            // 
            // tabPageEX3
            // 
            this.tabPageEX3.Controls.Add(this.mysticRadioButton8);
            this.tabPageEX3.Controls.Add(this.mysticRadioButton7);
            this.tabPageEX3.Controls.Add(this.mysticButton4);
            this.tabPageEX3.Controls.Add(this.mysticGroupBox13);
            this.tabPageEX3.Controls.Add(this.mysticGroupBox12);
            this.tabPageEX3.Controls.Add(this.mysticGroupBox11);
            this.tabPageEX3.Controls.Add(this.mysticCheckBox12);
            this.tabPageEX3.Controls.Add(this.mysticGroupBox10);
            this.tabPageEX3.Location = new System.Drawing.Point(4, 25);
            this.tabPageEX3.Name = "tabPageEX3";
            this.tabPageEX3.Size = new System.Drawing.Size(539, 228);
            this.tabPageEX3.TabIndex = 2;
            this.tabPageEX3.Text = "Msg";
            // 
            // mysticButton4
            // 
            this.mysticButton4.Enabled = false;
            this.mysticButton4.Location = new System.Drawing.Point(458, 193);
            this.mysticButton4.Name = "mysticButton4";
            this.mysticButton4.Size = new System.Drawing.Size(75, 29);
            this.mysticButton4.TabIndex = 6;
            this.mysticButton4.Text = "Test";
            this.mysticButton4.Click += new System.EventHandler(this.mysticButton4_Click);
            // 
            // mysticGroupBox13
            // 
            this.mysticGroupBox13.Controls.Add(this.comboBox2);
            this.mysticGroupBox13.Enabled = false;
            this.mysticGroupBox13.Location = new System.Drawing.Point(344, 101);
            this.mysticGroupBox13.Name = "mysticGroupBox13";
            this.mysticGroupBox13.Size = new System.Drawing.Size(190, 65);
            this.mysticGroupBox13.TabIndex = 5;
            this.mysticGroupBox13.Text = "Message Button";
            // 
            // comboBox2
            // 
            this.comboBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(37)))), ((int)(((byte)(44)))));
            this.comboBox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(153)))), ((int)(((byte)(228)))));
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(10, 29);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(170, 23);
            this.comboBox2.TabIndex = 0;
            // 
            // mysticGroupBox12
            // 
            this.mysticGroupBox12.Controls.Add(this.comboBox1);
            this.mysticGroupBox12.Enabled = false;
            this.mysticGroupBox12.Location = new System.Drawing.Point(344, 30);
            this.mysticGroupBox12.Name = "mysticGroupBox12";
            this.mysticGroupBox12.Size = new System.Drawing.Size(190, 65);
            this.mysticGroupBox12.TabIndex = 4;
            this.mysticGroupBox12.Text = "Message Icon";
            // 
            // comboBox1
            // 
            this.comboBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(34)))), ((int)(((byte)(37)))), ((int)(((byte)(44)))));
            this.comboBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(153)))), ((int)(((byte)(228)))));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(10, 29);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(170, 23);
            this.comboBox1.TabIndex = 0;
            // 
            // mysticGroupBox11
            // 
            this.mysticGroupBox11.Controls.Add(this.mysticTextBox6);
            this.mysticGroupBox11.Enabled = false;
            this.mysticGroupBox11.Location = new System.Drawing.Point(4, 101);
            this.mysticGroupBox11.Name = "mysticGroupBox11";
            this.mysticGroupBox11.Size = new System.Drawing.Size(332, 126);
            this.mysticGroupBox11.TabIndex = 3;
            this.mysticGroupBox11.Text = "Message Text";
            // 
            // mysticTextBox6
            // 
            this.mysticTextBox6.BackColor = System.Drawing.Color.Transparent;
            this.mysticTextBox6.Location = new System.Drawing.Point(8, 28);
            this.mysticTextBox6.MaxLength = 32767;
            this.mysticTextBox6.Multiline = true;
            this.mysticTextBox6.Name = "mysticTextBox6";
            this.mysticTextBox6.ReadOnly = false;
            this.mysticTextBox6.Size = new System.Drawing.Size(317, 92);
            this.mysticTextBox6.TabIndex = 2;
            this.mysticTextBox6.Text = "Please enter the text of your message!";
            this.mysticTextBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.mysticTextBox6.UseSystemPasswordChar = false;
            // 
            // mysticGroupBox10
            // 
            this.mysticGroupBox10.Controls.Add(this.mysticTextBox5);
            this.mysticGroupBox10.Enabled = false;
            this.mysticGroupBox10.Location = new System.Drawing.Point(4, 30);
            this.mysticGroupBox10.Name = "mysticGroupBox10";
            this.mysticGroupBox10.Size = new System.Drawing.Size(331, 65);
            this.mysticGroupBox10.TabIndex = 2;
            this.mysticGroupBox10.Text = "Message Title";
            // 
            // mysticTextBox5
            // 
            this.mysticTextBox5.BackColor = System.Drawing.Color.Transparent;
            this.mysticTextBox5.Location = new System.Drawing.Point(7, 27);
            this.mysticTextBox5.MaxLength = 32767;
            this.mysticTextBox5.Multiline = false;
            this.mysticTextBox5.Name = "mysticTextBox5";
            this.mysticTextBox5.ReadOnly = false;
            this.mysticTextBox5.Size = new System.Drawing.Size(317, 27);
            this.mysticTextBox5.TabIndex = 2;
            this.mysticTextBox5.Text = "Please enter the title of your message!";
            this.mysticTextBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.mysticTextBox5.UseSystemPasswordChar = false;
            // 
            // tabPageEX4
            // 
            this.tabPageEX4.Controls.Add(this.mysticCheckBox18);
            this.tabPageEX4.Controls.Add(this.mysticCheckBox17);
            this.tabPageEX4.Controls.Add(this.mysticCheckBox16);
            this.tabPageEX4.Controls.Add(this.mysticGroupBox19);
            this.tabPageEX4.Controls.Add(this.mysticGroupBox18);
            this.tabPageEX4.Controls.Add(this.mysticGroupBox17);
            this.tabPageEX4.Controls.Add(this.mysticGroupBox14);
            this.tabPageEX4.Controls.Add(this.mysticCheckBox14);
            this.tabPageEX4.Location = new System.Drawing.Point(4, 25);
            this.tabPageEX4.Name = "tabPageEX4";
            this.tabPageEX4.Size = new System.Drawing.Size(539, 228);
            this.tabPageEX4.TabIndex = 3;
            this.tabPageEX4.Text = "Startup";
            // 
            // mysticGroupBox19
            // 
            this.mysticGroupBox19.Controls.Add(this.mysticTextBox11);
            this.mysticGroupBox19.Location = new System.Drawing.Point(344, 167);
            this.mysticGroupBox19.Name = "mysticGroupBox19";
            this.mysticGroupBox19.Size = new System.Drawing.Size(190, 60);
            this.mysticGroupBox19.TabIndex = 6;
            this.mysticGroupBox19.Text = "CMD Arguments";
            // 
            // mysticGroupBox18
            // 
            this.mysticGroupBox18.Controls.Add(this.mysticTextBox10);
            this.mysticGroupBox18.Enabled = false;
            this.mysticGroupBox18.Location = new System.Drawing.Point(344, 98);
            this.mysticGroupBox18.Name = "mysticGroupBox18";
            this.mysticGroupBox18.Size = new System.Drawing.Size(190, 60);
            this.mysticGroupBox18.TabIndex = 5;
            this.mysticGroupBox18.Text = "File Pump in KBs";
            // 
            // mysticGroupBox17
            // 
            this.mysticGroupBox17.Controls.Add(this.mysticTextBox9);
            this.mysticGroupBox17.Enabled = false;
            this.mysticGroupBox17.Location = new System.Drawing.Point(344, 30);
            this.mysticGroupBox17.Name = "mysticGroupBox17";
            this.mysticGroupBox17.Size = new System.Drawing.Size(190, 60);
            this.mysticGroupBox17.TabIndex = 4;
            this.mysticGroupBox17.Text = "Delay in Secs";
            // 
            // mysticGroupBox14
            // 
            this.mysticGroupBox14.Controls.Add(this.mysticCheckBox15);
            this.mysticGroupBox14.Controls.Add(this.comboBox3);
            this.mysticGroupBox14.Controls.Add(this.mysticGroupBox16);
            this.mysticGroupBox14.Controls.Add(this.mysticGroupBox15);
            this.mysticGroupBox14.Enabled = false;
            this.mysticGroupBox14.Location = new System.Drawing.Point(4, 30);
            this.mysticGroupBox14.Name = "mysticGroupBox14";
            this.mysticGroupBox14.Size = new System.Drawing.Size(331, 197);
            this.mysticGroupBox14.TabIndex = 3;
            this.mysticGroupBox14.Text = "Startup";
            // 
            // mysticGroupBox16
            // 
            this.mysticGroupBox16.Controls.Add(this.mysticTextBox8);
            this.mysticGroupBox16.Location = new System.Drawing.Point(7, 96);
            this.mysticGroupBox16.Name = "mysticGroupBox16";
            this.mysticGroupBox16.Size = new System.Drawing.Size(315, 65);
            this.mysticGroupBox16.TabIndex = 4;
            this.mysticGroupBox16.Text = "Startup Entry Name";
            // 
            // mysticGroupBox15
            // 
            this.mysticGroupBox15.Controls.Add(this.mysticTextBox7);
            this.mysticGroupBox15.Location = new System.Drawing.Point(7, 25);
            this.mysticGroupBox15.Name = "mysticGroupBox15";
            this.mysticGroupBox15.Size = new System.Drawing.Size(315, 65);
            this.mysticGroupBox15.TabIndex = 3;
            this.mysticGroupBox15.Text = "Startup Entry Name";
            // 
            // tabPageEX6
            // 
            this.tabPageEX6.Controls.Add(this.mysticGroupBox9);
            this.tabPageEX6.Location = new System.Drawing.Point(4, 25);
            this.tabPageEX6.Name = "tabPageEX6";
            this.tabPageEX6.Size = new System.Drawing.Size(539, 228);
            this.tabPageEX6.TabIndex = 5;
            this.tabPageEX6.Text = "B&&D";
            // 
            // mysticGroupBox9
            // 
            this.mysticGroupBox9.Controls.Add(this.listView1);
            this.mysticGroupBox9.Location = new System.Drawing.Point(4, 8);
            this.mysticGroupBox9.Name = "mysticGroupBox9";
            this.mysticGroupBox9.Size = new System.Drawing.Size(530, 219);
            this.mysticGroupBox9.TabIndex = 0;
            this.mysticGroupBox9.Text = "Binder & Downloader";
            // 
            // listView1
            // 
            this.listView1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(51)))), ((int)(((byte)(62)))));
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4});
            this.listView1.ContextMenuStrip = this.contextMenuStrip1;
            this.listView1.ForeColor = System.Drawing.Color.White;
            this.listView1.FullRowSelect = true;
            this.listView1.GridLines = true;
            this.listView1.Location = new System.Drawing.Point(9, 26);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(518, 190);
            this.listView1.TabIndex = 1;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "File / Address";
            this.columnHeader1.Width = 246;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Location";
            this.columnHeader2.Width = 156;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Run";
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Delay";
            this.columnHeader4.Width = 45;
            // 
            // tabPageEX10
            // 
            this.tabPageEX10.Controls.Add(this.mysticCheckBox28);
            this.tabPageEX10.Controls.Add(this.mysticGroupBox26);
            this.tabPageEX10.Controls.Add(this.label13);
            this.tabPageEX10.Controls.Add(this.mysticRadioButton10);
            this.tabPageEX10.Controls.Add(this.mysticRadioButton9);
            this.tabPageEX10.Controls.Add(this.mysticCheckBox27);
            this.tabPageEX10.Controls.Add(this.mysticGroupBox25);
            this.tabPageEX10.Controls.Add(this.mysticGroupBox24);
            this.tabPageEX10.Controls.Add(this.mysticGroupBox23);
            this.tabPageEX10.Controls.Add(this.mysticCheckBox24);
            this.tabPageEX10.Controls.Add(this.mysticGroupBox22);
            this.tabPageEX10.Controls.Add(this.mysticGroupBox21);
            this.tabPageEX10.Location = new System.Drawing.Point(4, 25);
            this.tabPageEX10.Name = "tabPageEX10";
            this.tabPageEX10.Size = new System.Drawing.Size(539, 228);
            this.tabPageEX10.TabIndex = 9;
            this.tabPageEX10.Text = "Other";
            // 
            // mysticGroupBox26
            // 
            this.mysticGroupBox26.Controls.Add(this.dateTimePicker1);
            this.mysticGroupBox26.Enabled = false;
            this.mysticGroupBox26.Location = new System.Drawing.Point(210, 67);
            this.mysticGroupBox26.Name = "mysticGroupBox26";
            this.mysticGroupBox26.Size = new System.Drawing.Size(181, 58);
            this.mysticGroupBox26.TabIndex = 12;
            this.mysticGroupBox26.Text = "Creation Date";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CalendarForeColor = System.Drawing.Color.White;
            this.dateTimePicker1.CalendarMonthBackground = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(36)))), ((int)(((byte)(44)))));
            this.dateTimePicker1.CalendarTitleBackColor = System.Drawing.Color.Aquamarine;
            this.dateTimePicker1.CustomFormat = "";
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(7, 26);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(168, 23);
            this.dateTimePicker1.TabIndex = 0;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(471, 139);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(12, 15);
            this.label13.TabIndex = 11;
            this.label13.Text = "/";
            // 
            // mysticGroupBox25
            // 
            this.mysticGroupBox25.Controls.Add(this.mysticButton7);
            this.mysticGroupBox25.Controls.Add(this.mysticTextBox13);
            this.mysticGroupBox25.Enabled = false;
            this.mysticGroupBox25.Location = new System.Drawing.Point(210, 160);
            this.mysticGroupBox25.Name = "mysticGroupBox25";
            this.mysticGroupBox25.Size = new System.Drawing.Size(324, 67);
            this.mysticGroupBox25.TabIndex = 7;
            this.mysticGroupBox25.Text = "Signature Stealer";
            // 
            // mysticTextBox13
            // 
            this.mysticTextBox13.BackColor = System.Drawing.Color.Transparent;
            this.mysticTextBox13.Location = new System.Drawing.Point(7, 27);
            this.mysticTextBox13.MaxLength = 32767;
            this.mysticTextBox13.Multiline = false;
            this.mysticTextBox13.Name = "mysticTextBox13";
            this.mysticTextBox13.ReadOnly = false;
            this.mysticTextBox13.Size = new System.Drawing.Size(269, 27);
            this.mysticTextBox13.TabIndex = 2;
            this.mysticTextBox13.Text = "Please select a file to steal the signature from!";
            this.mysticTextBox13.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.mysticTextBox13.UseSystemPasswordChar = false;
            this.mysticTextBox13.KeyDown += new System.Windows.Forms.KeyEventHandler(this.mysticTextBox1_KeyDown);
            // 
            // mysticGroupBox24
            // 
            this.mysticGroupBox24.Controls.Add(this.mysticButton6);
            this.mysticGroupBox24.Controls.Add(this.mysticButton5);
            this.mysticGroupBox24.Location = new System.Drawing.Point(397, 8);
            this.mysticGroupBox24.Name = "mysticGroupBox24";
            this.mysticGroupBox24.Size = new System.Drawing.Size(137, 117);
            this.mysticGroupBox24.TabIndex = 6;
            this.mysticGroupBox24.Text = "Profile";
            // 
            // mysticGroupBox23
            // 
            this.mysticGroupBox23.Controls.Add(this.mysticCheckBox26);
            this.mysticGroupBox23.Controls.Add(this.mysticCheckBox25);
            this.mysticGroupBox23.Location = new System.Drawing.Point(210, 8);
            this.mysticGroupBox23.Name = "mysticGroupBox23";
            this.mysticGroupBox23.Size = new System.Drawing.Size(180, 53);
            this.mysticGroupBox23.TabIndex = 5;
            this.mysticGroupBox23.Text = "Attributes";
            // 
            // mysticGroupBox22
            // 
            this.mysticGroupBox22.Controls.Add(this.mysticTextBox12);
            this.mysticGroupBox22.Enabled = false;
            this.mysticGroupBox22.Location = new System.Drawing.Point(4, 160);
            this.mysticGroupBox22.Name = "mysticGroupBox22";
            this.mysticGroupBox22.Size = new System.Drawing.Size(200, 67);
            this.mysticGroupBox22.TabIndex = 3;
            this.mysticGroupBox22.Text = "New Extension";
            // 
            // mysticTextBox12
            // 
            this.mysticTextBox12.BackColor = System.Drawing.Color.Transparent;
            this.mysticTextBox12.Location = new System.Drawing.Point(7, 27);
            this.mysticTextBox12.MaxLength = 32767;
            this.mysticTextBox12.Multiline = false;
            this.mysticTextBox12.Name = "mysticTextBox12";
            this.mysticTextBox12.ReadOnly = false;
            this.mysticTextBox12.Size = new System.Drawing.Size(185, 27);
            this.mysticTextBox12.TabIndex = 2;
            this.mysticTextBox12.Text = "Please enter your new extension!";
            this.mysticTextBox12.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.mysticTextBox12.UseSystemPasswordChar = false;
            // 
            // mysticGroupBox21
            // 
            this.mysticGroupBox21.Controls.Add(this.mysticCheckBox23);
            this.mysticGroupBox21.Controls.Add(this.mysticCheckBox22);
            this.mysticGroupBox21.Controls.Add(this.mysticCheckBox21);
            this.mysticGroupBox21.Controls.Add(this.mysticCheckBox20);
            this.mysticGroupBox21.Location = new System.Drawing.Point(4, 8);
            this.mysticGroupBox21.Name = "mysticGroupBox21";
            this.mysticGroupBox21.Size = new System.Drawing.Size(200, 117);
            this.mysticGroupBox21.TabIndex = 0;
            this.mysticGroupBox21.Text = "Protection";
            // 
            // tabPageEX8
            // 
            this.tabPageEX8.Controls.Add(this.mysticGroupBox29);
            this.tabPageEX8.Controls.Add(this.mysticGroupBox28);
            this.tabPageEX8.Controls.Add(this.mysticGroupBox27);
            this.tabPageEX8.Location = new System.Drawing.Point(4, 25);
            this.tabPageEX8.Name = "tabPageEX8";
            this.tabPageEX8.Size = new System.Drawing.Size(539, 228);
            this.tabPageEX8.TabIndex = 7;
            this.tabPageEX8.Text = "User";
            // 
            // mysticGroupBox29
            // 
            this.mysticGroupBox29.Controls.Add(this.mysticButton8);
            this.mysticGroupBox29.Location = new System.Drawing.Point(336, 8);
            this.mysticGroupBox29.Name = "mysticGroupBox29";
            this.mysticGroupBox29.Size = new System.Drawing.Size(198, 66);
            this.mysticGroupBox29.TabIndex = 2;
            this.mysticGroupBox29.Text = "NetSeal Panel";
            // 
            // mysticButton8
            // 
            this.mysticButton8.Location = new System.Drawing.Point(49, 26);
            this.mysticButton8.Name = "mysticButton8";
            this.mysticButton8.Size = new System.Drawing.Size(100, 30);
            this.mysticButton8.TabIndex = 0;
            this.mysticButton8.Text = "Show Panel";
            this.mysticButton8.Click += new System.EventHandler(this.mysticButton8_Click);
            // 
            // mysticGroupBox28
            // 
            this.mysticGroupBox28.Controls.Add(this.label17);
            this.mysticGroupBox28.Controls.Add(this.label16);
            this.mysticGroupBox28.Controls.Add(this.label15);
            this.mysticGroupBox28.Controls.Add(this.label14);
            this.mysticGroupBox28.Location = new System.Drawing.Point(336, 80);
            this.mysticGroupBox28.Name = "mysticGroupBox28";
            this.mysticGroupBox28.Size = new System.Drawing.Size(198, 147);
            this.mysticGroupBox28.TabIndex = 1;
            this.mysticGroupBox28.Text = "Member Info";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.Transparent;
            this.label17.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label17.Location = new System.Drawing.Point(4, 123);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(64, 15);
            this.label17.TabIndex = 6;
            this.label17.Text = "Time left: ";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label16.Location = new System.Drawing.Point(4, 91);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(67, 15);
            this.label16.TabIndex = 5;
            this.label16.Text = "Valid until: ";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label15.Location = new System.Drawing.Point(4, 59);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(88, 15);
            this.label15.TabIndex = 4;
            this.label15.Text = "Account Type: ";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label14.Location = new System.Drawing.Point(4, 27);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(70, 15);
            this.label14.TabIndex = 3;
            this.label14.Text = "Username: ";
            // 
            // mysticGroupBox27
            // 
            this.mysticGroupBox27.Controls.Add(this.mysticTextBox14);
            this.mysticGroupBox27.Location = new System.Drawing.Point(4, 8);
            this.mysticGroupBox27.Name = "mysticGroupBox27";
            this.mysticGroupBox27.Size = new System.Drawing.Size(326, 219);
            this.mysticGroupBox27.TabIndex = 0;
            this.mysticGroupBox27.Text = "News";
            // 
            // mysticTextBox14
            // 
            this.mysticTextBox14.BackColor = System.Drawing.Color.Transparent;
            this.mysticTextBox14.Location = new System.Drawing.Point(4, 26);
            this.mysticTextBox14.MaxLength = 32767;
            this.mysticTextBox14.Multiline = true;
            this.mysticTextBox14.Name = "mysticTextBox14";
            this.mysticTextBox14.ReadOnly = false;
            this.mysticTextBox14.Size = new System.Drawing.Size(318, 189);
            this.mysticTextBox14.TabIndex = 0;
            this.mysticTextBox14.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.mysticTextBox14.UseSystemPasswordChar = false;
            // 
            // tabPageEX9
            // 
            this.tabPageEX9.Controls.Add(this.linkLabel2);
            this.tabPageEX9.Controls.Add(this.linkLabel1);
            this.tabPageEX9.Controls.Add(this.label18);
            this.tabPageEX9.Controls.Add(this.mysticButton9);
            this.tabPageEX9.Controls.Add(this.mysticGroupBox32);
            this.tabPageEX9.Controls.Add(this.mysticGroupBox31);
            this.tabPageEX9.Controls.Add(this.mysticGroupBox30);
            this.tabPageEX9.Location = new System.Drawing.Point(4, 25);
            this.tabPageEX9.Name = "tabPageEX9";
            this.tabPageEX9.Size = new System.Drawing.Size(539, 228);
            this.tabPageEX9.TabIndex = 8;
            this.tabPageEX9.Text = "Help";
            // 
            // linkLabel2
            // 
            this.linkLabel2.AutoSize = true;
            this.linkLabel2.LinkColor = System.Drawing.Color.White;
            this.linkLabel2.Location = new System.Drawing.Point(140, 180);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Size = new System.Drawing.Size(131, 15);
            this.linkLabel2.TabIndex = 10;
            this.linkLabel2.TabStop = true;
            this.linkLabel2.Text = "Gegi- HackForums PM";
            this.linkLabel2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel2_LinkClicked);
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.LinkColor = System.Drawing.Color.White;
            this.linkLabel1.Location = new System.Drawing.Point(140, 156);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(127, 15);
            this.linkLabel1.TabIndex = 9;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "KazyProducts - Skype";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.Transparent;
            this.label18.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label18.Location = new System.Drawing.Point(3, 156);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(58, 15);
            this.label18.TabIndex = 8;
            this.label18.Text = "Contacts:";
            // 
            // mysticButton9
            // 
            this.mysticButton9.Location = new System.Drawing.Point(4, 197);
            this.mysticButton9.Name = "mysticButton9";
            this.mysticButton9.Size = new System.Drawing.Size(78, 30);
            this.mysticButton9.TabIndex = 7;
            this.mysticButton9.Text = "Send";
            this.mysticButton9.Click += new System.EventHandler(this.mysticButton9_Click);
            // 
            // mysticGroupBox32
            // 
            this.mysticGroupBox32.Controls.Add(this.mysticTextBox17);
            this.mysticGroupBox32.Location = new System.Drawing.Point(272, 8);
            this.mysticGroupBox32.Name = "mysticGroupBox32";
            this.mysticGroupBox32.Size = new System.Drawing.Size(262, 219);
            this.mysticGroupBox32.TabIndex = 6;
            this.mysticGroupBox32.Text = "Message";
            // 
            // mysticTextBox17
            // 
            this.mysticTextBox17.BackColor = System.Drawing.Color.Transparent;
            this.mysticTextBox17.Location = new System.Drawing.Point(7, 27);
            this.mysticTextBox17.MaxLength = 32767;
            this.mysticTextBox17.Multiline = true;
            this.mysticTextBox17.Name = "mysticTextBox17";
            this.mysticTextBox17.ReadOnly = false;
            this.mysticTextBox17.Size = new System.Drawing.Size(247, 185);
            this.mysticTextBox17.TabIndex = 2;
            this.mysticTextBox17.Text = "Please enter your message here!";
            this.mysticTextBox17.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.mysticTextBox17.UseSystemPasswordChar = false;
            // 
            // mysticGroupBox31
            // 
            this.mysticGroupBox31.Controls.Add(this.mysticTextBox16);
            this.mysticGroupBox31.Location = new System.Drawing.Point(4, 79);
            this.mysticGroupBox31.Name = "mysticGroupBox31";
            this.mysticGroupBox31.Size = new System.Drawing.Size(263, 65);
            this.mysticGroupBox31.TabIndex = 5;
            this.mysticGroupBox31.Text = "E-mail address";
            // 
            // mysticTextBox16
            // 
            this.mysticTextBox16.BackColor = System.Drawing.Color.Transparent;
            this.mysticTextBox16.Location = new System.Drawing.Point(7, 27);
            this.mysticTextBox16.MaxLength = 32767;
            this.mysticTextBox16.Multiline = false;
            this.mysticTextBox16.Name = "mysticTextBox16";
            this.mysticTextBox16.ReadOnly = false;
            this.mysticTextBox16.Size = new System.Drawing.Size(247, 27);
            this.mysticTextBox16.TabIndex = 2;
            this.mysticTextBox16.Text = "Please enter your e-mail address!";
            this.mysticTextBox16.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.mysticTextBox16.UseSystemPasswordChar = false;
            // 
            // mysticGroupBox30
            // 
            this.mysticGroupBox30.Controls.Add(this.mysticTextBox15);
            this.mysticGroupBox30.Location = new System.Drawing.Point(4, 8);
            this.mysticGroupBox30.Name = "mysticGroupBox30";
            this.mysticGroupBox30.Size = new System.Drawing.Size(263, 65);
            this.mysticGroupBox30.TabIndex = 4;
            this.mysticGroupBox30.Text = "Subject of your problem";
            // 
            // mysticTextBox15
            // 
            this.mysticTextBox15.BackColor = System.Drawing.Color.Transparent;
            this.mysticTextBox15.Location = new System.Drawing.Point(7, 27);
            this.mysticTextBox15.MaxLength = 32767;
            this.mysticTextBox15.Multiline = false;
            this.mysticTextBox15.Name = "mysticTextBox15";
            this.mysticTextBox15.ReadOnly = false;
            this.mysticTextBox15.Size = new System.Drawing.Size(247, 27);
            this.mysticTextBox15.TabIndex = 2;
            this.mysticTextBox15.Text = "Please enter the subject of your problem!";
            this.mysticTextBox15.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.mysticTextBox15.UseSystemPasswordChar = false;
            // 
            // tabPageEX7
            // 
            this.tabPageEX7.Controls.Add(this.mysticButton11);
            this.tabPageEX7.Controls.Add(this.label22);
            this.tabPageEX7.Controls.Add(this.label21);
            this.tabPageEX7.Controls.Add(this.mysticButton10);
            this.tabPageEX7.Controls.Add(this.mysticGroupBox35);
            this.tabPageEX7.Controls.Add(this.mysticGroupBox34);
            this.tabPageEX7.Controls.Add(this.mysticGroupBox33);
            this.tabPageEX7.Location = new System.Drawing.Point(4, 25);
            this.tabPageEX7.Name = "tabPageEX7";
            this.tabPageEX7.Size = new System.Drawing.Size(539, 228);
            this.tabPageEX7.TabIndex = 6;
            this.tabPageEX7.Text = "Scan";
            // 
            // mysticButton11
            // 
            this.mysticButton11.Location = new System.Drawing.Point(165, 192);
            this.mysticButton11.Name = "mysticButton11";
            this.mysticButton11.Size = new System.Drawing.Size(90, 35);
            this.mysticButton11.TabIndex = 9;
            this.mysticButton11.Text = "Open";
            this.mysticButton11.Click += new System.EventHandler(this.mysticButton11_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.Transparent;
            this.label22.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label22.Location = new System.Drawing.Point(3, 171);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(145, 15);
            this.label22.TabIndex = 8;
            this.label22.Text = "If the scan fails try again!";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.Transparent;
            this.label21.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label21.Location = new System.Drawing.Point(3, 153);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(171, 15);
            this.label21.TabIndex = 7;
            this.label21.Text = "Powered by VirusCheckMate!";
            // 
            // mysticGroupBox35
            // 
            this.mysticGroupBox35.Controls.Add(this.linkLabel3);
            this.mysticGroupBox35.Location = new System.Drawing.Point(4, 81);
            this.mysticGroupBox35.Name = "mysticGroupBox35";
            this.mysticGroupBox35.Size = new System.Drawing.Size(251, 67);
            this.mysticGroupBox35.TabIndex = 5;
            this.mysticGroupBox35.Text = "Link of the scan";
            // 
            // linkLabel3
            // 
            this.linkLabel3.BackColor = System.Drawing.Color.Transparent;
            this.linkLabel3.LinkColor = System.Drawing.Color.White;
            this.linkLabel3.Location = new System.Drawing.Point(12, 27);
            this.linkLabel3.Name = "linkLabel3";
            this.linkLabel3.Size = new System.Drawing.Size(227, 31);
            this.linkLabel3.TabIndex = 10;
            this.linkLabel3.TabStop = true;
            this.linkLabel3.Text = "N/A";
            this.linkLabel3.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel3_LinkClicked);
            // 
            // mysticGroupBox34
            // 
            this.mysticGroupBox34.Controls.Add(this.label20);
            this.mysticGroupBox34.Controls.Add(this.label19);
            this.mysticGroupBox34.Location = new System.Drawing.Point(4, 8);
            this.mysticGroupBox34.Name = "mysticGroupBox34";
            this.mysticGroupBox34.Size = new System.Drawing.Size(251, 67);
            this.mysticGroupBox34.TabIndex = 4;
            this.mysticGroupBox34.Text = "Results";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.Transparent;
            this.label20.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label20.ForeColor = System.Drawing.Color.White;
            this.label20.Location = new System.Drawing.Point(178, 33);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(29, 15);
            this.label20.TabIndex = 4;
            this.label20.Text = "N/A";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.Transparent;
            this.label19.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label19.Location = new System.Drawing.Point(12, 33);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(71, 15);
            this.label19.TabIndex = 3;
            this.label19.Text = "Detections:";
            // 
            // mysticGroupBox33
            // 
            this.mysticGroupBox33.Controls.Add(this.listView2);
            this.mysticGroupBox33.Location = new System.Drawing.Point(261, 8);
            this.mysticGroupBox33.Name = "mysticGroupBox33";
            this.mysticGroupBox33.Size = new System.Drawing.Size(273, 219);
            this.mysticGroupBox33.TabIndex = 0;
            this.mysticGroupBox33.Text = "Detections";
            // 
            // listView2
            // 
            this.listView2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(51)))), ((int)(((byte)(62)))));
            this.listView2.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader9,
            this.columnHeader10});
            this.listView2.ContextMenuStrip = this.contextMenuStrip1;
            this.listView2.ForeColor = System.Drawing.Color.White;
            this.listView2.FullRowSelect = true;
            this.listView2.GridLines = true;
            this.listView2.Location = new System.Drawing.Point(3, 26);
            this.listView2.Name = "listView2";
            this.listView2.Size = new System.Drawing.Size(267, 190);
            this.listView2.TabIndex = 2;
            this.listView2.UseCompatibleStateImageBehavior = false;
            this.listView2.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "AntiVirus";
            this.columnHeader9.Width = 108;
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "Detection";
            this.columnHeader10.Width = 137;
            // 
            // tabPageEX5
            // 
            this.tabPageEX5.Controls.Add(this.mysticCheckBox29);
            this.tabPageEX5.Controls.Add(this.mysticGroupBox39);
            this.tabPageEX5.Controls.Add(this.mysticGroupBox38);
            this.tabPageEX5.Controls.Add(this.mysticGroupBox37);
            this.tabPageEX5.Controls.Add(this.mysticGroupBox36);
            this.tabPageEX5.Location = new System.Drawing.Point(4, 25);
            this.tabPageEX5.Name = "tabPageEX5";
            this.tabPageEX5.Size = new System.Drawing.Size(539, 228);
            this.tabPageEX5.TabIndex = 10;
            this.tabPageEX5.Text = "Build";
            // 
            // mysticGroupBox39
            // 
            this.mysticGroupBox39.Controls.Add(this.label25);
            this.mysticGroupBox39.Controls.Add(this.mysticButton14);
            this.mysticGroupBox39.Controls.Add(this.mysticTextBox18);
            this.mysticGroupBox39.Enabled = false;
            this.mysticGroupBox39.Location = new System.Drawing.Point(333, 87);
            this.mysticGroupBox39.Name = "mysticGroupBox39";
            this.mysticGroupBox39.Size = new System.Drawing.Size(200, 78);
            this.mysticGroupBox39.TabIndex = 4;
            this.mysticGroupBox39.Text = "Private Stub";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.Color.Transparent;
            this.label25.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label25.Location = new System.Drawing.Point(5, 57);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(76, 15);
            this.label25.TabIndex = 4;
            this.label25.Text = "Version: N/A";
            // 
            // mysticTextBox18
            // 
            this.mysticTextBox18.BackColor = System.Drawing.Color.Transparent;
            this.mysticTextBox18.Location = new System.Drawing.Point(8, 26);
            this.mysticTextBox18.MaxLength = 32767;
            this.mysticTextBox18.Multiline = false;
            this.mysticTextBox18.Name = "mysticTextBox18";
            this.mysticTextBox18.ReadOnly = false;
            this.mysticTextBox18.Size = new System.Drawing.Size(145, 27);
            this.mysticTextBox18.TabIndex = 1;
            this.mysticTextBox18.Text = "Please select your stub!";
            this.mysticTextBox18.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.mysticTextBox18.UseSystemPasswordChar = false;
            this.mysticTextBox18.KeyDown += new System.Windows.Forms.KeyEventHandler(this.mysticTextBox1_KeyDown);
            // 
            // mysticGroupBox38
            // 
            this.mysticGroupBox38.Controls.Add(this.comboBox4);
            this.mysticGroupBox38.Controls.Add(this.mysticButton13);
            this.mysticGroupBox38.Location = new System.Drawing.Point(333, 171);
            this.mysticGroupBox38.Name = "mysticGroupBox38";
            this.mysticGroupBox38.Size = new System.Drawing.Size(201, 56);
            this.mysticGroupBox38.TabIndex = 3;
            this.mysticGroupBox38.Text = "Build";
            // 
            // mysticButton13
            // 
            this.mysticButton13.Location = new System.Drawing.Point(121, 20);
            this.mysticButton13.Name = "mysticButton13";
            this.mysticButton13.Size = new System.Drawing.Size(73, 28);
            this.mysticButton13.TabIndex = 4;
            this.mysticButton13.Text = "Build";
            this.mysticButton13.Click += new System.EventHandler(this.mysticButton13_Click);
            // 
            // mysticGroupBox37
            // 
            this.mysticGroupBox37.Controls.Add(this.label24);
            this.mysticGroupBox37.Controls.Add(this.mysticButton12);
            this.mysticGroupBox37.Controls.Add(this.label23);
            this.mysticGroupBox37.Location = new System.Drawing.Point(333, 8);
            this.mysticGroupBox37.Name = "mysticGroupBox37";
            this.mysticGroupBox37.Size = new System.Drawing.Size(201, 73);
            this.mysticGroupBox37.TabIndex = 2;
            this.mysticGroupBox37.Text = "Crypt Engine";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.Transparent;
            this.label24.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label24.Location = new System.Drawing.Point(13, 49);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(91, 15);
            this.label24.TabIndex = 5;
            this.label24.Text = "Build date: N/A";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.Color.Transparent;
            this.label23.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label23.Location = new System.Drawing.Point(13, 26);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(76, 15);
            this.label23.TabIndex = 3;
            this.label23.Text = "Version: N/A";
            // 
            // mysticGroupBox36
            // 
            this.mysticGroupBox36.Controls.Add(this.panel2);
            this.mysticGroupBox36.Location = new System.Drawing.Point(4, 8);
            this.mysticGroupBox36.Name = "mysticGroupBox36";
            this.mysticGroupBox36.Size = new System.Drawing.Size(326, 219);
            this.mysticGroupBox36.TabIndex = 1;
            this.mysticGroupBox36.Text = "Information";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Transparent;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.richTextBox1);
            this.panel2.Location = new System.Drawing.Point(3, 24);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(320, 192);
            this.panel2.TabIndex = 0;
            // 
            // richTextBox1
            // 
            this.richTextBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(29)))), ((int)(((byte)(36)))), ((int)(((byte)(44)))));
            this.richTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBox1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.richTextBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richTextBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(101)))), ((int)(((byte)(177)))), ((int)(((byte)(235)))));
            this.richTextBox1.Location = new System.Drawing.Point(0, 0);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.ReadOnly = true;
            this.richTextBox1.Size = new System.Drawing.Size(318, 190);
            this.richTextBox1.TabIndex = 1;
            this.richTextBox1.TabStop = false;
            this.richTextBox1.Text = "";
            this.richTextBox1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.richTextBox1_MouseClick);
            this.richTextBox1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.mysticTextBox1_KeyDown);
            this.richTextBox1.MouseEnter += new System.EventHandler(this.richTextBox1_MouseEnter);
            // 
            // statusStrip1
            // 
            this.statusStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(29)))), ((int)(((byte)(34)))));
            this.statusStrip1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripStatusLabel2,
            this.toolStripStatusLabel3});
            this.statusStrip1.Location = new System.Drawing.Point(0, 293);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(547, 22);
            this.statusStrip1.SizingGrip = false;
            this.statusStrip1.TabIndex = 2;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.toolStripStatusLabel1.ForeColor = System.Drawing.Color.White;
            this.toolStripStatusLabel1.Margin = new System.Windows.Forms.Padding(0);
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(51, 22);
            this.toolStripStatusLabel1.Text = "Version:";
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(364, 17);
            this.toolStripStatusLabel2.Text = "                                                                                 " +
    "                                      ";
            // 
            // toolStripStatusLabel3
            // 
            this.toolStripStatusLabel3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripStatusLabel3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.toolStripStatusLabel3.ForeColor = System.Drawing.Color.White;
            this.toolStripStatusLabel3.Margin = new System.Windows.Forms.Padding(0);
            this.toolStripStatusLabel3.Name = "toolStripStatusLabel3";
            this.toolStripStatusLabel3.Size = new System.Drawing.Size(89, 22);
            this.toolStripStatusLabel3.Text = "coded by: Gegi";
            this.toolStripStatusLabel3.Click += new System.EventHandler(this.toolStripStatusLabel3_Click);
            // 
            // mysticMini1
            // 
            this.mysticMini1.BackColor = System.Drawing.Color.Transparent;
            this.mysticMini1.Location = new System.Drawing.Point(509, 12);
            this.mysticMini1.Name = "mysticMini1";
            this.mysticMini1.Size = new System.Drawing.Size(12, 12);
            this.mysticMini1.TabIndex = 1;
            this.mysticMini1.Text = "mysticMini1";
            // 
            // mysticClose1
            // 
            this.mysticClose1.BackColor = System.Drawing.Color.Transparent;
            this.mysticClose1.Location = new System.Drawing.Point(527, 14);
            this.mysticClose1.Name = "mysticClose1";
            this.mysticClose1.Size = new System.Drawing.Size(12, 12);
            this.mysticClose1.TabIndex = 0;
            this.mysticClose1.Text = "mysticClose1";
            // 
            // CrypterForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(547, 315);
            this.Controls.Add(this.mysticTheme1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = global::KazyCrypter.Properties.Resources.kazy;
            this.Name = "CrypterForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "KazyCrypter";
            this.TransparencyKey = System.Drawing.Color.Fuchsia;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.CrypterForm_FormClosed);
            this.Shown += new System.EventHandler(this.CrypterForm_Shown);
            this.contextMenuStrip1.ResumeLayout(false);
            this.mysticTheme1.ResumeLayout(false);
            this.mysticTheme1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.tabControlEX1.ResumeLayout(false);
            this.tabPageEX1.ResumeLayout(false);
            this.mysticGroupBox7.ResumeLayout(false);
            this.mysticGroupBox6.ResumeLayout(false);
            this.mysticGroupBox5.ResumeLayout(false);
            this.mysticGroupBox3.ResumeLayout(false);
            this.mysticGroupBox4.ResumeLayout(false);
            this.mysticGroupBox1.ResumeLayout(false);
            this.mysticGroupBox1.PerformLayout();
            this.tabPageEX2.ResumeLayout(false);
            this.mysticGroupBox20.ResumeLayout(false);
            this.mysticGroupBox20.PerformLayout();
            this.mysticGroupBox8.ResumeLayout(false);
            this.mysticGroupBox2.ResumeLayout(false);
            this.mysticGroupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabPageEX3.ResumeLayout(false);
            this.mysticGroupBox13.ResumeLayout(false);
            this.mysticGroupBox12.ResumeLayout(false);
            this.mysticGroupBox11.ResumeLayout(false);
            this.mysticGroupBox10.ResumeLayout(false);
            this.tabPageEX4.ResumeLayout(false);
            this.mysticGroupBox19.ResumeLayout(false);
            this.mysticGroupBox18.ResumeLayout(false);
            this.mysticGroupBox17.ResumeLayout(false);
            this.mysticGroupBox14.ResumeLayout(false);
            this.mysticGroupBox16.ResumeLayout(false);
            this.mysticGroupBox15.ResumeLayout(false);
            this.tabPageEX6.ResumeLayout(false);
            this.mysticGroupBox9.ResumeLayout(false);
            this.tabPageEX10.ResumeLayout(false);
            this.tabPageEX10.PerformLayout();
            this.mysticGroupBox26.ResumeLayout(false);
            this.mysticGroupBox25.ResumeLayout(false);
            this.mysticGroupBox24.ResumeLayout(false);
            this.mysticGroupBox23.ResumeLayout(false);
            this.mysticGroupBox22.ResumeLayout(false);
            this.mysticGroupBox21.ResumeLayout(false);
            this.tabPageEX8.ResumeLayout(false);
            this.mysticGroupBox29.ResumeLayout(false);
            this.mysticGroupBox28.ResumeLayout(false);
            this.mysticGroupBox28.PerformLayout();
            this.mysticGroupBox27.ResumeLayout(false);
            this.tabPageEX9.ResumeLayout(false);
            this.tabPageEX9.PerformLayout();
            this.mysticGroupBox32.ResumeLayout(false);
            this.mysticGroupBox31.ResumeLayout(false);
            this.mysticGroupBox30.ResumeLayout(false);
            this.tabPageEX7.ResumeLayout(false);
            this.tabPageEX7.PerformLayout();
            this.mysticGroupBox35.ResumeLayout(false);
            this.mysticGroupBox34.ResumeLayout(false);
            this.mysticGroupBox34.PerformLayout();
            this.mysticGroupBox33.ResumeLayout(false);
            this.tabPageEX5.ResumeLayout(false);
            this.mysticGroupBox39.ResumeLayout(false);
            this.mysticGroupBox39.PerformLayout();
            this.mysticGroupBox38.ResumeLayout(false);
            this.mysticGroupBox37.ResumeLayout(false);
            this.mysticGroupBox37.PerformLayout();
            this.mysticGroupBox36.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private MysticTheme mysticTheme1;
        private MysticMini mysticMini1;
        private MysticClose mysticClose1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel3;
        private System.Windows.Forms.Panel panel1;
        private Dotnetrix.Controls.TabControlEX tabControlEX1;
        private Dotnetrix.Controls.TabPageEX tabPageEX1;
        private Dotnetrix.Controls.TabPageEX tabPageEX2;
        private System.Windows.Forms.ToolTip tt;
        private MysticGroupBox mysticGroupBox7;
        private MysticCheckBox mysticCheckBox13;
        private MysticGroupBox mysticGroupBox6;
        private MysticCheckBox mysticCheckBox6;
        private MysticCheckBox mysticCheckBox7;
        private MysticCheckBox mysticCheckBox8;
        private MysticCheckBox mysticCheckBox9;
        private MysticGroupBox mysticGroupBox5;
        private MysticCheckBox mysticCheckBox5;
        private MysticCheckBox mysticCheckBox4;
        private MysticCheckBox mysticCheckBox3;
        private MysticCheckBox mysticCheckBox2;
        private MysticGroupBox mysticGroupBox3;
        private MysticGroupBox mysticGroupBox4;
        private MysticTextBox mysticTextBox2;
        private MysticRadioButton mysticRadioButton6;
        private MysticRadioButton mysticRadioButton5;
        private MysticRadioButton mysticRadioButton4;
        private MysticRadioButton mysticRadioButton3;
        private MysticRadioButton mysticRadioButton2;
        private MysticRadioButton mysticRadioButton1;
        private MysticCheckBox mysticCheckBox1;
        private MysticGroupBox mysticGroupBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private MysticButton mysticButton1;
        private MysticTextBox mysticTextBox1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private MysticGroupBox mysticGroupBox2;
        private MysticCheckBox mysticCheckBox10;
        private MysticCheckBox mysticCheckBox11;
        private MysticGroupBox mysticGroupBox8;
        private MysticButton mysticButton3;
        private MysticTextBox mysticTextBox4;
        private MysticButton mysticButton2;
        private MysticTextBox mysticTextBox3;
        private Dotnetrix.Controls.TabPageEX tabPageEX3;
        private Dotnetrix.Controls.TabPageEX tabPageEX4;
        private System.Windows.Forms.OpenFileDialog openFileDialog2;
        private System.Windows.Forms.OpenFileDialog openFileDialog3;
        private MysticCheckBox mysticCheckBox12;
        private MysticGroupBox mysticGroupBox10;
        private MysticTextBox mysticTextBox5;
        private MysticGroupBox mysticGroupBox12;
        private MysticGroupBox mysticGroupBox11;
        private MysticTextBox mysticTextBox6;
        private System.Windows.Forms.ComboBox comboBox1;
        private MysticGroupBox mysticGroupBox13;
        private System.Windows.Forms.ComboBox comboBox2;
        private MysticRadioButton mysticRadioButton8;
        private MysticRadioButton mysticRadioButton7;
        private MysticButton mysticButton4;
        private MysticGroupBox mysticGroupBox14;
        private MysticCheckBox mysticCheckBox14;
        private MysticCheckBox mysticCheckBox15;
        private System.Windows.Forms.ComboBox comboBox3;
        private MysticGroupBox mysticGroupBox16;
        private MysticTextBox mysticTextBox8;
        private MysticGroupBox mysticGroupBox15;
        private MysticTextBox mysticTextBox7;
        private MysticCheckBox mysticCheckBox18;
        private MysticCheckBox mysticCheckBox17;
        private MysticCheckBox mysticCheckBox16;
        private MysticGroupBox mysticGroupBox19;
        private MysticTextBox mysticTextBox11;
        private MysticGroupBox mysticGroupBox18;
        private MysticTextBox mysticTextBox10;
        private MysticGroupBox mysticGroupBox17;
        private MysticTextBox mysticTextBox9;
        private Dotnetrix.Controls.TabPageEX tabPageEX6;
        private Dotnetrix.Controls.TabPageEX tabPageEX7;
        private Dotnetrix.Controls.TabPageEX tabPageEX8;
        private Dotnetrix.Controls.TabPageEX tabPageEX9;
        private Dotnetrix.Controls.TabPageEX tabPageEX10;
        private MysticGroupBox mysticGroupBox20;
        private System.Windows.Forms.VScrollBar vScrollBar1;
        private MysticCheckBox mysticCheckBox19;
        private MysticTextBox fversion4;
        private MysticTextBox fversion3;
        private MysticTextBox fversion2;
        private MysticTextBox fversion1;
        private MysticTextBox version4;
        private MysticTextBox version3;
        private MysticTextBox version2;
        private MysticTextBox version1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private MysticTextBox descriptionbox;
        private System.Windows.Forms.Label label10;
        private MysticTextBox copyrightbox;
        private System.Windows.Forms.Label label9;
        private MysticTextBox productbox;
        private System.Windows.Forms.Label label8;
        private MysticTextBox titlebox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Dotnetrix.Controls.TabPageEX tabPageEX5;
        private MysticGroupBox mysticGroupBox9;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ToolStripMenuItem addFileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addUrlToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem locationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem runToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem onceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem alwaysToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem neverToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem currentFolderToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem removeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem removeAllToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.OpenFileDialog openFileDialog4;
        private MysticCheckBox mysticCheckBox24;
        private MysticGroupBox mysticGroupBox22;
        private MysticTextBox mysticTextBox12;
        private MysticGroupBox mysticGroupBox21;
        private MysticCheckBox mysticCheckBox23;
        private MysticCheckBox mysticCheckBox22;
        private MysticCheckBox mysticCheckBox21;
        private MysticCheckBox mysticCheckBox20;
        private MysticGroupBox mysticGroupBox24;
        private MysticGroupBox mysticGroupBox23;
        private MysticCheckBox mysticCheckBox26;
        private MysticCheckBox mysticCheckBox25;
        private System.Windows.Forms.Label label13;
        private MysticRadioButton mysticRadioButton10;
        private MysticRadioButton mysticRadioButton9;
        private MysticCheckBox mysticCheckBox27;
        private MysticGroupBox mysticGroupBox25;
        private MysticButton mysticButton7;
        private MysticTextBox mysticTextBox13;
        private MysticButton mysticButton6;
        private MysticButton mysticButton5;
        private MysticGroupBox mysticGroupBox26;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private MysticCheckBox mysticCheckBox28;
        private MysticGroupBox mysticGroupBox29;
        private MysticButton mysticButton8;
        private MysticGroupBox mysticGroupBox28;
        private MysticGroupBox mysticGroupBox27;
        private MysticTextBox mysticTextBox14;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.Label label18;
        private MysticButton mysticButton9;
        private MysticGroupBox mysticGroupBox32;
        private MysticTextBox mysticTextBox17;
        private MysticGroupBox mysticGroupBox31;
        private MysticTextBox mysticTextBox16;
        private MysticGroupBox mysticGroupBox30;
        private MysticTextBox mysticTextBox15;
        private System.Windows.Forms.LinkLabel linkLabel2;
        private MysticGroupBox mysticGroupBox35;
        private System.Windows.Forms.LinkLabel linkLabel3;
        private MysticGroupBox mysticGroupBox34;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private MysticGroupBox mysticGroupBox33;
        private MysticButton mysticButton11;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private MysticButton mysticButton10;
        private System.Windows.Forms.ListView listView2;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.OpenFileDialog openFileDialog5;
        private MysticGroupBox mysticGroupBox36;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private MysticGroupBox mysticGroupBox37;
        private MysticButton mysticButton12;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private MysticCheckBox mysticCheckBox29;
        private MysticGroupBox mysticGroupBox39;
        private System.Windows.Forms.Label label25;
        private MysticButton mysticButton14;
        private MysticTextBox mysticTextBox18;
        private MysticGroupBox mysticGroupBox38;
        private System.Windows.Forms.ComboBox comboBox4;
        private MysticButton mysticButton13;
        private System.Windows.Forms.OpenFileDialog openFileDialog6;
        private System.Windows.Forms.OpenFileDialog openFileDialog7;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog2;
        private System.Windows.Forms.OpenFileDialog openFileDialog8;
    }
}

