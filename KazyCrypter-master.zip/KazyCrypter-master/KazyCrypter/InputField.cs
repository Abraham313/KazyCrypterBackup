﻿using System;
using System.Windows.Forms;

namespace KazyCrypter
{
    public partial class InputField : Form
    {
        public string text;

        public InputField(string text)
        {
            InitializeComponent();
            mysticGroupBox1.Text = text;
            ShowDialog();
        }

        private void mysticButton1_Click(object sender, EventArgs e)
        {
            text = mysticTextBox1.Text;
            Close();
        }

        public static string GetInput(string text)
        {
            return new InputField(text).text;
        }
    }
}
