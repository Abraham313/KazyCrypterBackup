﻿namespace KazyCrypter
{
    partial class InputField
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mysticGroupBox1 = new KazyCrypter.MysticGroupBox();
            this.mysticButton1 = new KazyCrypter.MysticButton();
            this.mysticTextBox1 = new KazyCrypter.MysticTextBox();
            this.mysticGroupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // mysticGroupBox1
            // 
            this.mysticGroupBox1.Controls.Add(this.mysticButton1);
            this.mysticGroupBox1.Controls.Add(this.mysticTextBox1);
            this.mysticGroupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mysticGroupBox1.Location = new System.Drawing.Point(0, 0);
            this.mysticGroupBox1.Name = "mysticGroupBox1";
            this.mysticGroupBox1.Size = new System.Drawing.Size(403, 63);
            this.mysticGroupBox1.TabIndex = 0;
            this.mysticGroupBox1.Text = "mysticGroupBox1";
            // 
            // mysticButton1
            // 
            this.mysticButton1.Location = new System.Drawing.Point(328, 24);
            this.mysticButton1.Name = "mysticButton1";
            this.mysticButton1.Size = new System.Drawing.Size(63, 27);
            this.mysticButton1.TabIndex = 1;
            this.mysticButton1.Text = "OK";
            this.mysticButton1.Click += new System.EventHandler(this.mysticButton1_Click);
            // 
            // mysticTextBox1
            // 
            this.mysticTextBox1.BackColor = System.Drawing.Color.Transparent;
            this.mysticTextBox1.Location = new System.Drawing.Point(12, 25);
            this.mysticTextBox1.MaxLength = 32767;
            this.mysticTextBox1.Multiline = false;
            this.mysticTextBox1.Name = "mysticTextBox1";
            this.mysticTextBox1.ReadOnly = false;
            this.mysticTextBox1.Size = new System.Drawing.Size(310, 27);
            this.mysticTextBox1.TabIndex = 0;
            this.mysticTextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.mysticTextBox1.UseSystemPasswordChar = false;
            // 
            // InputField
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(403, 63);
            this.Controls.Add(this.mysticGroupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "InputField";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "InputField";
            this.mysticGroupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private MysticGroupBox mysticGroupBox1;
        private MysticButton mysticButton1;
        private MysticTextBox mysticTextBox1;
    }
}