﻿using System;
using System.Windows.Forms;

namespace KazyCrypter
{
    public partial class GlobalMessage : Form
    {
        int i = 5;

        public GlobalMessage(string text)
        {
            InitializeComponent();
            mysticTextBox1.Text = text;
            timer1_Tick(null, null);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (i == 0)
            {
                mysticButton1.Text = "Close";
                mysticButton1.Enabled = true;
                timer1.Stop();
            }
            else
            {
                mysticButton1.Text = "Close   " + i.ToString();
                mysticButton1.Invalidate();
                i--;
            }
        }

        private void mysticButton1_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
