﻿namespace KazyCrypter
{
    partial class GlobalMessage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.mysticGroupBox1 = new KazyCrypter.MysticGroupBox();
            this.mysticButton1 = new KazyCrypter.MysticButton();
            this.mysticTextBox1 = new KazyCrypter.MysticTextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.mysticGroupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // mysticGroupBox1
            // 
            this.mysticGroupBox1.Controls.Add(this.mysticButton1);
            this.mysticGroupBox1.Controls.Add(this.mysticTextBox1);
            this.mysticGroupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mysticGroupBox1.Location = new System.Drawing.Point(0, 0);
            this.mysticGroupBox1.Name = "mysticGroupBox1";
            this.mysticGroupBox1.Size = new System.Drawing.Size(323, 226);
            this.mysticGroupBox1.TabIndex = 0;
            this.mysticGroupBox1.Text = "GlobalMessage";
            // 
            // mysticButton1
            // 
            this.mysticButton1.Enabled = false;
            this.mysticButton1.Location = new System.Drawing.Point(111, 187);
            this.mysticButton1.Name = "mysticButton1";
            this.mysticButton1.Size = new System.Drawing.Size(100, 32);
            this.mysticButton1.TabIndex = 1;
            this.mysticButton1.Text = "Close";
            this.mysticButton1.Click += new System.EventHandler(this.mysticButton1_Click);
            // 
            // mysticTextBox1
            // 
            this.mysticTextBox1.BackColor = System.Drawing.Color.Transparent;
            this.mysticTextBox1.Location = new System.Drawing.Point(12, 28);
            this.mysticTextBox1.MaxLength = 32767;
            this.mysticTextBox1.Multiline = true;
            this.mysticTextBox1.Name = "mysticTextBox1";
            this.mysticTextBox1.ReadOnly = false;
            this.mysticTextBox1.Size = new System.Drawing.Size(299, 153);
            this.mysticTextBox1.TabIndex = 0;
            this.mysticTextBox1.Text = "mysticTextBox1";
            this.mysticTextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.mysticTextBox1.UseSystemPasswordChar = false;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // GlobalMessage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(323, 226);
            this.Controls.Add(this.mysticGroupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "GlobalMessage";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "GlobalMessage";
            this.TopMost = true;
            this.mysticGroupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private MysticGroupBox mysticGroupBox1;
        private MysticButton mysticButton1;
        private MysticTextBox mysticTextBox1;
        private System.Windows.Forms.Timer timer1;
    }
}