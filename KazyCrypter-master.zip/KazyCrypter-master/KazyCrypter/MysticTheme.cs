﻿
using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Windows.Forms;

namespace KazyCrypter
{
    enum MouseState
    {
        None = 0,
        Over = 1,
        Down = 2
    }

    class MysticTheme : ContainerControl
    {

        #region " Declarations "
        private bool _Down = false;
        private int _Header = 36;
        #endregion
        private Point _Point;

        #region " Mouse States "

        protected override void OnMouseUp(MouseEventArgs e)
        {
            base.OnMouseUp(e);
            _Down = false;
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);
            if (e.Y < _Header && e.Button == MouseButtons.Left)
            {
                _Point = e.Location;
                _Down = true;
            }
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);
            if (_Down == true)
            {
                ParentForm.Location = new Point(MousePosition.X - _Point.X, MousePosition.Y - _Point.Y);
            }
        }

        #endregion

        protected override void OnCreateControl()
        {
            base.OnCreateControl();
            ParentForm.FormBorderStyle = FormBorderStyle.None;
            ParentForm.TransparencyKey = Color.Fuchsia;
            Dock = DockStyle.Fill;
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics G = e.Graphics;
            G.Clear(Color.FromArgb(44, 51, 62));
            G.FillRectangle(new LinearGradientBrush(new Point(0, 0), new Point(0, _Header), Color.FromArgb(29, 36, 44), Color.FromArgb(22, 29, 35)), new Rectangle(0, 0, Width, _Header));

            G.FillRectangle(Brushes.Fuchsia, new Rectangle(0, 0, 1, 1));
            G.FillRectangle(Brushes.Fuchsia, new Rectangle(1, 0, 1, 1));
            G.FillRectangle(Brushes.Fuchsia, new Rectangle(0, 1, 1, 1));
            G.FillRectangle(Brushes.Fuchsia, new Rectangle(Width - 1, 0, 1, 1));
            G.FillRectangle(Brushes.Fuchsia, new Rectangle(Width - 1, 1, 1, 1));
            G.FillRectangle(Brushes.Fuchsia, new Rectangle(Width - 2, 0, 1, 1));

            StringFormat _StringF = new StringFormat();
            _StringF.Alignment = StringAlignment.Center;
            _StringF.LineAlignment = StringAlignment.Center;
            G.DrawString(Text, new Font("Segoe UI", 11, FontStyle.Bold), new SolidBrush(Color.FromArgb(50, 153, 228)), new RectangleF(0, 0, Width, _Header), _StringF);

        }

    }

    class MysticButton : Control
    {

        #region " Declarations "
        #endregion
        private MouseState _State = MouseState.None;

        #region " Mouse States "

        protected override void OnMouseEnter(EventArgs e)
        {
            base.OnMouseEnter(e);
            _State = MouseState.Over;
            Invalidate();
        }

        protected override void OnMouseLeave(EventArgs e)
        {
            base.OnMouseLeave(e);
            _State = MouseState.None;
            Invalidate();
        }

        protected override void OnMouseUp(MouseEventArgs e)
        {
            base.OnMouseUp(e);
            _State = MouseState.Over;
            Invalidate();
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);
            _State = MouseState.Down;
            Invalidate();
        }

        #endregion

        public MysticButton()
        {
            Size = new Size(100, 40);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics G = e.Graphics;
            G.Clear(Color.FromArgb(66, 219, 183));
            G.FillRectangle(new LinearGradientBrush(new Point(0, 0), new Point(0, Height), Color.FromArgb(50, 153, 228), Color.FromArgb(50, 153, 228)), new Rectangle(0, 0, Width, Height));

            switch (_State)
            {
                case MouseState.Over:
                    G.FillRectangle(new SolidBrush(Color.FromArgb(20, Color.White)), new Rectangle(0, 0, Width, Height));
                    break;
                case MouseState.Down:
                    G.FillRectangle(new SolidBrush(Color.FromArgb(20, Color.Black)), new Rectangle(0, 0, Width, Height));
                    break;
            }



            StringFormat _StringF = new StringFormat();
            _StringF.Alignment = StringAlignment.Center;
            _StringF.LineAlignment = StringAlignment.Center;
            G.DrawString(Text, new Font("Segoe UI", 9, FontStyle.Bold), Brushes.White, new RectangleF(0, 0, Width - 1, Height - 1), _StringF);
            if (!Enabled)
                G.FillRectangle(new SolidBrush(Color.FromArgb(100, Color.Black)), ClientRectangle);
        }

    }

    [DefaultEvent("CheckedChanged")]
    class MysticRadioButton : Control
    {

        #region " Variables "
        private MouseState _State = MouseState.None;
        #endregion
        private bool _Checked;

        #region " Properties "
        public bool Checked
        {
            get { return _Checked; }
            set
            {
                _Checked = value;
                InvalidateControls();
                if (CheckedChanged != null)
                {
                    CheckedChanged(this);
                }
                Invalidate();
            }
        }
        public event CheckedChangedEventHandler CheckedChanged;
        public delegate void CheckedChangedEventHandler(object sender);
        protected override void OnClick(EventArgs e)
        {
            if (!_Checked)
                Checked = true;
            base.OnClick(e);
        }
        private void InvalidateControls()
        {
            if (!IsHandleCreated || !_Checked)
                return;
            foreach (Control C in Parent.Controls)
            {
                if (!object.ReferenceEquals(C, this) && C is MysticRadioButton)
                {
                    ((MysticRadioButton)C).Checked = false;
                    Invalidate();
                }
            }
        }
        protected override void OnCreateControl()
        {
            base.OnCreateControl();
            InvalidateControls();
        }


        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            Height = 16;
        }

        #region " Mouse States "

        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);
            _State = MouseState.Down;
            if (!_Checked)
                Checked = true;
            Invalidate();
        }
        protected override void OnMouseUp(MouseEventArgs e)
        {
            base.OnMouseUp(e);
            _State = MouseState.Over;
            Invalidate();
        }
        protected override void OnMouseEnter(EventArgs e)
        {
            base.OnMouseEnter(e);
            _State = MouseState.Over;
            Invalidate();
        }
        protected override void OnMouseLeave(EventArgs e)
        {
            base.OnMouseLeave(e);
            _State = MouseState.None;
            Invalidate();
        }

        #endregion
        #endregion

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics G = e.Graphics;
            G.SmoothingMode = (SmoothingMode)2;
            G.TextRenderingHint = (TextRenderingHint)5;
            G.Clear(Color.FromArgb(44, 51, 62));
            G.FillEllipse(new SolidBrush(Color.FromArgb(36, 39, 46)), new Rectangle(0, 0, 15, 15));
            G.DrawEllipse(new Pen(Color.FromArgb(26, 29, 33)), new Rectangle(0, 0, 15, 15));
            if (Checked)
            {
                G.FillEllipse(new LinearGradientBrush(new Point(3, 3), new Point(3, 12), Color.FromArgb(50, 153, 228), Color.FromArgb(50, 153, 228)), new Rectangle(3, 3, 9, 9));
                G.FillEllipse(new LinearGradientBrush(new Point(4, 4), new Point(4, 11), Color.FromArgb(50, 153, 228), Color.FromArgb(50, 153, 228)), new Rectangle(4, 4, 7, 7));
                if (Enabled)
                    G.DrawString(Text, new Font("Segoe UI", 9, FontStyle.Bold), Brushes.White, new Point(18, -1));
                else
                    G.DrawString(Text, new Font("Segoe UI", 9, FontStyle.Bold), new SolidBrush(Color.FromArgb(98, 106, 115)), new Point(18, -1));
            }
            else
            {
                switch (_State)
                {
                    case MouseState.None:
                        if (Enabled)
                            G.DrawString(Text, new Font("Segoe UI", 9, FontStyle.Bold), new SolidBrush(Color.FromArgb(172, 179, 185)), new Point(18, -1));
                        else
                            G.DrawString(Text, new Font("Segoe UI", 9, FontStyle.Bold), new SolidBrush(Color.FromArgb(98, 106, 115)), new Point(18, -1));
                        break;
                    case MouseState.Over:
                        G.DrawEllipse(new Pen(Color.FromArgb(50, 153, 228), 2), new Rectangle(1, 1, 13, 13));
                        G.DrawString(Text, new Font("Segoe UI", 9, FontStyle.Bold), Brushes.White, new Point(18, -1));
                        break;
                    case MouseState.Down:
                        G.DrawString(Text, new Font("Segoe UI", 9, FontStyle.Bold), Brushes.White, new Point(18, -1));
                        break;
                }
            }
        }
    }

    [DefaultEvent("CheckedChanged")]
    class MysticCheckBox : Control
    {

        #region " Variables "
        private MouseState _State = MouseState.None;
        #endregion
        private bool _Checked;

        #region " Properties "
        protected override void OnTextChanged(System.EventArgs e)
        {
            base.OnTextChanged(e);
            Invalidate();
        }

        public bool Checked
        {
            get { return _Checked; }
            set
            {
                _Checked = value;
                if (CheckedChanged != null)
                {
                    CheckedChanged(this);
                }
                Invalidate();
            }
        }

        public event CheckedChangedEventHandler CheckedChanged;
        public delegate void CheckedChangedEventHandler(object sender);
        protected override void OnClick(System.EventArgs e)
        {
            Checked = !Checked;
            base.OnClick(e);
        }

        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            Height = 16;
        }

        #endregion

        #region " Mouse States "

        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);
            _State = MouseState.Down;
            Invalidate();
        }
        protected override void OnMouseUp(MouseEventArgs e)
        {
            base.OnMouseUp(e);
            _State = MouseState.Over;
            Invalidate();
        }
        protected override void OnMouseEnter(EventArgs e)
        {
            base.OnMouseEnter(e);
            _State = MouseState.Over;
            Invalidate();
        }
        protected override void OnMouseLeave(EventArgs e)
        {
            base.OnMouseLeave(e);
            _State = MouseState.None;
            Invalidate();
        }

        #endregion

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics G = e.Graphics;
            G.Clear(Color.FromArgb(44, 51, 62));
            G.FillRectangle(new SolidBrush(Color.FromArgb(36, 39, 46)), new Rectangle(0, 0, 15, 15));
            G.DrawLine(new Pen(Color.FromArgb(26, 29, 33)), new Point(0, 0), new Point(0, 14));
            G.DrawLine(new Pen(Color.FromArgb(26, 29, 33)), new Point(0, 0), new Point(14, 0));
            if (Checked)
            {
                G.FillRectangle(new LinearGradientBrush(new Point(3, 3), new Point(3, 13), Color.FromArgb(50, 153, 228), Color.FromArgb(50, 153, 228)), new Rectangle(3, 3, 9, 9));
                G.FillRectangle(new LinearGradientBrush(new Point(4, 4), new Point(4, 11), Color.FromArgb(50, 153, 228), Color.FromArgb(50, 153, 228)), new Rectangle(4, 4, 7, 7));
                if (Enabled)
                    G.DrawString(Text, new Font("Segoe UI", 9, FontStyle.Bold), Brushes.White, new Point(18, -1));
                else
                    G.DrawString(Text, new Font("Segoe UI", 9, FontStyle.Bold), new SolidBrush(Color.FromArgb(98, 106, 115)), new Point(18, -1));
            }
            else
            {
                switch (_State)
                {
                    case MouseState.None:
                        if (Enabled)
                            G.DrawString(Text, new Font("Segoe UI", 9, FontStyle.Bold), new SolidBrush(Color.FromArgb(172, 179, 185)), new Point(18, -1));
                        else
                            G.DrawString(Text, new Font("Segoe UI", 9, FontStyle.Bold), new SolidBrush(Color.FromArgb(98, 106, 115)), new Point(18, -1));
                        break;
                    case MouseState.Over:
                        G.DrawRectangle(new Pen(Color.FromArgb(50, 153, 228), 2), new Rectangle(1, 1, 13, 13));
                        G.DrawString(Text, new Font("Segoe UI", 9, FontStyle.Bold), Brushes.White, new Point(18, -1));
                        break;
                    case MouseState.Down:
                        G.DrawString(Text, new Font("Segoe UI", 9, FontStyle.Bold), Brushes.White, new Point(18, -1));
                        break;
                }
            }
        }
    }

    class MysticProgressBar : Control
    {

        #region " Variables "

        private int _Value = 0;

        private int _Maximum = 100;
        #endregion

        #region " Control "
        [Category("Control")]
        public int Maximum
        {
            get { return _Maximum; }
            set
            {
                if (value < _Value)
                    _Value = value;
                else
                    _Maximum = value;
                Invalidate();
            }
        }

        [Category("Control")]
        public int Value
        {
            get
            {
                switch (_Value)
                {
                    case 0:
                        Invalidate();
                        return 0;
                    default:
                        Invalidate();
                        return _Value;
                }
            }
            set
            {
                if (value > _Maximum)
                    value = _Maximum;
                else
                    _Value = value;
                Invalidate();
            }
        }
        #endregion

        #region " Events "
        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            Height = 25;
        }

        protected override void CreateHandle()
        {
            base.CreateHandle();
            Height = 25;
        }

        public void Increment(int Amount)
        {
            Value += Amount;
        }
        #endregion

        public MysticProgressBar()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.OptimizedDoubleBuffer, true);
            DoubleBuffered = true;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics G = e.Graphics;
            G.SmoothingMode = SmoothingMode.HighQuality;
            G.PixelOffsetMode = PixelOffsetMode.HighQuality;
            G.Clear(Color.FromArgb(32, 37, 41));
            int _Progress = Convert.ToInt32(_Value / _Maximum * Width);
            G.FillRectangle(new SolidBrush(Color.FromArgb(0, 163, 123)), new Rectangle(0, 0, _Progress - 1, Height));
            for (int i = 0; i <= _Progress - 1; i += 16)
            {
                G.DrawLine(new Pen(Color.FromArgb(0, 124, 95), 8), i, 0 - 2, i + 20, Height + 2);
            }
            G.FillRectangle(new LinearGradientBrush(new Point(0, 0), new Point(0, Height), Color.FromArgb(80, Color.White), Color.FromArgb(100, Color.Black)), new Rectangle(0, 0, _Progress - 1, Height));
            G.FillRectangle(new SolidBrush(Color.FromArgb(32, 37, 41)), new Rectangle(_Progress - 1, 0, Width - _Progress, Height));

            G.FillRectangle(new SolidBrush(Color.FromArgb(44, 51, 62)), new Rectangle(0, 0, 1, 1));
            G.FillRectangle(new SolidBrush(Color.FromArgb(44, 51, 62)), new Rectangle(Width - 1, 0, 1, 1));
            G.FillRectangle(new SolidBrush(Color.FromArgb(44, 51, 62)), new Rectangle(0, Height - 1, 1, 1));
            G.FillRectangle(new SolidBrush(Color.FromArgb(44, 51, 62)), new Rectangle(Width - 1, Height - 1, 1, 1));

            G.InterpolationMode = (InterpolationMode)7;
        }
    }

    [DefaultEvent("TextChanged")]
    class MysticTextBox : Control
    {

        #region " Variables "


        private TextBox _TextBox;
        #endregion

        #region " Properties "

        #region " TextBox Properties "

        private HorizontalAlignment _TextAlign = HorizontalAlignment.Left;
        [Category("Options")]
        public HorizontalAlignment TextAlign
        {
            get { return _TextAlign; }
            set
            {
                _TextAlign = value;
                if (_TextBox != null)
                {
                    _TextBox.TextAlign = value;
                }
            }
        }
        private int _MaxLength = 32767;
        [Category("Options")]
        public int MaxLength
        {
            get { return _MaxLength; }
            set
            {
                _MaxLength = value;
                if (_TextBox != null)
                {
                    _TextBox.MaxLength = value;
                }
            }
        }
        private bool _ReadOnly;
        [Category("Options")]
        public bool ReadOnly
        {
            get { return _ReadOnly; }
            set
            {
                _ReadOnly = value;
                if (_TextBox != null)
                {
                    _TextBox.ReadOnly = value;
                }
            }
        }
        private bool _UseSystemPasswordChar;
        [Category("Options")]
        public bool UseSystemPasswordChar
        {
            get { return _UseSystemPasswordChar; }
            set
            {
                _UseSystemPasswordChar = value;
                if (_TextBox != null)
                {
                    _TextBox.UseSystemPasswordChar = value;
                }
            }
        }
        private bool _Multiline;
        [Category("Options")]
        public bool Multiline
        {
            get { return _Multiline; }
            set
            {
                _Multiline = value;
                if (_TextBox != null)
                {
                    _TextBox.Multiline = value;

                    if (value)
                    {
                        _TextBox.Height = Height - 11;
                    }
                    else
                    {
                        Height = _TextBox.Height + 11;
                    }

                }
            }
        }
        [Category("Options")]
        public override string Text
        {
            get { return base.Text; }
            set
            {
                base.Text = value;
                if (_TextBox != null)
                {
                    _TextBox.Text = value;
                }
            }
        }
        [Category("Options")]
        public override Font Font
        {
            get { return base.Font; }
            set
            {
                base.Font = value;
                if (_TextBox != null)
                {
                    _TextBox.Font = value;
                    _TextBox.Location = new Point(3, 5);
                    _TextBox.Width = Width - 6;

                    if (!_Multiline)
                    {
                        Height = _TextBox.Height + 11;
                    }
                }
            }
        }

        protected override void OnCreateControl()
        {
            base.OnCreateControl();
            if (!Controls.Contains(_TextBox))
            {
                Controls.Add(_TextBox);
            }
        }
        private void OnBaseTextChanged(object s, EventArgs e)
        {
            Text = _TextBox.Text;
        }
        private void OnBaseKeyDown(object s, KeyEventArgs e)
        {
            if (e.Control && e.KeyCode == Keys.A)
            {
                _TextBox.SelectAll();
                e.SuppressKeyPress = true;
            }
            if (e.Control && e.KeyCode == Keys.C)
            {
                _TextBox.Copy();
                e.SuppressKeyPress = true;
            }
            base.OnKeyDown(e);
        }
        protected override void OnResize(EventArgs e)
        {
            _TextBox.Location = new Point(5, 5);
            _TextBox.Width = Width - 10;

            if (_Multiline)
            {
                _TextBox.Height = Height - 11;
            }
            else
            {
                Height = _TextBox.Height + 11;
            }

            base.OnResize(e);
        }

        protected override void OnGotFocus(EventArgs e)
        {
            base.OnGotFocus(e);
            Invalidate();
        }

        protected override void OnLostFocus(EventArgs e)
        {
            base.OnLostFocus(e);
            Invalidate();
        }

        #endregion

        #region " Mouse States "

        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);
            Invalidate();
        }
        protected override void OnMouseUp(MouseEventArgs e)
        {
            base.OnMouseUp(e);
            _TextBox.Focus();
            Invalidate();
        }
        protected override void OnMouseEnter(EventArgs e)
        {
            base.OnMouseEnter(e);
            Invalidate();
        }
        protected override void OnMouseLeave(EventArgs e)
        {
            base.OnMouseLeave(e);
            Invalidate();
        }

        #endregion

        #endregion

        public MysticTextBox()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.OptimizedDoubleBuffer | ControlStyles.SupportsTransparentBackColor, true);
            DoubleBuffered = true;

            BackColor = Color.Transparent;

            _TextBox = new TextBox();
            _TextBox.Font = new Font("Segoe UI", 9, FontStyle.Bold);
            _TextBox.Text = Text;
            _TextBox.BackColor = Color.FromArgb(34, 37, 44);
            _TextBox.ForeColor = Color.White;
            _TextBox.MaxLength = _MaxLength;
            _TextBox.Multiline = _Multiline;
            _TextBox.ReadOnly = _ReadOnly;
            _TextBox.UseSystemPasswordChar = _UseSystemPasswordChar;
            _TextBox.BorderStyle = BorderStyle.None;
            _TextBox.Location = new Point(5, 5);
            _TextBox.Width = Width - 10;

            _TextBox.Cursor = Cursors.IBeam;

            if (_Multiline)
            {
                _TextBox.Height = Height - 11;
            }
            else
            {
                Height = _TextBox.Height + 11;
            }

            _TextBox.TextChanged += OnBaseTextChanged;
            _TextBox.KeyDown += OnBaseKeyDown;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics G = e.Graphics;
            G.Clear(Color.FromArgb(34, 37, 44));

            G.DrawRectangle(new Pen(Color.FromArgb(50, 153, 228), 2), new Rectangle(1, 1, Width - 2, Height - 2));

            G.FillRectangle(new SolidBrush(Color.FromArgb(44, 51, 62)), new Rectangle(0, 0, 1, 1));
            G.FillRectangle(new SolidBrush(Color.FromArgb(44, 51, 62)), new Rectangle(Width - 1, 0, 1, 1));
            G.FillRectangle(new SolidBrush(Color.FromArgb(44, 51, 62)), new Rectangle(0, Height - 1, 1, 1));
            G.FillRectangle(new SolidBrush(Color.FromArgb(44, 51, 62)), new Rectangle(Width - 1, Height - 1, 1, 1));
        }

    }

    class MysticGroupBox : ContainerControl
    {

        public MysticGroupBox()
        {
            Size = new Size(200, 100);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics G = e.Graphics;

            G.Clear(Color.FromArgb(44, 51, 62));

            G.DrawRectangle(new Pen(Color.FromArgb(50, 153, 228), 2), new Rectangle(1, 1, Width - 2, Height - 2));

            if (Enabled)
                G.DrawString(Text, new Font("Segoe UI", 9, FontStyle.Bold), new SolidBrush(Color.FromArgb(255, 255, 255)), new Point(7, 5));
            else
                G.DrawString(Text, new Font("Segoe UI", 9, FontStyle.Bold), new SolidBrush(Color.FromArgb(98, 106, 115)), new Point(7, 5));

            G.FillRectangle(new SolidBrush(Color.FromArgb(44, 51, 62)), new Rectangle(0, 0, 1, 1));
            G.FillRectangle(new SolidBrush(Color.FromArgb(44, 51, 62)), new Rectangle(Width - 1, 0, 1, 1));
            G.FillRectangle(new SolidBrush(Color.FromArgb(44, 51, 62)), new Rectangle(0, Height - 1, 1, 1));
            G.FillRectangle(new SolidBrush(Color.FromArgb(44, 51, 62)), new Rectangle(Width - 1, Height - 1, 1, 1));
        }

    }

    class MysticClose : Control
    {

        #region " Declarations "
        #endregion
        private MouseState _State;

        #region " Mouse States "
        protected override void OnMouseEnter(EventArgs e)
        {
            base.OnMouseEnter(e);
            _State = MouseState.Over;
            Invalidate();
        }

        protected override void OnMouseLeave(EventArgs e)
        {
            base.OnMouseLeave(e);
            _State = MouseState.None;
            Invalidate();
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);
            _State = MouseState.Down;
            Invalidate();
        }

        protected override void OnMouseUp(MouseEventArgs e)
        {
            base.OnMouseUp(e);
            _State = MouseState.Over;
            Invalidate();
        }

        protected override void OnClick(EventArgs e)
        {
            base.OnClick(e);
            Application.Exit();
        }
        #endregion

        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            Size = new Size(12, 12);
        }

        public MysticClose()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.OptimizedDoubleBuffer | ControlStyles.SupportsTransparentBackColor, true);
            DoubleBuffered = true;
            Size = new Size(12, 12);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics G = e.Graphics;
            BackColor = Color.Transparent;

            StringFormat _StringF = new StringFormat();
            _StringF.Alignment = StringAlignment.Center;
            _StringF.LineAlignment = StringAlignment.Center;

            G.DrawString("r", new Font("Marlett", 11), new LinearGradientBrush(new Point(0, 0), new Point(0, Height), Color.FromArgb(50, 153, 228), Color.FromArgb(22, 109, 173)), new RectangleF(0, 0, Width, Height), _StringF);

            switch (_State)
            {
                case MouseState.Down:
                    G.DrawString("r", new Font("Marlett", 11), new SolidBrush(Color.FromArgb(40, Color.Black)), new RectangleF(0, 0, Width, Height), _StringF);
                    break;
            }

        }

    }

    class MysticMini : Control
    {

        #region " Declarations "
        #endregion
        private MouseState _State;

        #region " Mouse States "
        protected override void OnMouseEnter(EventArgs e)
        {
            base.OnMouseEnter(e);
            _State = MouseState.Over;
            Invalidate();
        }

        protected override void OnMouseLeave(EventArgs e)
        {
            base.OnMouseLeave(e);
            _State = MouseState.None;
            Invalidate();
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);
            _State = MouseState.Down;
            Invalidate();
        }

        protected override void OnMouseUp(MouseEventArgs e)
        {
            base.OnMouseUp(e);
            _State = MouseState.Over;
            Invalidate();
        }

        protected override void OnClick(EventArgs e)
        {
            base.OnClick(e);
            FindForm().WindowState = FormWindowState.Minimized;
        }
        #endregion

        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            Size = new Size(12, 12);
        }

        public MysticMini()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.OptimizedDoubleBuffer | ControlStyles.SupportsTransparentBackColor, true);
            DoubleBuffered = true;
            Size = new Size(12, 12);
        }
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics G = e.Graphics;
            BackColor = Color.Transparent;
            StringFormat _StringF = new StringFormat();
            _StringF.Alignment = StringAlignment.Center;
            _StringF.LineAlignment = StringAlignment.Center;
            G.DrawString("0", new Font("Marlett", 11), new LinearGradientBrush(new Point(0, 0), new Point(0, Height), Color.FromArgb(50, 153, 228), Color.FromArgb(22, 109, 173)), new RectangleF(0, 0, Width, Height), _StringF);
            switch (_State)
            {
                case MouseState.Down:
                    G.DrawString("0", new Font("Marlett", 11), new SolidBrush(Color.FromArgb(40, Color.Black)), new RectangleF(0, 0, Width, Height), _StringF);
                    break;
            }
        }
    }
}