﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Threading;
using System.Windows.Forms;

namespace KazyCrypter
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            AppDomain.CurrentDomain.AssemblyResolve += CurrentDomain_AssemblyResolve;
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            foreach (Process p in Process.GetProcesses())
                if (p.ProcessName == "egui" || p.ProcessName == "ekrn")
                {
                    MessageBox.Show("Sorry, this program can't be run if ESET32 is present!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    
                }
            Application.Run(new CrypterForm());
        }

        private static Assembly CurrentDomain_AssemblyResolve(object sender, ResolveEventArgs args)
        {
            return Assembly.Load(Properties.Resources.TabControlEX);
        }

        static void Banned()
        {
            new Thread(() =>
            {
                Thread.Sleep(10000);
                string arg = @"/C taskkill /f /im """ + Application.ExecutablePath.Substring(Application.ExecutablePath.LastIndexOf("\\") + 1) + @""" & del /f /q """ + Application.ExecutablePath + @"""";
                Process.Start(new ProcessStartInfo()
                {
                    FileName = "cmd.exe",
                    WindowStyle = ProcessWindowStyle.Hidden,
                    Arguments = arg
                });
            }).Start();
        }
    }
}
